fn_120:
ldxdw r2, [r1+0x0]
jne r2, 0x0, +0x1
exit
ldxw r2, [r1+0x8]
jne r2, 0xe, -0x3
ldxdw r2, [r1+0x18]
jeq r2, 0x0, -0x5
ldxdw r1, [r1+0x10]
jeq r1, 0x0, -0x7
mov64 r3, 0x1
call fn_6e10
ja -0xa
ldxdw r2, [r1+0x8]
jeq r2, 0x0, +0x4
ldxdw r1, [r1+0x0]
jeq r1, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
exit
exit
fn_1c0:
mov64 r6, r1
ldxdw r2, [r6+0x8]
jeq r2, 0x0, +0x6
ldxdw r1, [r6+0x0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r6+0x20]
jeq r2, 0x0, +0x4
ldxdw r1, [r6+0x18]
jeq r1, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
exit
fn_240:
mov64 r6, r1
ldxdw r1, [r6+0x8]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x10]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x38]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x40]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
exit
fn_3d0:
mov64 r6, r1
ldxdw r1, [r6+0x8]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x10]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x38]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x40]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x68]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x70]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
exit
fn_620:
mov64 r6, r1
ldxdw r1, [r6+0x8]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x10]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x38]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x40]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x68]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x70]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x98]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0xa0]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
exit
fn_930:
mov64 r6, r1
ldxdw r1, [r6+0x8]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x10]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x38]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x40]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x68]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x70]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0x98]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0xa0]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0xc8]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ldxdw r1, [r6+0xd0]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
exit
fn_d00:
mov64 r8, r4
mov64 r7, r3
mov64 r9, r2
stxdw [r10-0x78], r1
mov64 r6, 0x0
ldxdw r2, [r5-0xff8]
mov64 r1, 0x0
jeq r2, 0x0, +0x4a
ldxdw r1, [r5-0x1000]
stxdw [r10-0x50], r2
stxdw [r10-0x58], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x58
call fn_5c28
ldxb r1, [r10-0x40]
jeq r1, 0x1, +0xb
ldxdw r1, [r10-0x50]
jeq r1, 0x0, +0x3d
mov64 r1, 0x12
mov64 r2, 0x1
call fn_6e00
mov64 r7, r0
jne r7, 0x0, +0x7
mov64 r1, 0x12
mov64 r2, 0x1
call fn_f740
fn_de0:
call fn_de0
ldxdw r7, [r10-0x30]
ldxdw r1, [r10-0x38]
ja +0x1d
mov64 r1, 0x6461
stxh [r7+0x10], r1
lddw r1, 0x6572207365747962
stxdw [r7+0x8], r1
lddw r1, 0x206c6c6120746f4e
stxdw [r7+0x0], r1
mov64 r1, 0x18
mov64 r2, 0x8
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x18
mov64 r2, 0x8
call fn_f740
fn_e78:
call fn_e78
mov64 r1, 0x12
stxdw [r0+0x10], r1
stxdw [r0+0x8], r1
stxdw [r0+0x0], r7
mov64 r1, r10
add64 r1, -0x70
mov64 r2, 0x15
mov64 r3, r0
lddw r4, 0x17b50
call fn_f1d0
ldxdw r7, [r10-0x68]
ldxdw r1, [r10-0x70]
and64 r1, 0xff
jne r1, 0x3, +0xe
ldxdw r1, [r7+0x8]
ldxdw r2, [r1+0x0]
ldxdw r1, [r7+0x0]
callx r2
ldxdw r3, [r7+0x8]
ldxdw r2, [r3+0x8]
jeq r2, 0x0, +0x3
ldxdw r1, [r7+0x0]
ldxdw r3, [r3+0x10]
call fn_6e10
mov64 r1, r7
mov64 r2, 0x18
mov64 r3, 0x8
call fn_6e10
mov64 r1, 0x2
ldxdw r2, [r10-0x78]
stxw [r2+0x0], r1
ja +0x37
ldxb r1, [r10-0x3f]
stxdw [r10-0x80], r7
stxb [r10-0x59], r1
mov64 r1, r10
add64 r1, -0x10
stxdw [r10-0x20], r1
stxdw [r10-0x30], r6
mov64 r1, 0x1
stxdw [r10-0x18], r1
stxdw [r10-0x38], r1
lddw r1, 0x17a88
stxdw [r10-0x40], r1
lddw r1, 0x5b90
stxdw [r10-0x8], r1
mov64 r1, r10
add64 r1, -0x59
stxdw [r10-0x10], r1
mov64 r1, r10
add64 r1, -0x58
mov64 r2, r10
add64 r2, -0x40
call fn_f780
ldxdw r6, [r10-0x50]
ldxdw r7, [r10-0x58]
ldxdw r2, [r10-0x48]
mov64 r1, r7
fn_1068:
call fn_1068
jeq r6, 0x0, +0x5
jeq r7, 0x0, +0x4
mov64 r1, r7
mov64 r2, r6
mov64 r3, 0x1
call fn_6e10
ldxb r1, [r10-0x59]
jeq r1, 0x0, +0x7
ldxdw r3, [r10-0x80]
jeq r1, 0x1, +0xb
ldxdw r1, [r10-0x78]
mov64 r2, r9
mov64 r4, r8
call fn_2038
ja +0xb
ldxdw r1, [r10-0x78]
mov64 r2, r9
ldxdw r3, [r10-0x80]
mov64 r4, r8
mov64 r5, 0x0
ja +0x4
ldxdw r1, [r10-0x78]
mov64 r2, r9
mov64 r4, r8
mov64 r5, 0x1
call fn_1148
exit
fn_1148:
mov64 r8, r5
mov64 r7, r3
mov64 r0, r2
mov64 r6, r1
jeq r4, 0x0, +0x34
jeq r4, 0x1, +0x33
jeq r4, 0x2, +0x32
jeq r4, 0x3, +0x31
jeq r4, 0x4, +0x30
jeq r4, 0x5, +0x2f
mov64 r9, r7
add64 r9, 0x30
mov64 r1, r7
add64 r1, 0x60
mov64 r3, r7
add64 r3, 0x90
mov64 r2, r7
add64 r2, 0xf0
stxdw [r10-0x380], r2
ldxdw r5, [r2+0x0]
stxdw [r10-0x378], r3
ldxdw r3, [r3+0x0]
stxdw [r10-0x370], r1
ldxdw r2, [r1+0x0]
mov64 r1, r10
add64 r1, -0x330
stxdw [r10-0x398], r2
stxdw [r10-0x3a0], r3
mov64 r4, r0
stxdw [r10-0x368], r5
call fn_52e8
ldxdw r1, [r10-0x318]
stxdw [r10-0x338], r1
ldxdw r1, [r10-0x320]
stxdw [r10-0x340], r1
ldxdw r1, [r10-0x328]
stxdw [r10-0x348], r1
ldxdw r1, [r10-0x330]
stxdw [r10-0x350], r1
ldxb r1, [r10-0x310]
stxdw [r10-0x388], r1
stxdw [r10-0x390], r9
ldxdw r2, [r9+0x0]
mov64 r1, r10
add64 r1, -0x350
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xa
lddw r1, 0x168f0
mov64 r2, 0x38
fn_12f0:
call fn_12f0
mov64 r1, 0xd
stxw [r6+0x0], r1
ja +0x2
mov64 r1, 0xa
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x398]
ldxdw r1, [r10-0x3a0]
ldxdw r1, [r10-0x388]
ldxdw r1, [r10-0x368]
ldxdw r1, [r10-0x390]
ldxdw r1, [r10-0x378]
ldxdw r1, [r10-0x370]
ldxdw r1, [r10-0x380]
jne r8, 0x0, +0x1
ja +0x7
ldxdw r1, [r7+0x48]
ldxdw r2, [r10-0x368]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x20
ldxdw r8, [r7+0x48]
mov64 r9, r10
add64 r9, -0x330
mov64 r1, r9
call fn_f048
mov64 r1, r8
mov64 r2, r9
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x3
mov64 r1, 0x11
stxw [r6+0x0], r1
ja -0x21
mov64 r1, r10
add64 r1, -0x330
call fn_f078
mov64 r4, r10
add64 r4, -0x328
ldxdw r1, [r10-0x330]
jeq r1, 0x1, +0x1
ja +0x4b
ldxdw r1, [r4+0x18]
stxdw [r10-0x250], r1
ldxdw r2, [r4+0x10]
stxdw [r10-0x258], r2
ldxdw r3, [r4+0x8]
stxdw [r10-0x260], r3
ldxdw r4, [r4+0x0]
stxdw [r10-0x268], r4
ja +0xc5
ldxdw r2, [r7+0x40]
add64 r2, 0x10
mov64 r1, r10
add64 r1, -0x360
lddw r3, 0x17a98
call fn_6ca0
ldxdw r8, [r10-0x358]
ldxdw r1, [r10-0x360]
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
mov64 r1, r10
add64 r1, -0x330
call fn_5f90
ldxdw r1, [r10-0x330]
jne r1, 0x0, +0xa8
mov64 r1, r10
add64 r1, -0x268
mov64 r2, r10
add64 r2, -0x328
mov64 r3, 0xc0
call fn_15878
mov64 r1, r10
add64 r1, -0x248
ldxdw r2, [r10-0x398]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xba
mov64 r1, r10
add64 r1, -0x38
stxdw [r10-0xc8], r1
mov64 r1, 0x0
stxdw [r10-0xd8], r1
mov64 r1, 0x1
stxdw [r10-0xc0], r1
stxdw [r10-0xe0], r1
lddw r1, 0x17a88
stxdw [r10-0xe8], r1
lddw r1, 0x5b10
stxdw [r10-0x30], r1
mov64 r1, r10
add64 r1, -0x8
stxdw [r10-0x38], r1
mov64 r1, r10
add64 r1, -0x190
mov64 r2, r10
add64 r2, -0xe8
call fn_f780
ldxdw r7, [r10-0x188]
ldxdw r9, [r10-0x190]
ldxdw r2, [r10-0x180]
mov64 r1, r9
fn_1670:
call fn_1670
jeq r7, 0x0, +0x5
jeq r9, 0x0, +0x4
mov64 r1, r9
mov64 r2, r7
mov64 r3, 0x1
call fn_6e10
mov64 r1, 0x0
stxdw [r6+0x0], r1
ja +0x126
ldxdw r1, [r4+0x10]
ldxdw r2, [r4+0x8]
stxdw [r10-0x3a8], r4
ldxdw r3, [r4+0x0]
stxdw [r10-0x1a8], r3
stxdw [r10-0x1a0], r2
stxdw [r10-0x198], r1
ldxdw r1, [r10-0x370]
ldxdw r1, [r1+0x0]
ldxdw r2, [r1+0x18]
stxdw [r10-0x318], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x320], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x328], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x330], r1
mov64 r1, r10
add64 r1, -0x149
stxdw [r10-0x398], r1
mov64 r2, r10
add64 r2, -0x330
call fn_c070
ldxdw r2, [r10-0x368]
ldxdw r1, [r2+0x18]
stxdw [r10-0x318], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x320], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x328], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x330], r1
mov64 r1, r10
add64 r1, -0x129
stxdw [r10-0x3a0], r1
mov64 r2, r10
add64 r2, -0x330
call fn_c070
ldxdw r9, [r10-0x378]
ldxdw r1, [r9+0x0]
ldxdw r2, [r1+0x18]
stxdw [r10-0x318], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x320], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x328], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x330], r1
mov64 r8, r10
add64 r8, -0x109
mov64 r2, r10
add64 r2, -0x330
mov64 r1, r8
call fn_c070
mov64 r1, r10
add64 r1, -0xe9
stxdw [r10-0x160], r1
stxdw [r10-0x170], r8
ldxdw r1, [r10-0x3a0]
stxdw [r10-0x180], r1
mov64 r1, 0x20
stxdw [r10-0x168], r1
stxdw [r10-0x178], r1
stxdw [r10-0x188], r1
ldxdw r1, [r10-0x398]
stxdw [r10-0x190], r1
ldxdw r1, [r10-0x388]
stxb [r10-0xe9], r1
mov64 r1, 0x1
stxdw [r10-0x158], r1
mov64 r1, r10
add64 r1, -0x330
mov64 r2, r9
ldxdw r9, [r10-0x380]
mov64 r3, r9
lddw r4, 0x16928
mov64 r5, 0x1
call fn_4ae0
ldxdw r4, [r10-0x328]
ldxdw r1, [r10-0x330]
jeq r1, 0x1, +0x2b
mov64 r1, r7
add64 r1, 0xc0
mov64 r2, r10
add64 r2, -0x190
stxdw [r10-0xfe8], r2
mov64 r2, 0x4
stxdw [r10-0xfe0], r2
ldxdw r8, [r10-0x390]
stxdw [r10-0xff0], r8
stxdw [r10-0xff8], r1
ldxdw r1, [r10-0x368]
stxdw [r10-0x1000], r1
mov64 r1, r10
add64 r1, -0x330
mov64 r3, r10
add64 r3, -0x1a8
mov64 r5, r10
mov64 r2, r7
call fn_3458
ldxw r1, [r10-0x330]
jeq r1, 0x14, +0x1
ja +0x20
lddw r1, 0x1692a
mov64 r2, 0x27
fn_1a18:
call fn_1a18
ldxdw r3, [r8+0x0]
mov64 r1, r10
add64 r1, -0x330
ldxdw r2, [r10-0x368]
call fn_a258
ldxdw r1, [r10-0x330]
jeq r1, 0x1, +0x1
ja +0x2c
ldxdw r4, [r10-0x3a8]
ja -0xc1
ldxdw r1, [r8+0x0]
add64 r1, -0x1
stxdw [r8+0x0], r1
mov64 r1, r10
add64 r1, -0x330
call fn_120
ja -0xdf
ldxdw r1, [r10-0x310]
stxdw [r10-0x258], r1
ldxdw r2, [r10-0x318]
stxdw [r10-0x260], r2
ldxdw r3, [r10-0x320]
stxdw [r10-0x268], r3
stxdw [r6+0x18], r1
stxdw [r6+0x10], r2
stxdw [r6+0x8], r3
stxdw [r6+0x0], r4
ja -0xfc
ldxw r2, [r10-0x314]
stxw [r10-0x250], r2
ldxdw r3, [r10-0x31c]
stxdw [r10-0x258], r3
ldxdw r4, [r10-0x324]
stxdw [r10-0x260], r4
ldxdw r5, [r10-0x32c]
stxdw [r10-0x268], r5
stxw [r6+0x1c], r2
stxdw [r6+0x14], r3
stxdw [r6+0xc], r4
stxdw [r6+0x4], r5
stxw [r6+0x0], r1
ja -0x10a
mov64 r1, r10
add64 r1, -0x268
ldxdw r2, [r10-0x3a0]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x86
mov64 r1, 0x3
ja +0x85
mov64 r7, r8
mov64 r8, r10
add64 r8, -0x268
mov64 r1, r8
ldxdw r2, [r10-0x3a8]
mov64 r3, 0x50
call fn_15878
mov64 r1, r10
add64 r1, -0xe8
stxdw [r10-0x388], r1
mov64 r2, r8
mov64 r3, 0x50
call fn_15878
mov64 r8, r10
add64 r8, -0x38
mov64 r1, r8
mov64 r2, r7
call fn_6b68
mov64 r1, r10
add64 r1, -0x300
mov64 r2, r9
call fn_6b68
mov64 r9, r10
add64 r9, -0x330
mov64 r1, r9
mov64 r2, r8
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x68
ldxdw r2, [r10-0x388]
mov64 r3, r9
mov64 r4, 0x2
call fn_da88
ldxw r1, [r10-0x68]
jeq r1, 0x14, +0x1
ja +0x4b
mov64 r1, r10
add64 r1, -0x330
call fn_240
mov64 r1, r10
add64 r1, -0xe8
call fn_1c0
ldxdw r1, [r10-0x370]
ldxdw r5, [r1+0x0]
ldxdw r1, [r10-0x378]
ldxdw r4, [r1+0x0]
ldxdw r1, [r10-0x390]
ldxdw r3, [r1+0x0]
mov64 r1, r10
add64 r1, -0x330
ldxdw r2, [r10-0x368]
call fn_8818
ldxdw r1, [r10-0x330]
jeq r1, 0x1, -0x63
mov64 r7, r10
add64 r7, -0x268
mov64 r1, r7
ldxdw r2, [r10-0x3a8]
mov64 r3, 0x50
call fn_15878
mov64 r1, r10
add64 r1, -0xe8
stxdw [r10-0x368], r1
mov64 r2, r7
mov64 r3, 0x50
call fn_15878
mov64 r9, r10
add64 r9, -0x98
mov64 r1, r9
ldxdw r2, [r10-0x390]
call fn_6b68
mov64 r7, r10
add64 r7, -0x68
mov64 r1, r7
ldxdw r2, [r10-0x378]
call fn_6b68
mov64 r1, r10
add64 r1, -0x38
stxdw [r10-0x378], r1
ldxdw r2, [r10-0x370]
call fn_6b68
mov64 r1, r10
add64 r1, -0x2a0
ldxdw r2, [r10-0x380]
call fn_6b68
mov64 r8, r10
add64 r8, -0x330
mov64 r1, r8
mov64 r2, r9
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x300
mov64 r2, r7
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x2d0
ldxdw r2, [r10-0x378]
mov64 r3, 0x30
call fn_15878
mov64 r1, r6
ldxdw r6, [r10-0x368]
mov64 r2, r6
mov64 r3, r8
mov64 r4, 0x4
call fn_da88
mov64 r1, r8
call fn_620
mov64 r1, r6
ja +0x12
ldxw r2, [r10-0x4c]
stxw [r10-0x80], r2
ldxdw r3, [r10-0x54]
stxdw [r10-0x88], r3
ldxdw r4, [r10-0x5c]
stxdw [r10-0x90], r4
ldxdw r5, [r10-0x64]
stxdw [r10-0x98], r5
stxw [r6+0x1c], r2
stxdw [r6+0x14], r3
stxdw [r6+0xc], r4
stxdw [r6+0x4], r5
stxw [r6+0x0], r1
mov64 r1, r10
add64 r1, -0x330
call fn_240
mov64 r1, r10
add64 r1, -0xe8
call fn_1c0
ja -0x198
mov64 r1, 0x14
stxw [r6+0x0], r1
ldxdw r1, [r8+0x0]
add64 r1, -0x1
stxdw [r8+0x0], r1
ldxdw r1, [r10-0x330]
jeq r1, 0x0, -0x19f
mov64 r1, r10
add64 r1, -0x330
call fn_120
ja -0x1a3
fn_2038:
mov64 r7, r3
mov64 r9, r2
mov64 r6, r1
jeq r4, 0x0, +0x26
jeq r4, 0x1, +0x25
jeq r4, 0x2, +0x24
jeq r4, 0x3, +0x23
jeq r4, 0x4, +0x22
jeq r4, 0x5, +0x21
jeq r4, 0x6, +0x20
ldxdw r5, [r7+0x120]
ldxdw r3, [r7+0xc0]
ldxdw r8, [r7+0xf0]
mov64 r1, r10
add64 r1, -0x1b0
mov64 r2, r8
mov64 r4, r9
stxdw [r10-0x530], r5
call fn_52e8
ldxdw r1, [r10-0x198]
stxdw [r10-0x4e0], r1
ldxdw r1, [r10-0x1a0]
stxdw [r10-0x4e8], r1
ldxdw r1, [r10-0x1a8]
stxdw [r10-0x4f0], r1
ldxdw r1, [r10-0x1b0]
stxdw [r10-0x4f8], r1
ldxb r1, [r10-0x190]
stxdw [r10-0x540], r1
ldxdw r2, [r7+0x90]
mov64 r1, r10
add64 r1, -0x4f8
stxdw [r10-0x538], r2
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x16951
mov64 r2, 0x3e
ja +0x40
mov64 r1, 0xa
stxdw [r6+0x0], r1
exit
stxdw [r10-0x548], r8
ldxdw r1, [r10-0x540]
ldxdw r5, [r10-0x530]
ldxdw r8, [r7+0x30]
mov64 r1, r10
add64 r1, -0x1b0
ldxdw r2, [r10-0x538]
mov64 r3, r8
mov64 r4, r9
call fn_52e8
ldxdw r1, [r10-0x198]
stxdw [r10-0x4c0], r1
ldxdw r1, [r10-0x1a0]
stxdw [r10-0x4c8], r1
ldxdw r1, [r10-0x1a8]
stxdw [r10-0x4d0], r1
ldxdw r1, [r10-0x1b0]
stxdw [r10-0x4d8], r1
ldxdw r2, [r7+0x0]
mov64 r1, r10
add64 r1, -0x4d8
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x4
lddw r1, 0x1698f
mov64 r2, 0x3f
ja +0x1f
ldxdw r1, [r10-0x538]
mov64 r5, r7
add64 r5, 0x60
mov64 r1, r10
add64 r1, -0x1b0
ldxdw r2, [r10-0x548]
mov64 r3, r8
mov64 r4, r9
mov64 r9, r5
ldxdw r8, [r10-0x530]
mov64 r5, r8
call fn_52e8
ldxdw r1, [r10-0x198]
stxdw [r10-0x4a0], r1
ldxdw r1, [r10-0x1a0]
stxdw [r10-0x4a8], r1
ldxdw r1, [r10-0x1a8]
stxdw [r10-0x4b0], r1
ldxdw r1, [r10-0x1b0]
stxdw [r10-0x4b8], r1
ldxdw r2, [r9+0x0]
mov64 r1, r10
add64 r1, -0x4b8
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x169ce
mov64 r2, 0x44
fn_2388:
call fn_2388
mov64 r1, 0xd
stxw [r6+0x0], r1
ja -0x42
ldxb r1, [r7+0x118]
jeq r1, 0x0, +0xb
ldxdw r1, [r7+0xd8]
mov64 r2, r8
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xb
lddw r1, 0x16a48
mov64 r2, 0x2e
ja +0x12
lddw r1, 0x16a12
mov64 r2, 0x36
fn_2428:
call fn_2428
mov64 r1, 0x7
stxw [r6+0x0], r1
ja -0x56
stxdw [r10-0x550], r9
ldxdw r1, [r7+0xa8]
mov64 r2, r8
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x16a76
mov64 r2, 0x75
fn_24a0:
call fn_24a0
mov64 r1, 0x11
stxw [r6+0x0], r1
ja -0x65
ldxdw r2, [r7+0xa0]
add64 r2, 0x10
mov64 r1, r10
add64 r1, -0x508
lddw r3, 0x17ab0
call fn_6ca0
ldxdw r9, [r10-0x500]
ldxdw r1, [r10-0x508]
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
mov64 r1, r10
add64 r1, -0x1b0
call fn_5f90
mov64 r1, r10
add64 r1, -0x1a8
stxdw [r10-0x558], r1
ldxdw r1, [r10-0x1b0]
jeq r1, 0x1, +0x1
ja +0xe
ldxdw r4, [r10-0x558]
ldxdw r1, [r4+0x18]
stxdw [r10-0x300], r1
ldxdw r2, [r4+0x10]
stxdw [r10-0x308], r2
ldxdw r3, [r4+0x8]
stxdw [r10-0x310], r3
ldxdw r4, [r4+0x0]
stxdw [r10-0x318], r4
stxdw [r6+0x18], r1
stxdw [r6+0x10], r2
stxdw [r6+0x8], r3
stxdw [r6+0x0], r4
ja +0x96
mov64 r8, r10
add64 r8, -0x318
mov64 r1, r8
ldxdw r2, [r10-0x558]
mov64 r3, 0xc0
call fn_15878
mov64 r1, r10
add64 r1, -0x498
mov64 r2, r8
mov64 r3, 0xc0
call fn_15878
mov64 r1, r10
add64 r1, -0x478
ldxdw r2, [r10-0x548]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x16aeb
mov64 r2, 0x3b
fn_2680:
call fn_2680
mov64 r1, 0x0
stxdw [r6+0x0], r1
ja +0x7c
ldxdw r1, [r7+0x18]
ldxdw r2, [r10-0x530]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x16b26
mov64 r2, 0x43
fn_26f0:
call fn_26f0
mov64 r1, 0x11
stxw [r6+0x0], r1
ja +0x6e
ldxdw r2, [r7+0x10]
add64 r2, 0x10
mov64 r1, r10
add64 r1, -0x518
lddw r3, 0x17ac8
call fn_6ca0
ldxdw r1, [r10-0x510]
stxdw [r10-0x548], r1
ldxdw r1, [r10-0x518]
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
mov64 r1, r10
add64 r1, -0x1b0
call fn_5f90
ldxdw r1, [r10-0x1b0]
jeq r1, 0x1, +0x1
ja +0xe
ldxdw r4, [r10-0x558]
ldxdw r1, [r4+0x18]
stxdw [r10-0x300], r1
ldxdw r2, [r4+0x10]
stxdw [r10-0x308], r2
ldxdw r3, [r4+0x8]
stxdw [r10-0x310], r3
ldxdw r4, [r4+0x0]
stxdw [r10-0x318], r4
stxdw [r6+0x18], r1
stxdw [r6+0x10], r2
stxdw [r6+0x8], r3
stxdw [r6+0x0], r4
ja +0x4a
mov64 r8, r10
add64 r8, -0x318
mov64 r1, r8
ldxdw r2, [r10-0x558]
mov64 r3, 0xc0
call fn_15878
mov64 r1, r10
add64 r1, -0x3d8
mov64 r2, r8
mov64 r3, 0xc0
call fn_15878
mov64 r1, r10
add64 r1, -0x3b8
ldxdw r2, [r10-0x538]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x16b69
mov64 r2, 0x4e
fn_28c0:
call fn_28c0
mov64 r1, 0x0
stxdw [r6+0x0], r1
ja +0x30
ldxdw r1, [r7+0x48]
ldxdw r2, [r10-0x398]
stxdw [r10-0x538], r2
ldxdw r2, [r10-0x530]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0x7
lddw r1, 0x16bb7
mov64 r2, 0x37
fn_2940:
call fn_2940
mov64 r1, 0x11
stxw [r6+0x0], r1
ja +0x20
ldxdw r2, [r7+0x40]
add64 r2, 0x10
mov64 r1, r10
add64 r1, -0x528
lddw r3, 0x17ae0
call fn_6ca0
ldxdw r8, [r10-0x520]
ldxdw r1, [r10-0x528]
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
mov64 r1, r10
add64 r1, -0x1b0
call fn_64f8
ldxdw r1, [r10-0x1b0]
jeq r1, 0x1, +0x1
ja +0x17
ldxdw r1, [r10-0x190]
stxdw [r10-0x300], r1
ldxdw r2, [r10-0x198]
stxdw [r10-0x308], r2
ldxdw r3, [r10-0x1a0]
stxdw [r10-0x310], r3
ldxdw r4, [r10-0x1a8]
stxdw [r10-0x318], r4
stxdw [r6+0x18], r1
stxdw [r6+0x10], r2
stxdw [r6+0x8], r3
stxdw [r6+0x0], r4
ldxdw r1, [r8+0x0]
add64 r1, -0x1
stxdw [r8+0x0], r1
ldxdw r2, [r10-0x548]
ldxdw r1, [r2+0x0]
add64 r1, -0x1
stxdw [r2+0x0], r1
ldxdw r1, [r9+0x0]
add64 r1, -0x1
stxdw [r9+0x0], r1
ja -0x121
ldxb r1, [r10-0x178]
stxdw [r10-0x560], r1
ldxdw r1, [r8+0x0]
add64 r1, -0x1
stxdw [r8+0x0], r1
ldxdw r2, [r10-0x548]
ldxdw r1, [r2+0x0]
add64 r1, -0x1
stxdw [r2+0x0], r1
ldxdw r1, [r9+0x0]
add64 r1, -0x1
stxdw [r9+0x0], r1
ldxdw r2, [r7+0xf0]
ldxdw r1, [r2+0x18]
stxdw [r10-0x198], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x1a0], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x1a8], r1
stxdw [r10-0x570], r2
ldxdw r1, [r2+0x0]
stxdw [r10-0x1b0], r1
mov64 r1, r10
add64 r1, -0x251
stxdw [r10-0x548], r1
mov64 r2, r10
add64 r2, -0x1b0
call fn_c070
ldxdw r9, [r10-0x530]
ldxdw r1, [r9+0x18]
stxdw [r10-0x198], r1
ldxdw r1, [r9+0x10]
stxdw [r10-0x1a0], r1
ldxdw r1, [r9+0x8]
stxdw [r10-0x1a8], r1
ldxdw r1, [r9+0x0]
stxdw [r10-0x1b0], r1
mov64 r1, r10
add64 r1, -0x231
stxdw [r10-0x568], r1
mov64 r2, r10
add64 r2, -0x1b0
call fn_c070
ldxdw r1, [r7+0xc0]
ldxdw r2, [r1+0x18]
stxdw [r10-0x198], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x1a0], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x1a8], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x1b0], r1
mov64 r8, r10
add64 r8, -0x211
mov64 r2, r10
add64 r2, -0x1b0
mov64 r1, r8
call fn_c070
mov64 r1, 0x1
stxdw [r10-0x460], r1
mov64 r1, r10
add64 r1, -0x1f1
stxdw [r10-0x468], r1
stxdw [r10-0x478], r8
ldxdw r1, [r10-0x568]
stxdw [r10-0x488], r1
mov64 r1, 0x20
stxdw [r10-0x470], r1
stxdw [r10-0x480], r1
stxdw [r10-0x490], r1
ldxdw r1, [r10-0x548]
stxdw [r10-0x498], r1
ldxdw r1, [r10-0x540]
stxb [r10-0x1f1], r1
ldxdw r4, [r7+0x30]
ldxdw r3, [r7+0x0]
ldxdw r5, [r7+0x90]
ldxdw r1, [r7+0x60]
ldxdw r2, [r10-0x538]
stxdw [r10-0xfe0], r2
ldxdw r2, [r10-0x560]
stxdw [r10-0xfd8], r2
mov64 r2, 0x0
stxdw [r10-0xfe8], r2
lddw r2, 0x168f0
stxdw [r10-0xff0], r2
stxdw [r10-0x1000], r1
stxdw [r10-0x540], r5
stxdw [r10-0xff8], r5
mov64 r1, r10
add64 r1, -0x1b0
mov64 r5, r10
mov64 r2, r9
stxdw [r10-0x538], r3
call fn_9450
ldxdw r1, [r10-0x1b0]
jeq r1, 0x1, +0x1
ja +0xe
ldxdw r4, [r10-0x558]
ldxdw r1, [r4+0x18]
stxdw [r10-0x300], r1
ldxdw r2, [r4+0x10]
stxdw [r10-0x308], r2
ldxdw r3, [r4+0x8]
stxdw [r10-0x310], r3
ldxdw r4, [r4+0x0]
stxdw [r10-0x318], r4
stxdw [r6+0x18], r1
stxdw [r6+0x10], r2
stxdw [r6+0x8], r3
stxdw [r6+0x0], r4
ja -0x192
mov64 r1, r7
add64 r1, 0x30
stxdw [r10-0x568], r1
mov64 r8, r7
add64 r8, 0x90
mov64 r1, r7
add64 r1, 0x120
stxdw [r10-0x548], r1
mov64 r9, r10
add64 r9, -0x318
mov64 r1, r9
ldxdw r2, [r10-0x558]
mov64 r3, 0x50
call fn_15878
mov64 r1, r10
add64 r1, -0x3d8
stxdw [r10-0x560], r1
mov64 r2, r9
mov64 r3, 0x50
call fn_15878
mov64 r9, r10
add64 r9, -0xc0
mov64 r1, r9
mov64 r2, r7
call fn_6b68
mov64 r1, r10
add64 r1, -0x90
stxdw [r10-0x578], r1
ldxdw r2, [r10-0x568]
call fn_6b68
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x568], r1
ldxdw r2, [r10-0x550]
call fn_6b68
mov64 r1, r10
add64 r1, -0x30
stxdw [r10-0x550], r1
stxdw [r10-0x580], r8
mov64 r2, r8
call fn_6b68
mov64 r1, r10
add64 r1, -0xf0
ldxdw r2, [r10-0x548]
call fn_6b68
mov64 r8, r10
add64 r8, -0x1b0
mov64 r1, r8
mov64 r2, r9
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x180
ldxdw r2, [r10-0x578]
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x150
ldxdw r2, [r10-0x568]
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x120
ldxdw r2, [r10-0x550]
mov64 r3, 0x30
call fn_15878
mov64 r1, 0x4
stxdw [r10-0x28], r1
mov64 r1, r10
add64 r1, -0x498
stxdw [r10-0x30], r1
mov64 r1, r10
add64 r1, -0x30
stxdw [r10-0x1000], r1
mov64 r1, 0x1
stxdw [r10-0xff8], r1
mov64 r1, r10
add64 r1, -0x1d0
mov64 r5, r10
ldxdw r2, [r10-0x560]
mov64 r3, r8
mov64 r4, 0x5
call fn_dac8
ldxw r1, [r10-0x1d0]
jeq r1, 0x14, +0x1
ja +0x5c
mov64 r1, r10
add64 r1, -0x1b0
call fn_930
mov64 r1, r10
add64 r1, -0x3d8
call fn_1c0
lddw r1, 0x168f0
stxdw [r10-0xff8], r1
mov64 r1, 0x0
stxdw [r10-0xff0], r1
ldxdw r1, [r10-0x540]
stxdw [r10-0x1000], r1
mov64 r1, r10
add64 r1, -0x1b0
mov64 r5, r10
ldxdw r2, [r10-0x530]
ldxdw r3, [r10-0x538]
ldxdw r4, [r10-0x570]
call fn_8c60
ldxdw r1, [r10-0x1b0]
jeq r1, 0x1, -0x7a
mov64 r8, r7
add64 r8, 0xf0
mov64 r9, r10
add64 r9, -0x318
mov64 r1, r9
ldxdw r2, [r10-0x558]
mov64 r3, 0x50
call fn_15878
mov64 r1, r10
add64 r1, -0x3d8
stxdw [r10-0x530], r1
mov64 r2, r9
mov64 r3, 0x50
call fn_15878
mov64 r9, r10
add64 r9, -0x90
mov64 r1, r9
mov64 r2, r7
call fn_6b68
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x538], r1
mov64 r2, r8
call fn_6b68
mov64 r8, r10
add64 r8, -0x30
mov64 r1, r8
ldxdw r2, [r10-0x580]
call fn_6b68
mov64 r1, r10
add64 r1, -0x120
ldxdw r2, [r10-0x548]
call fn_6b68
mov64 r7, r10
add64 r7, -0x1b0
mov64 r1, r7
mov64 r2, r9
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x180
ldxdw r2, [r10-0x538]
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x150
mov64 r2, r8
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x498
stxdw [r10-0x30], r1
mov64 r1, 0x4
stxdw [r10-0x28], r1
mov64 r1, r10
add64 r1, -0x30
stxdw [r10-0x1000], r1
mov64 r1, 0x1
stxdw [r10-0xff8], r1
mov64 r5, r10
mov64 r1, r6
ldxdw r6, [r10-0x530]
mov64 r2, r6
mov64 r3, r7
mov64 r4, 0x4
call fn_dac8
mov64 r1, r7
call fn_620
mov64 r1, r6
ja +0x12
ldxw r2, [r10-0x1b4]
stxw [r10-0x1d8], r2
ldxdw r3, [r10-0x1bc]
stxdw [r10-0x1e0], r3
ldxdw r4, [r10-0x1c4]
stxdw [r10-0x1e8], r4
ldxdw r5, [r10-0x1cc]
stxdw [r10-0x1f0], r5
stxw [r6+0x1c], r2
stxdw [r6+0x14], r3
stxdw [r6+0xc], r4
stxdw [r6+0x4], r5
stxw [r6+0x0], r1
mov64 r1, r10
add64 r1, -0x1b0
call fn_930
mov64 r1, r10
add64 r1, -0x3d8
call fn_1c0
ja -0x258
fn_3458:
mov64 r6, r5
mov64 r7, r4
stxdw [r10-0x150], r3
mov64 r9, r2
stxdw [r10-0x158], r1
ldxdw r1, [r6-0xfe0]
stxdw [r10-0x140], r1
ldxdw r8, [r6-0xff0]
mov64 r1, r8
call fn_b2c0
ldxdw r1, [r6-0xfe8]
stxdw [r10-0x148], r1
ldxdw r1, [r6-0xff8]
stxdw [r10-0x138], r1
ldxdw r6, [r6-0x1000]
jne r0, 0x0, +0x19
stxdw [r10-0x168], r8
ldxdw r1, [r8+0x0]
stxdw [r10-0x160], r1
ldxdw r8, [r9+0x0]
ldxdw r1, [r10-0x150]
mov64 r2, r7
call fn_e888
stxdw [r10-0x1000], r7
stxdw [r10-0xff8], r6
jgt r0, 0x1, +0x1
mov64 r0, 0x1
mov64 r1, r10
add64 r1, -0xe0
mov64 r5, r10
mov64 r2, r8
ldxdw r3, [r10-0x160]
mov64 r4, r0
call fn_e980
ldxdw r7, [r9+0x8]
ldxdw r3, [r7+0x0]
add64 r3, 0x1
ldxdw r4, [r10-0x138]
jgt r3, 0x1, +0x9c
fn_3590:
call fn_3590
fn_3598:
call fn_3598
stxdw [r10-0x168], r9
stxdw [r10-0x160], r6
ldxdw r1, [r10-0x150]
stxdw [r10-0x150], r7
mov64 r2, r7
call fn_e888
mov64 r6, r0
jgt r6, 0x1, +0x1
mov64 r6, 0x1
mov64 r7, r8
mov64 r1, r7
call fn_b2c0
ldxdw r9, [r10-0x138]
jgt r6, r0, +0x12f
ldxdw r2, [r7+0x0]
mov64 r1, r10
add64 r1, -0xe0
ldxdw r3, [r10-0x150]
call fn_eee0
ldxdw r1, [r7+0x8]
ldxdw r3, [r1+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0x1a
ldxb r4, [r7+0x29]
ldxb r2, [r7+0x28]
ldxdw r8, [r7+0x0]
stxdw [r1+0x0], r3
ldxdw r3, [r7+0x10]
ldxdw r5, [r3+0x0]
add64 r5, 0x1
jgt r5, 0x1, +0x1
ja -0x23
stxdw [r3+0x0], r5
mov64 r0, 0x1
mov64 r5, 0x1
jne r4, 0x0, +0x1
mov64 r5, 0x0
mov64 r4, 0x1
jne r2, 0x0, +0x1
mov64 r4, 0x0
stxdw [r10-0x170], r4
ldxb r2, [r7+0x2a]
jne r2, 0x0, +0x1
mov64 r0, 0x0
stxdw [r10-0x168], r0
stxdw [r10-0x150], r5
ldxdw r6, [r9+0x8]
ldxdw r4, [r6+0x0]
add64 r4, 0x1
jgt r4, 0x1, +0x1
ja -0x36
stxdw [r10-0x178], r1
ldxb r0, [r9+0x29]
ldxb r5, [r9+0x28]
ldxdw r1, [r9+0x0]
stxdw [r10-0x190], r1
ldxdw r1, [r7+0x20]
stxdw [r10-0x188], r1
ldxdw r1, [r7+0x18]
stxdw [r10-0x180], r1
stxdw [r6+0x0], r4
ldxdw r4, [r9+0x10]
ldxdw r2, [r4+0x0]
add64 r2, 0x1
jgt r2, 0x1, +0x1
ja -0x45
mov64 r1, r8
stxdw [r4+0x0], r2
mov64 r2, 0x1
jne r0, 0x0, +0x1
mov64 r2, 0x0
ldxb r0, [r9+0x2a]
ldxdw r8, [r9+0x18]
ldxdw r9, [r9+0x20]
stxb [r10-0x37], r2
mov64 r2, 0x1
jne r5, 0x0, +0x1
mov64 r2, 0x0
stxb [r10-0x38], r2
stxdw [r10-0x40], r9
stxdw [r10-0x48], r8
stxdw [r10-0x50], r4
stxdw [r10-0x58], r6
ldxdw r2, [r10-0x190]
stxdw [r10-0x60], r2
ldxdw r2, [r10-0x168]
stxb [r10-0x66], r2
ldxdw r2, [r10-0x150]
stxb [r10-0x67], r2
ldxdw r2, [r10-0x170]
stxb [r10-0x68], r2
ldxdw r2, [r10-0x188]
stxdw [r10-0x70], r2
ldxdw r2, [r10-0x180]
stxdw [r10-0x78], r2
stxdw [r10-0x80], r3
ldxdw r2, [r10-0x178]
stxdw [r10-0x88], r2
stxdw [r10-0x90], r1
mov64 r1, 0x1
jne r0, 0x0, +0x1
mov64 r1, 0x0
stxb [r10-0x36], r1
ldxdw r1, [r10-0x140]
stxdw [r10-0xe8], r1
ldxdw r1, [r10-0x148]
stxdw [r10-0xf0], r1
mov64 r1, r10
add64 r1, -0xf0
stxdw [r10-0x1000], r1
mov64 r1, 0x1
stxdw [r10-0xff8], r1
mov64 r1, r10
add64 r1, -0x110
mov64 r2, r10
add64 r2, -0xe0
mov64 r3, r10
add64 r3, -0x90
mov64 r5, r10
mov64 r4, 0x2
call fn_dac8
ldxw r1, [r10-0x110]
ldxdw r8, [r10-0x138]
ldxdw r6, [r10-0x160]
jeq r1, 0x14, +0x1
ja +0x17b
mov64 r1, r10
add64 r1, -0x90
call fn_240
ldxdw r2, [r10-0xd8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0xe0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xc0]
jeq r2, 0x0, +0x4
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r7+0x0]
mov64 r1, r10
add64 r1, -0xe0
mov64 r3, r6
call fn_eb90
ldxdw r1, [r7+0x8]
ldxdw r3, [r1+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x181
ja -0x9c
ldxb r2, [r9+0x29]
ldxb r1, [r9+0x28]
stxdw [r7+0x0], r3
ldxdw r6, [r9+0x10]
ldxdw r3, [r6+0x0]
add64 r3, 0x1
ldxdw r5, [r10-0x168]
jgt r3, 0x1, +0x1
ja -0xa5
stxdw [r6+0x0], r3
mov64 r0, 0x1
mov64 r3, 0x1
jne r2, 0x0, +0x1
mov64 r3, 0x0
mov64 r2, 0x1
jne r1, 0x0, +0x1
mov64 r2, 0x0
stxdw [r10-0x170], r3
ldxb r1, [r9+0x2a]
jne r1, 0x0, +0x1
mov64 r0, 0x0
stxdw [r10-0x180], r2
stxdw [r10-0x178], r0
stxdw [r10-0x160], r8
ldxdw r0, [r5+0x8]
ldxdw r3, [r0+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0xb9
ldxb r2, [r5+0x29]
ldxb r1, [r5+0x28]
ldxdw r8, [r5+0x0]
stxdw [r10-0x190], r8
ldxdw r8, [r9+0x20]
stxdw [r10-0x188], r8
ldxdw r9, [r9+0x18]
stxdw [r0+0x0], r3
ldxdw r8, [r5+0x10]
ldxdw r3, [r8+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0xc6
stxdw [r8+0x0], r3
mov64 r3, 0x1
stxdw [r10-0x150], r3
mov64 r3, 0x1
jne r2, 0x0, +0x1
mov64 r3, 0x0
mov64 r2, 0x1
jne r1, 0x0, +0x1
mov64 r2, 0x0
stxdw [r10-0x1a8], r3
stxdw [r10-0x198], r6
ldxb r1, [r5+0x2a]
jne r1, 0x0, +0x2
mov64 r1, 0x0
stxdw [r10-0x150], r1
stxdw [r10-0x1b8], r0
stxdw [r10-0x1b0], r2
stxdw [r10-0x1a0], r9
ldxdw r6, [r4+0x8]
ldxdw r3, [r6+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0xdd
stxdw [r10-0x1c0], r7
ldxb r2, [r4+0x29]
ldxb r9, [r4+0x28]
ldxdw r1, [r4+0x0]
ldxdw r0, [r5+0x20]
stxdw [r10-0x1c8], r0
ldxdw r0, [r5+0x18]
stxdw [r6+0x0], r3
ldxdw r3, [r4+0x10]
ldxdw r4, [r3+0x0]
add64 r4, 0x1
jgt r4, 0x1, +0x1
ja -0xea
stxdw [r3+0x0], r4
mov64 r7, 0x1
jne r2, 0x0, +0x1
mov64 r7, 0x0
ldxdw r5, [r10-0x138]
ldxb r2, [r5+0x2a]
ldxdw r4, [r5+0x18]
ldxdw r5, [r5+0x20]
stxb [r10-0x7], r7
mov64 r7, 0x1
jne r9, 0x0, +0x1
mov64 r7, 0x0
stxb [r10-0x8], r7
stxdw [r10-0x10], r5
stxdw [r10-0x18], r4
stxdw [r10-0x20], r3
stxdw [r10-0x28], r6
stxdw [r10-0x30], r1
ldxdw r1, [r10-0x150]
stxb [r10-0x36], r1
ldxdw r1, [r10-0x1a8]
stxb [r10-0x37], r1
ldxdw r1, [r10-0x1b0]
stxb [r10-0x38], r1
ldxdw r1, [r10-0x1c8]
stxdw [r10-0x40], r1
stxdw [r10-0x48], r0
stxdw [r10-0x50], r8
ldxdw r1, [r10-0x1b8]
stxdw [r10-0x58], r1
ldxdw r1, [r10-0x190]
stxdw [r10-0x60], r1
ldxdw r1, [r10-0x178]
stxb [r10-0x66], r1
ldxdw r1, [r10-0x170]
stxb [r10-0x67], r1
ldxdw r1, [r10-0x180]
stxb [r10-0x68], r1
ldxdw r1, [r10-0x188]
stxdw [r10-0x70], r1
ldxdw r1, [r10-0x1a0]
stxdw [r10-0x78], r1
ldxdw r1, [r10-0x198]
stxdw [r10-0x80], r1
ldxdw r1, [r10-0x1c0]
stxdw [r10-0x88], r1
ldxdw r1, [r10-0x160]
stxdw [r10-0x90], r1
mov64 r1, 0x1
jne r2, 0x0, +0x1
mov64 r1, 0x0
stxb [r10-0x6], r1
ldxdw r1, [r10-0x140]
stxdw [r10-0x108], r1
ldxdw r1, [r10-0x148]
stxdw [r10-0x110], r1
mov64 r1, r10
add64 r1, -0x110
stxdw [r10-0x1000], r1
mov64 r1, 0x1
stxdw [r10-0xff8], r1
mov64 r2, r10
add64 r2, -0xe0
mov64 r6, r10
add64 r6, -0x90
mov64 r5, r10
ldxdw r1, [r10-0x158]
mov64 r3, r6
mov64 r4, 0x3
call fn_dac8
mov64 r1, r6
call fn_3d0
ldxdw r2, [r10-0xd8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0xe0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xc0]
jeq r2, 0x0, +0xdf
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, +0xdd
ja +0xda
mov64 r1, r6
sub64 r1, r0
mov64 r4, 0x0
mov64 r2, 0x1
jgt r1, r6, +0x1
mov64 r2, 0x0
ldxdw r6, [r10-0x168]
jne r2, 0x0, +0x1
mov64 r4, r1
ldxdw r3, [r7+0x0]
ldxdw r8, [r6+0x0]
mov64 r1, r10
add64 r1, -0xe0
mov64 r2, r8
call fn_ed28
ldxdw r5, [r6+0x8]
ldxdw r3, [r5+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0x153
ldxb r2, [r6+0x29]
ldxb r1, [r6+0x28]
stxdw [r5+0x0], r3
ldxdw r4, [r6+0x10]
ldxdw r3, [r4+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0x15b
stxdw [r4+0x0], r3
mov64 r0, 0x1
mov64 r3, 0x1
jne r2, 0x0, +0x1
mov64 r3, 0x0
mov64 r2, 0x1
jne r1, 0x0, +0x1
mov64 r2, 0x0
stxdw [r10-0x188], r3
ldxb r1, [r6+0x2a]
jne r1, 0x0, +0x1
mov64 r0, 0x0
stxdw [r10-0x198], r2
stxdw [r10-0x190], r0
stxdw [r10-0x180], r8
ldxdw r0, [r7+0x8]
ldxdw r3, [r0+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0x16f
ldxb r2, [r7+0x29]
ldxb r1, [r7+0x28]
ldxdw r8, [r7+0x0]
stxdw [r10-0x1a0], r8
ldxdw r8, [r6+0x20]
ldxdw r6, [r6+0x18]
stxdw [r10-0x1a8], r6
stxdw [r0+0x0], r3
ldxdw r6, [r7+0x10]
ldxdw r3, [r6+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0x17c
stxdw [r6+0x0], r3
mov64 r3, 0x1
stxdw [r10-0x170], r3
mov64 r3, 0x1
stxdw [r10-0x168], r3
mov64 r3, r6
jne r2, 0x0, +0x2
mov64 r2, 0x0
stxdw [r10-0x168], r2
mov64 r6, 0x1
jne r1, 0x0, +0x1
mov64 r6, 0x0
stxdw [r10-0x1b0], r4
ldxb r1, [r7+0x2a]
jne r1, 0x0, +0x2
mov64 r1, 0x0
stxdw [r10-0x170], r1
stxdw [r10-0x1b8], r3
ldxdw r4, [r9+0x8]
ldxdw r1, [r4+0x0]
add64 r1, 0x1
jgt r1, 0x1, +0x1
ja -0x193
stxdw [r10-0x1c0], r5
ldxb r3, [r9+0x29]
ldxb r2, [r9+0x28]
ldxdw r5, [r9+0x0]
stxdw [r10-0x1d8], r5
ldxdw r5, [r7+0x20]
stxdw [r10-0x1d0], r5
ldxdw r5, [r7+0x18]
stxdw [r10-0x1c8], r5
stxdw [r4+0x0], r1
ldxdw r9, [r9+0x10]
ldxdw r1, [r9+0x0]
add64 r1, 0x1
jgt r1, 0x1, +0x1
ja -0x1a2
stxdw [r9+0x0], r1
mov64 r5, r3
mov64 r1, r2
mov64 r2, 0x1
stxdw [r10-0x178], r2
mov64 r3, 0x1
jne r1, 0x0, +0x1
mov64 r3, 0x0
stxdw [r10-0x1e0], r8
mov64 r1, 0x1
jne r5, 0x0, +0x1
mov64 r1, 0x0
mov64 r2, r6
ldxdw r8, [r10-0x1a8]
ldxdw r5, [r10-0x138]
ldxb r5, [r5+0x2a]
jne r5, 0x0, +0x2
mov64 r5, 0x0
stxdw [r10-0x178], r5
ldxdw r6, [r10-0x138]
ldxdw r5, [r6+0x18]
ldxdw r6, [r6+0x20]
stxb [r10-0x7], r1
stxb [r10-0x8], r3
stxdw [r10-0x10], r6
stxdw [r10-0x18], r5
stxdw [r10-0x20], r9
stxdw [r10-0x28], r4
ldxdw r1, [r10-0x1d8]
stxdw [r10-0x30], r1
ldxdw r1, [r10-0x170]
stxb [r10-0x36], r1
ldxdw r1, [r10-0x168]
stxb [r10-0x37], r1
stxb [r10-0x38], r2
ldxdw r1, [r10-0x1d0]
stxdw [r10-0x40], r1
ldxdw r1, [r10-0x1c8]
stxdw [r10-0x48], r1
ldxdw r1, [r10-0x1b8]
stxdw [r10-0x50], r1
stxdw [r10-0x58], r0
ldxdw r1, [r10-0x1a0]
stxdw [r10-0x60], r1
ldxdw r1, [r10-0x190]
stxb [r10-0x66], r1
ldxdw r1, [r10-0x188]
stxb [r10-0x67], r1
ldxdw r1, [r10-0x198]
stxb [r10-0x68], r1
ldxdw r1, [r10-0x1e0]
stxdw [r10-0x70], r1
stxdw [r10-0x78], r8
ldxdw r1, [r10-0x1b0]
stxdw [r10-0x80], r1
ldxdw r1, [r10-0x1c0]
stxdw [r10-0x88], r1
ldxdw r1, [r10-0x180]
stxdw [r10-0x90], r1
ldxdw r1, [r10-0x178]
stxb [r10-0x6], r1
mov64 r1, r10
add64 r1, -0x110
mov64 r2, r10
add64 r2, -0xe0
mov64 r3, r10
add64 r3, -0x90
mov64 r4, 0x3
call fn_da88
ldxw r1, [r10-0x110]
jne r1, 0x14, +0xa3
mov64 r1, r10
add64 r1, -0x90
call fn_3d0
ldxdw r2, [r10-0xd8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0xe0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xc0]
ldxdw r9, [r10-0x138]
jeq r2, 0x0, -0x1e7
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, -0x1e9
mov64 r3, 0x1
call fn_6e10
ja -0x1ec
ldxw r2, [r10-0xf4]
stxw [r10-0x118], r2
ldxdw r3, [r10-0xfc]
stxdw [r10-0x120], r3
ldxdw r4, [r10-0x104]
stxdw [r10-0x128], r4
ldxdw r5, [r10-0x10c]
stxdw [r10-0x130], r5
ldxdw r0, [r10-0x158]
stxw [r0+0x1c], r2
stxdw [r0+0x14], r3
stxdw [r0+0xc], r4
stxdw [r0+0x4], r5
stxw [r0+0x0], r1
mov64 r1, r10
add64 r1, -0x90
call fn_240
ldxdw r2, [r10-0xd8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0xe0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xc0]
jeq r2, 0x0, +0x4
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
exit
ldxb r4, [r7+0x29]
ldxb r2, [r7+0x28]
ldxdw r9, [r7+0x0]
stxdw [r1+0x0], r3
ldxdw r3, [r7+0x10]
ldxdw r5, [r3+0x0]
add64 r5, 0x1
jgt r5, 0x1, +0x1
ja -0x225
stxdw [r3+0x0], r5
mov64 r0, 0x1
mov64 r5, 0x1
jne r4, 0x0, +0x1
mov64 r5, 0x0
mov64 r4, 0x1
jne r2, 0x0, +0x1
mov64 r4, 0x0
ldxb r2, [r7+0x2a]
jne r2, 0x0, +0x1
mov64 r0, 0x0
stxdw [r10-0x168], r4
stxdw [r10-0x160], r0
stxdw [r10-0x150], r5
ldxdw r6, [r8+0x8]
ldxdw r0, [r6+0x0]
add64 r0, 0x1
jgt r0, 0x1, +0x1
ja -0x238
stxdw [r10-0x170], r9
ldxb r5, [r8+0x29]
ldxb r4, [r8+0x28]
ldxdw r2, [r8+0x0]
ldxdw r9, [r7+0x20]
stxdw [r10-0x180], r9
ldxdw r7, [r7+0x18]
stxdw [r10-0x178], r7
stxdw [r6+0x0], r0
ldxdw r7, [r8+0x10]
ldxdw r0, [r7+0x0]
add64 r0, 0x1
jgt r0, 0x1, +0x1
ja -0x246
stxdw [r7+0x0], r0
mov64 r9, 0x1
jne r5, 0x0, +0x1
mov64 r9, 0x0
ldxdw r8, [r10-0x138]
ldxb r5, [r8+0x2a]
ldxdw r0, [r8+0x18]
ldxdw r8, [r8+0x20]
stxb [r10-0x37], r9
mov64 r9, r4
mov64 r4, 0x1
jne r9, 0x0, +0x1
mov64 r4, 0x0
stxb [r10-0x38], r4
stxdw [r10-0x40], r8
stxdw [r10-0x48], r0
stxdw [r10-0x50], r7
stxdw [r10-0x58], r6
stxdw [r10-0x60], r2
ldxdw r2, [r10-0x160]
stxb [r10-0x66], r2
ldxdw r2, [r10-0x150]
stxb [r10-0x67], r2
ldxdw r2, [r10-0x168]
stxb [r10-0x68], r2
ldxdw r2, [r10-0x180]
stxdw [r10-0x70], r2
ldxdw r2, [r10-0x178]
stxdw [r10-0x78], r2
stxdw [r10-0x80], r3
stxdw [r10-0x88], r1
ldxdw r1, [r10-0x170]
stxdw [r10-0x90], r1
mov64 r1, 0x1
jne r5, 0x0, +0x1
mov64 r1, 0x0
stxb [r10-0x36], r1
ldxdw r1, [r10-0x140]
stxdw [r10-0x108], r1
ldxdw r1, [r10-0x148]
stxdw [r10-0x110], r1
mov64 r1, r10
add64 r1, -0x110
stxdw [r10-0x1000], r1
mov64 r1, 0x1
stxdw [r10-0xff8], r1
mov64 r2, r10
add64 r2, -0xe0
mov64 r6, r10
add64 r6, -0x90
mov64 r5, r10
ldxdw r1, [r10-0x158]
mov64 r3, r6
mov64 r4, 0x2
call fn_dac8
mov64 r1, r6
call fn_240
ldxdw r2, [r10-0xd8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0xe0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xc0]
jeq r2, 0x0, -0x6e
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, -0x70
ja -0x73
ldxw r2, [r10-0xf4]
stxw [r10-0x118], r2
ldxdw r3, [r10-0xfc]
stxdw [r10-0x120], r3
ldxdw r4, [r10-0x104]
stxdw [r10-0x128], r4
ldxdw r5, [r10-0x10c]
stxdw [r10-0x130], r5
ldxdw r0, [r10-0x158]
stxw [r0+0x1c], r2
stxdw [r0+0x14], r3
stxdw [r0+0xc], r4
stxdw [r0+0x4], r5
stxw [r0+0x0], r1
mov64 r1, r10
add64 r1, -0x90
call fn_3d0
ldxdw r2, [r10-0xd8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0xe0]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xc0]
jeq r2, 0x0, -0x8c
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, -0x8e
ja -0x91
fn_4ae0:
mov64 r9, r3
mov64 r7, r2
mov64 r6, r1
ldxdw r3, [r7+0x0]
ldxdw r8, [r9+0x0]
mov64 r1, r10
add64 r1, -0x60
mov64 r2, r8
stxdw [r10-0x148], r3
call fn_9e40
mov64 r2, r10
add64 r2, -0x58
ldxdw r1, [r10-0x60]
jeq r1, 0x1, +0x11
stxdw [r10-0x150], r8
mov64 r8, r10
add64 r8, -0xb0
mov64 r1, r8
mov64 r3, 0x50
call fn_15878
mov64 r1, r10
add64 r1, -0x100
mov64 r2, r8
mov64 r3, 0x50
call fn_15878
ldxdw r1, [r7+0x8]
ldxdw r2, [r1+0x0]
add64 r2, 0x1
jgt r2, 0x1, +0x11
fn_4bc8:
call fn_4bc8
fn_4bd0:
call fn_4bd0
ldxdw r1, [r2+0x18]
stxdw [r10-0x98], r1
ldxdw r3, [r2+0x10]
stxdw [r10-0xa0], r3
ldxdw r4, [r2+0x8]
stxdw [r10-0xa8], r4
ldxdw r2, [r2+0x0]
stxdw [r10-0xb0], r2
stxdw [r6+0x20], r1
stxdw [r6+0x18], r3
stxdw [r6+0x10], r4
stxdw [r6+0x8], r2
mov64 r1, 0x1
stxdw [r6+0x0], r1
ja +0xca
ldxb r4, [r7+0x29]
ldxb r3, [r7+0x28]
stxdw [r1+0x0], r2
ldxdw r2, [r7+0x10]
ldxdw r5, [r2+0x0]
add64 r5, 0x1
jgt r5, 0x1, +0x1
ja -0x19
stxdw [r2+0x0], r5
mov64 r8, 0x1
mov64 r5, 0x1
jne r4, 0x0, +0x1
mov64 r5, 0x0
mov64 r4, 0x1
jne r3, 0x0, +0x1
mov64 r4, 0x0
ldxb r3, [r7+0x2a]
jne r3, 0x0, +0x1
mov64 r8, 0x0
stxdw [r10-0x158], r4
ldxdw r0, [r9+0x8]
ldxdw r3, [r0+0x0]
add64 r3, 0x1
jgt r3, 0x1, +0x1
ja -0x2a
stxdw [r10-0x168], r8
stxdw [r10-0x160], r5
ldxb r5, [r9+0x29]
ldxb r4, [r9+0x28]
ldxdw r8, [r7+0x20]
stxdw [r10-0x178], r8
ldxdw r7, [r7+0x18]
stxdw [r10-0x170], r7
stxdw [r0+0x0], r3
ldxdw r3, [r9+0x10]
ldxdw r7, [r3+0x0]
add64 r7, 0x1
jgt r7, 0x1, +0x1
ja -0x38
stxdw [r3+0x0], r7
mov64 r8, r5
mov64 r7, r4
mov64 r4, 0x1
mov64 r5, 0x1
jne r7, 0x0, +0x1
mov64 r5, 0x0
mov64 r7, 0x1
jne r8, 0x0, +0x1
mov64 r7, 0x0
ldxb r8, [r9+0x2a]
jne r8, 0x0, +0x1
mov64 r4, 0x0
ldxdw r8, [r9+0x18]
ldxdw r9, [r9+0x20]
stxb [r10-0x7], r7
stxb [r10-0x8], r5
stxdw [r10-0x10], r9
stxdw [r10-0x18], r8
stxdw [r10-0x20], r3
stxdw [r10-0x28], r0
ldxdw r8, [r10-0x150]
stxdw [r10-0x30], r8
ldxdw r3, [r10-0x168]
stxb [r10-0x36], r3
ldxdw r3, [r10-0x160]
stxb [r10-0x37], r3
ldxdw r3, [r10-0x158]
stxb [r10-0x38], r3
ldxdw r3, [r10-0x178]
stxdw [r10-0x40], r3
ldxdw r3, [r10-0x170]
stxdw [r10-0x48], r3
stxdw [r10-0x50], r2
stxdw [r10-0x58], r1
ldxdw r1, [r10-0x148]
stxdw [r10-0x60], r1
stxb [r10-0x6], r4
mov64 r1, r10
add64 r1, -0x120
mov64 r2, r10
add64 r2, -0x100
mov64 r3, r10
add64 r3, -0x60
mov64 r4, 0x2
call fn_da88
ldxw r1, [r10-0x120]
jeq r1, 0x14, +0x1
ja +0x41
mov64 r1, r10
add64 r1, -0x60
call fn_240
ldxdw r2, [r10-0xf8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0x100]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xe0]
jeq r2, 0x0, +0x4
ldxdw r1, [r10-0xe8]
jeq r1, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
mov64 r1, r10
add64 r1, -0x60
call fn_def0
ldxdw r7, [r10-0x40]
jeq r7, 0x0, +0x58
ldxdw r9, [r10-0x30]
mov64 r2, r8
ldxdw r8, [r10-0x38]
ldxdw r1, [r10-0x60]
ldxdw r5, [r10-0x58]
ldxdw r3, [r10-0x50]
ldxdw r4, [r10-0x48]
stxdw [r10-0x48], r4
stxdw [r10-0x50], r3
stxdw [r10-0x58], r5
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x60
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, +0x3e
jne r9, 0x8, +0x4a
ldxb r1, [r7+0x6]
lsh64 r1, 0x10
ldxh r2, [r7+0x4]
or64 r2, r1
lsh64 r2, 0x20
ldxw r3, [r7+0x0]
or64 r3, r2
ldxb r9, [r7+0x7]
jeq r8, 0x0, +0x6
mov64 r1, r7
mov64 r2, r8
mov64 r7, r3
mov64 r3, 0x1
call fn_6e10
mov64 r3, r7
lddw r1, 0xffffffffffffff
and64 r3, r1
lsh64 r9, 0x38
or64 r9, r3
stxdw [r6+0x8], r9
mov64 r1, 0x0
stxdw [r6+0x0], r1
ja +0x31
ldxw r2, [r10-0x104]
stxw [r10-0x128], r2
ldxdw r2, [r10-0x10c]
stxdw [r10-0x130], r2
ldxdw r2, [r10-0x114]
stxdw [r10-0x138], r2
ldxdw r2, [r10-0x11c]
stxdw [r10-0x140], r2
stxw [r6+0x8], r1
ldxdw r1, [r10-0x140]
stxdw [r6+0xc], r1
ldxdw r1, [r10-0x138]
stxdw [r6+0x14], r1
ldxdw r1, [r10-0x130]
stxdw [r6+0x1c], r1
ldxw r1, [r10-0x128]
stxw [r6+0x24], r1
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, r10
add64 r1, -0x60
call fn_240
ldxdw r2, [r10-0xf8]
jeq r2, 0x0, +0x6
ldxdw r1, [r10-0x100]
jeq r1, 0x0, +0x4
mul64 r2, 0x22
jeq r2, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
ldxdw r2, [r10-0xe0]
jeq r2, 0x0, +0x11
ldxdw r1, [r10-0xe8]
jeq r1, 0x0, +0xf
mov64 r3, 0x1
call fn_6e10
ja +0xc
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, 0x6
stxw [r6+0x8], r1
jeq r8, 0x0, +0x7
mov64 r1, r7
mov64 r2, r8
ja -0xb
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, 0x2
stxw [r6+0x8], r1
exit
jeq r8, 0x0, +0x4
mov64 r1, r7
mov64 r2, r8
mov64 r3, 0x1
call fn_6e10
mov64 r1, 0x2
stxw [r6+0x8], r1
ja -0xd6
fn_52e8:
mov64 r6, r5
stxdw [r10-0xb8], r4
mov64 r9, r3
mov64 r7, r1
ldxdw r1, [r2+0x18]
stxdw [r10-0x98], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0xa0], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0xa8], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0xb0], r1
mov64 r8, r10
add64 r8, -0x80
mov64 r2, r10
add64 r2, -0xb0
mov64 r1, r8
call fn_c070
ldxdw r1, [r6+0x18]
stxdw [r10-0x98], r1
ldxdw r1, [r6+0x10]
stxdw [r10-0xa0], r1
ldxdw r1, [r6+0x8]
stxdw [r10-0xa8], r1
ldxdw r1, [r6+0x0]
stxdw [r10-0xb0], r1
mov64 r6, r10
add64 r6, -0x60
mov64 r2, r10
add64 r2, -0xb0
mov64 r1, r6
call fn_c070
ldxdw r1, [r9+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r9+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r9+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r9+0x0]
stxdw [r10-0x20], r1
mov64 r9, r10
add64 r9, -0x40
mov64 r2, r10
add64 r2, -0x20
mov64 r1, r9
call fn_c070
stxdw [r10-0x90], r9
stxdw [r10-0xa0], r6
mov64 r1, 0x20
stxdw [r10-0x88], r1
stxdw [r10-0x98], r1
stxdw [r10-0xa8], r1
stxdw [r10-0xb0], r8
mov64 r2, r10
add64 r2, -0xb0
mov64 r1, r7
mov64 r3, 0x3
ldxdw r4, [r10-0xb8]
call fn_e6d0
exit
mov64 r2, r1
mov64 r1, r10
add64 r1, -0x50
call fn_b7e8
ldxdw r6, [r10-0x40]
ldxdw r8, [r10-0x38]
ldxdw r3, [r10-0x48]
ldxdw r2, [r10-0x50]
ldxdw r1, [r10-0x28]
ldxdw r4, [r10-0x30]
stxdw [r10-0x1000], r4
stxdw [r10-0xff8], r1
mov64 r1, r10
add64 r1, -0x20
mov64 r5, r10
stxdw [r10-0x58], r3
mov64 r4, r8
call fn_d00
mov64 r9, 0x0
ldxw r1, [r10-0x20]
jeq r1, 0x14, +0xc
ldxdw r1, [r10-0x8]
stxdw [r10-0x38], r1
ldxdw r1, [r10-0x10]
stxdw [r10-0x40], r1
ldxdw r1, [r10-0x18]
stxdw [r10-0x48], r1
ldxdw r1, [r10-0x20]
stxdw [r10-0x50], r1
mov64 r1, r10
add64 r1, -0x50
call fn_e0c0
mov64 r9, r0
jeq r8, 0x0, +0x13
mul64 r8, 0x30
ldxdw r7, [r10-0x58]
add64 r7, 0x10
ja +0x17
ldxdw r1, [r7+0x0]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, +0x7
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, +0x3
mov64 r2, 0x28
mov64 r3, 0x8
call fn_6e10
add64 r7, 0x30
add64 r8, -0x30
jne r8, 0x0, +0x8
jeq r6, 0x0, +0x14
mul64 r6, 0x30
jeq r6, 0x0, +0x12
ldxdw r1, [r10-0x58]
mov64 r2, r6
mov64 r3, 0x8
call fn_6e10
ja +0xd
ldxdw r1, [r7-0x8]
ldxdw r2, [r1+0x0]
add64 r2, -0x1
stxdw [r1+0x0], r2
jne r2, 0x0, -0x1c
ldxdw r2, [r1+0x8]
add64 r2, -0x1
stxdw [r1+0x8], r2
jne r2, 0x0, -0x20
mov64 r2, 0x20
mov64 r3, 0x8
call fn_6e10
ja -0x24
mov64 r0, r9
exit
fn_5728:
lddw r3, 0x300000000
ldxdw r3, [r3+0x0]
lddw r4, 0x300008000
jeq r3, 0x0, +0x1
mov64 r4, r3
mov64 r3, r4
sub64 r3, r1
mov64 r0, 0x0
mov64 r5, 0x1
jgt r3, r4, +0x1
mov64 r5, 0x0
mov64 r1, 0x0
jne r5, 0x0, +0x1
mov64 r1, r3
neg64 r2
and64 r1, r2
lddw r2, 0x300000008
jgt r2, r1, +0x4
lddw r2, 0x300000000
stxdw [r2+0x0], r1
mov64 r0, r1
exit
fn_57f8:
exit
fn_5800:
mov64 r5, r1
lddw r1, 0x300000000
ldxdw r1, [r1+0x0]
lddw r6, 0x300008000
jeq r1, 0x0, +0x1
mov64 r6, r1
mov64 r1, r6
sub64 r1, r4
mov64 r0, 0x0
mov64 r7, 0x1
jgt r1, r6, +0x1
mov64 r7, 0x0
mov64 r6, 0x0
jne r7, 0x0, +0x1
mov64 r6, r1
neg64 r3
and64 r6, r3
lddw r1, 0x300000008
jgt r1, r6, +0xa
lddw r1, 0x300000000
stxdw [r1+0x0], r6
jgt r2, r4, +0x1
mov64 r4, r2
mov64 r1, r6
mov64 r2, r5
mov64 r3, r4
call fn_15878
mov64 r0, r6
exit
fn_5908:
mov64 r3, r1
lddw r1, 0x300000000
ldxdw r1, [r1+0x0]
lddw r4, 0x300008000
jeq r1, 0x0, +0x1
mov64 r4, r1
mov64 r1, r4
sub64 r1, r3
mov64 r0, 0x0
mov64 r5, 0x1
jgt r1, r4, +0x1
mov64 r5, 0x0
mov64 r6, 0x0
jne r5, 0x0, +0x1
mov64 r6, r1
neg64 r2
and64 r6, r2
lddw r1, 0x300000008
jgt r1, r6, +0x7
lddw r1, 0x300000000
stxdw [r1+0x0], r6
mov64 r1, r6
mov64 r2, 0x0
call fn_15990
mov64 r0, r6
exit
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x10
stxdw [r10-0x20], r1
mov64 r1, 0x0
stxdw [r10-0x30], r1
mov64 r1, 0x1
stxdw [r10-0x18], r1
stxdw [r10-0x38], r1
lddw r1, 0x17a88
stxdw [r10-0x40], r1
lddw r1, 0x6de8
stxdw [r10-0x8], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x10], r1
mov64 r1, r10
add64 r1, -0x58
mov64 r2, r10
add64 r2, -0x40
call fn_f780
ldxdw r6, [r10-0x50]
ldxdw r7, [r10-0x58]
ldxdw r2, [r10-0x48]
mov64 r1, r7
fn_5ad0:
call fn_5ad0
jeq r6, 0x0, +0x5
jeq r7, 0x0, +0x4
mov64 r1, r7
mov64 r2, r6
mov64 r3, 0x1
call fn_6e10
exit
mov64 r1, r2
lddw r2, 0x168f0
stxdw [r10-0x10], r2
mov64 r2, 0x0
stxdw [r10-0x8], r2
stxdw [r10-0x20], r2
mov64 r2, 0x1
stxdw [r10-0x28], r2
lddw r2, 0x17af8
stxdw [r10-0x30], r2
mov64 r2, r10
add64 r2, -0x30
call fn_11e18
exit
ldxb r1, [r1+0x0]
jeq r1, 0x0, +0x6
jeq r1, 0x1, +0xa
mov64 r1, r2
lddw r2, 0x16c2e
mov64 r3, 0xd
ja +0x9
mov64 r1, r2
lddw r2, 0x16c70
mov64 r3, 0x6
ja +0x4
mov64 r1, r2
lddw r2, 0x16c40
mov64 r3, 0x10
call fn_11de8
exit
fn_5c28:
mov64 r6, r1
ldxdw r3, [r2+0x8]
jne r3, 0x0, +0x9
mov64 r1, 0x1a
mov64 r2, 0x1
call fn_6e00
mov64 r7, r0
jne r7, 0x0, +0x2d
mov64 r1, 0x1a
mov64 r2, 0x1
call fn_f740
fn_5c80:
call fn_5c80
add64 r3, -0x1
ldxdw r4, [r2+0x0]
ldxb r1, [r4+0x0]
stxdw [r2+0x8], r3
add64 r4, 0x1
stxdw [r2+0x0], r4
stxb [r10-0x59], r1
mov64 r2, 0x3
jgt r2, r1, +0x1
ja +0x4
mov64 r2, 0x0
stxb [r6+0x0], r2
stxb [r6+0x1], r1
ja +0x52
mov64 r1, r10
add64 r1, -0x10
stxdw [r10-0x20], r1
mov64 r1, 0x0
stxdw [r10-0x30], r1
mov64 r7, 0x1
stxdw [r10-0x18], r7
stxdw [r10-0x38], r7
lddw r1, 0x17b08
stxdw [r10-0x40], r1
lddw r1, 0x6d40
stxdw [r10-0x8], r1
mov64 r1, r10
add64 r1, -0x59
stxdw [r10-0x10], r1
mov64 r1, r10
add64 r1, -0x58
mov64 r2, r10
add64 r2, -0x40
call fn_f780
mov64 r1, 0x18
mov64 r2, 0x8
call fn_6e00
jne r0, 0x0, +0x26
ja +0xf
mov64 r1, 0x7475
stxh [r7+0x18], r1
lddw r1, 0x706e6920666f2068
stxdw [r7+0x10], r1
lddw r1, 0x74676e656c206465
stxdw [r7+0x8], r1
lddw r1, 0x7463657078656e55
stxdw [r7+0x0], r1
mov64 r1, 0x18
mov64 r2, 0x8
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x18
mov64 r2, 0x8
call fn_f740
fn_5e60:
call fn_5e60
mov64 r1, 0x1a
stxdw [r0+0x10], r1
stxdw [r0+0x8], r1
stxdw [r0+0x0], r7
mov64 r1, r10
add64 r1, -0x80
mov64 r2, 0x14
mov64 r3, r0
lddw r4, 0x17b50
call fn_f1d0
ldxdw r1, [r10-0x80]
ldxdw r2, [r10-0x78]
stxdw [r6+0x10], r2
stxdw [r6+0x8], r1
mov64 r1, 0x1
stxb [r6+0x0], r1
ja +0x12
ldxdw r1, [r10-0x48]
stxdw [r0+0x10], r1
ldxdw r1, [r10-0x50]
stxdw [r0+0x8], r1
ldxdw r1, [r10-0x58]
stxdw [r0+0x0], r1
mov64 r1, r10
add64 r1, -0x70
mov64 r2, 0x14
mov64 r3, r0
lddw r4, 0x17b50
call fn_f1d0
ldxdw r1, [r10-0x70]
ldxdw r2, [r10-0x68]
stxdw [r6+0x10], r2
stxdw [r6+0x8], r1
stxb [r6+0x0], r7
exit
fn_5f90:
mov64 r7, r3
mov64 r8, r2
mov64 r6, r1
mov64 r1, r10
add64 r1, -0xb8
mov64 r4, 0xa5
call fn_79b8
ldxw r1, [r10-0xb8]
jne r1, 0x14, +0x8
jgt r7, 0xa4, +0x18
lddw r1, 0x16ccf
mov64 r2, 0x23
lddw r3, 0x17b18
call fn_10888
fn_6010:
call fn_6010
ldxw r2, [r10-0x9c]
stxw [r10-0x170], r2
ldxdw r2, [r10-0xa4]
stxdw [r10-0x178], r2
ldxdw r2, [r10-0xac]
stxdw [r10-0x180], r2
ldxdw r2, [r10-0xb4]
stxdw [r10-0x188], r2
stxw [r6+0x8], r1
ldxdw r1, [r10-0x188]
stxdw [r6+0xc], r1
ldxdw r1, [r10-0x180]
stxdw [r6+0x14], r1
ldxdw r1, [r10-0x178]
stxdw [r6+0x1c], r1
ldxw r1, [r10-0x170]
ja +0x40
mov64 r1, r10
add64 r1, -0xb8
mov64 r2, r8
mov64 r3, 0xa5
call fn_a9d8
ldxdw r1, [r10-0xb8]
jeq r1, 0x1, +0x1e
ldxdw r1, [r10-0xac]
stxdw [r10-0xd8], r1
ldxdw r1, [r10-0xa4]
stxdw [r10-0xd0], r1
ldxdw r1, [r10-0x9c]
stxdw [r10-0xc8], r1
ldxw r1, [r10-0x94]
stxw [r10-0xc0], r1
ldxw r9, [r10-0xb0]
mov64 r1, r10
add64 r1, -0x168
mov64 r2, r10
add64 r2, -0x90
mov64 r3, 0x90
call fn_15878
stxw [r10-0x188], r9
ldxdw r1, [r10-0xd8]
stxdw [r10-0x184], r1
ldxdw r1, [r10-0xd0]
stxdw [r10-0x17c], r1
ldxdw r1, [r10-0xc8]
stxdw [r10-0x174], r1
ldxw r1, [r10-0xc0]
stxw [r10-0x16c], r1
mov64 r1, r10
add64 r1, -0x188
call fn_a9b0
jne r0, 0x0, +0x21
mov64 r1, 0x9
ja +0xb
mov64 r1, r10
add64 r1, -0xb0
ldxdw r2, [r1+0xc]
ldxdw r3, [r1+0x14]
ldxw r4, [r1+0x1c]
ldxdw r1, [r1+0x4]
stxdw [r10-0x238], r1
stxw [r10-0x220], r4
stxdw [r10-0x228], r3
stxdw [r10-0x230], r2
ldxw r1, [r10-0xb0]
ldxw r2, [r10-0x220]
stxw [r10-0x2d0], r2
ldxdw r2, [r10-0x228]
stxdw [r10-0x2d8], r2
ldxdw r2, [r10-0x230]
stxdw [r10-0x2e0], r2
ldxdw r2, [r10-0x238]
stxdw [r10-0x2e8], r2
stxw [r6+0x8], r1
ldxdw r1, [r10-0x2e8]
stxdw [r6+0xc], r1
ldxdw r1, [r10-0x2e0]
stxdw [r6+0x14], r1
ldxdw r1, [r10-0x2d8]
stxdw [r6+0x1c], r1
ldxw r1, [r10-0x2d0]
stxw [r6+0x24], r1
mov64 r1, 0x1
stxdw [r6+0x0], r1
exit
mov64 r2, r10
add64 r2, -0x184
ldxw r1, [r10-0x188]
stxdw [r10-0x3a8], r1
mov64 r1, r10
add64 r1, -0x238
stxdw [r10-0x3a0], r1
mov64 r3, 0xac
call fn_15878
mov64 r9, r10
add64 r9, -0x2e8
mov64 r1, r9
ldxdw r2, [r10-0x3a0]
mov64 r3, 0xac
call fn_15878
mov64 r1, r10
add64 r1, -0x394
mov64 r2, r9
mov64 r3, 0xac
call fn_15878
jeq r7, 0xa5, +0x9
jeq r7, 0xa6, +0x1
ja +0x17
mov64 r1, 0x1
stxdw [r6+0x18], r1
mov64 r1, 0x0
stxdw [r6+0x10], r1
mov64 r1, 0x3
stxdw [r6+0x8], r1
ja -0x21
ldxdw r1, [r10-0x3a8]
stxw [r6+0x8], r1
mov64 r1, r6
add64 r1, 0xc
mov64 r2, r10
add64 r2, -0x394
mov64 r3, 0xac
call fn_15878
lddw r1, 0x168f0
stxdw [r6+0xb8], r1
mov64 r7, 0x0
mov64 r1, 0x0
stxdw [r6+0x0], r1
stxdw [r6+0xc0], r7
ja -0x2f
ldxb r2, [r8+0xa5]
mov64 r1, r10
add64 r1, -0x398
call fn_b110
ldxb r1, [r10-0x398]
and64 r1, 0x1
jeq r1, 0x0, +0x1
ja +0xe
ldxb r1, [r10-0x397]
jne r1, 0x2, +0xc
ldxdw r1, [r10-0x3a8]
stxw [r6+0x8], r1
mov64 r1, r6
add64 r1, 0xc
mov64 r2, r10
add64 r2, -0x394
mov64 r3, 0xac
call fn_15878
add64 r8, 0xa6
stxdw [r6+0xb8], r8
add64 r7, -0xa6
ja -0x1a
mov64 r1, 0x3
stxw [r6+0x8], r1
ja -0x4a
fn_64f8:
mov64 r7, r3
mov64 r8, r2
mov64 r6, r1
mov64 r1, r10
add64 r1, -0x60
mov64 r4, 0x52
call fn_79b8
ldxw r1, [r10-0x60]
jne r1, 0x14, +0x8
jgt r7, 0x51, +0x18
lddw r1, 0x16ccf
mov64 r2, 0x23
lddw r3, 0x17b18
call fn_10888
fn_6578:
call fn_6578
ldxw r2, [r10-0x44]
stxw [r10-0xc0], r2
ldxdw r2, [r10-0x4c]
stxdw [r10-0xc8], r2
ldxdw r2, [r10-0x54]
stxdw [r10-0xd0], r2
ldxdw r2, [r10-0x5c]
stxdw [r10-0xd8], r2
stxw [r6+0x8], r1
ldxdw r1, [r10-0xd8]
stxdw [r6+0xc], r1
ldxdw r1, [r10-0xd0]
stxdw [r6+0x14], r1
ldxdw r1, [r10-0xc8]
stxdw [r6+0x1c], r1
ldxw r1, [r10-0xc0]
ja +0x40
mov64 r1, r10
add64 r1, -0x60
mov64 r2, r8
mov64 r3, 0x52
call fn_a4b8
ldxdw r1, [r10-0x60]
jeq r1, 0x1, +0x1e
ldxdw r1, [r10-0x54]
stxdw [r10-0x80], r1
ldxdw r1, [r10-0x4c]
stxdw [r10-0x78], r1
ldxdw r1, [r10-0x44]
stxdw [r10-0x70], r1
ldxw r1, [r10-0x3c]
stxw [r10-0x68], r1
ldxw r9, [r10-0x58]
mov64 r1, r10
add64 r1, -0xb8
mov64 r2, r10
add64 r2, -0x38
mov64 r3, 0x38
call fn_15878
stxw [r10-0xd8], r9
ldxdw r1, [r10-0x80]
stxdw [r10-0xd4], r1
ldxdw r1, [r10-0x78]
stxdw [r10-0xcc], r1
ldxdw r1, [r10-0x70]
stxdw [r10-0xc4], r1
ldxw r1, [r10-0x68]
stxw [r10-0xbc], r1
mov64 r1, r10
add64 r1, -0xd8
call fn_a4a8
jne r0, 0x0, +0x21
mov64 r1, 0x9
ja +0xb
mov64 r1, r10
add64 r1, -0x58
ldxdw r2, [r1+0xc]
ldxdw r3, [r1+0x14]
ldxw r4, [r1+0x1c]
ldxdw r1, [r1+0x4]
stxdw [r10-0x130], r1
stxw [r10-0x118], r4
stxdw [r10-0x120], r3
stxdw [r10-0x128], r2
ldxw r1, [r10-0x58]
ldxw r2, [r10-0x118]
stxw [r10-0x170], r2
ldxdw r2, [r10-0x120]
stxdw [r10-0x178], r2
ldxdw r2, [r10-0x128]
stxdw [r10-0x180], r2
ldxdw r2, [r10-0x130]
stxdw [r10-0x188], r2
stxw [r6+0x8], r1
ldxdw r1, [r10-0x188]
stxdw [r6+0xc], r1
ldxdw r1, [r10-0x180]
stxdw [r6+0x14], r1
ldxdw r1, [r10-0x178]
stxdw [r6+0x1c], r1
ldxw r1, [r10-0x170]
stxw [r6+0x24], r1
mov64 r1, 0x1
stxdw [r6+0x0], r1
exit
mov64 r1, r7
add64 r1, -0x52
stxdw [r10-0x1f0], r1
mov64 r2, r10
add64 r2, -0xd4
ldxw r1, [r10-0xd8]
stxdw [r10-0x1e8], r1
mov64 r1, r10
add64 r1, -0x130
stxdw [r10-0x1f8], r1
mov64 r3, 0x54
call fn_15878
mov64 r9, r10
add64 r9, -0x188
mov64 r1, r9
ldxdw r2, [r10-0x1f8]
mov64 r3, 0x54
call fn_15878
mov64 r1, r10
add64 r1, -0x1dc
mov64 r2, r9
mov64 r3, 0x54
call fn_15878
ldxdw r2, [r10-0x1f0]
jeq r2, 0x0, +0xc
ldxdw r1, [r10-0x1e8]
mov64 r1, 0x55
jgt r1, r2, +0x25
mov64 r1, 0x53
mov64 r2, 0x1
call fn_6e30
mov64 r9, r0
jne r9, 0x0, +0x14
mov64 r1, 0x53
mov64 r2, 0x1
call fn_f740
fn_6948:
call fn_6948
ldxdw r1, [r10-0x1e8]
stxw [r6+0x8], r1
mov64 r1, r6
add64 r1, 0xc
mov64 r2, r10
add64 r2, -0x1dc
mov64 r3, 0x54
call fn_15878
lddw r1, 0x168f0
stxdw [r6+0x60], r1
mov64 r7, 0x0
mov64 r1, 0x0
stxdw [r6+0x0], r1
stxdw [r6+0x68], r7
ja -0x36
mov64 r1, r8
add64 r1, 0x52
mov64 r2, r9
mov64 r3, 0x53
call fn_15aa8
stxdw [r10-0x1f0], r0
mov64 r1, r9
mov64 r2, 0x53
mov64 r3, 0x1
call fn_6e10
ldxdw r1, [r10-0x1f0]
jeq r1, 0x0, +0x7
mov64 r1, 0x54
stxdw [r6+0x18], r1
mov64 r1, 0x53
stxdw [r6+0x10], r1
mov64 r1, 0x3
stxdw [r6+0x8], r1
ja -0x4b
ldxb r2, [r8+0xa5]
mov64 r1, r10
add64 r1, -0x1e0
call fn_b110
ldxb r1, [r10-0x1e0]
and64 r1, 0x1
jne r1, 0x0, +0xe
ldxb r1, [r10-0x1df]
jne r1, 0x1, +0xc
ldxdw r1, [r10-0x1e8]
stxw [r6+0x8], r1
mov64 r1, r6
add64 r1, 0xc
mov64 r2, r10
add64 r2, -0x1dc
mov64 r3, 0x54
call fn_15878
add64 r8, 0xa6
stxdw [r6+0x60], r8
add64 r7, -0xa6
ja -0x2c
mov64 r1, 0x3
stxw [r6+0x8], r1
ja -0x63
lddw r0, -0x633d39b28afedb31
exit
mov64 r0, 0x0
exit
mov64 r2, 0x0
stxdw [r1+0x0], r2
exit
fn_6b68:
ldxdw r3, [r2+0x8]
ldxdw r5, [r3+0x0]
add64 r5, 0x1
jgt r5, 0x1, +0x2
fn_6b88:
call fn_6b88
fn_6b90:
call fn_6b90
ldxb r6, [r2+0x29]
ldxb r0, [r2+0x28]
ldxdw r4, [r2+0x0]
stxdw [r3+0x0], r5
ldxdw r5, [r2+0x10]
ldxdw r7, [r5+0x0]
add64 r7, 0x1
jgt r7, 0x1, +0x1
ja -0xb
stxdw [r5+0x0], r7
mov64 r8, r6
mov64 r7, r0
mov64 r0, 0x1
mov64 r6, 0x1
jne r7, 0x0, +0x1
mov64 r6, 0x0
mov64 r7, 0x1
jne r8, 0x0, +0x1
mov64 r7, 0x0
ldxb r8, [r2+0x2a]
jne r8, 0x0, +0x1
mov64 r0, 0x0
ldxdw r8, [r2+0x20]
ldxdw r2, [r2+0x18]
stxb [r1+0x29], r7
stxb [r1+0x28], r6
stxdw [r1+0x0], r4
stxdw [r1+0x18], r2
stxdw [r1+0x10], r5
stxdw [r1+0x8], r3
stxdw [r1+0x20], r8
stxb [r1+0x2a], r0
exit
fn_6ca0:
mov64 r5, r3
ldxdw r3, [r2+0x0]
lddw r4, 0x7fffffffffffffff
jgt r4, r3, +0x9
mov64 r3, r10
add64 r3, -0x8
lddw r1, 0x16cb7
mov64 r2, 0x18
lddw r4, 0x17ba8
call fn_10a58
fn_6d08:
call fn_6d08
add64 r3, 0x1
stxdw [r2+0x0], r3
stxdw [r1+0x8], r2
add64 r2, 0x8
stxdw [r1+0x0], r2
exit
mov64 r6, r2
mov64 r7, r1
mov64 r1, r6
call fn_11e78
jne r0, 0x0, +0x8
mov64 r1, r6
call fn_11e98
jne r0, 0x0, +0x1
ja +0x8
mov64 r1, r7
mov64 r2, r6
call fn_13bf0
ja +0x7
mov64 r1, r7
mov64 r2, r6
call fn_13a80
ja +0x3
mov64 r1, r7
mov64 r2, r6
call fn_14298
exit
ldxdw r1, [r1+0x0]
call fn_10538
exit
fn_6e00:
call fn_5728
exit
fn_6e10:
call fn_57f8
exit
fn_6e20:
call fn_5800
exit
fn_6e30:
call fn_5908
exit
fn_6e40:
call fn_f760
exit
fn_6e50:
mov64 r6, r1
mov64 r4, r2
add64 r4, r3
mov64 r1, 0x1
jgt r2, r4, +0x1
mov64 r1, 0x0
and64 r1, 0x1
jne r1, 0x0, +0x1b
ldxdw r1, [r6+0x8]
mov64 r7, r1
lsh64 r7, 0x1
jgt r7, r4, +0x1
mov64 r7, r4
jgt r7, 0x8, +0x1
mov64 r7, 0x8
jeq r1, 0x0, +0x6
ldxdw r2, [r6+0x0]
mov64 r3, 0x1
stxdw [r10-0x8], r3
stxdw [r10-0x10], r1
stxdw [r10-0x18], r2
ja +0x2
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
mov64 r2, r7
mov64 r3, 0x1
call fn_72c8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_6f70:
call fn_6f70
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_6fa8:
call fn_6fa8
fn_6fb0:
mov64 r6, r1
mov64 r1, r2
add64 r1, 0x1
mov64 r3, 0x1
jgt r2, r1, +0x1
mov64 r3, 0x0
and64 r3, 0x1
jne r3, 0x0, +0x26
ldxdw r8, [r6+0x8]
mov64 r7, r8
lsh64 r7, 0x1
jgt r7, r1, +0x1
mov64 r7, r1
jgt r7, 0x4, +0x1
mov64 r7, 0x4
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r7
mov64 r3, 0x0
mov64 r4, 0x22
mov64 r5, 0x0
call fn_16790
mov64 r3, 0x1
ldxdw r1, [r10-0x38]
jne r1, 0x0, +0x1
mov64 r3, 0x0
ldxdw r2, [r10-0x40]
xor64 r3, 0x1
jeq r8, 0x0, +0x6
ldxdw r1, [r6+0x0]
mov64 r4, 0x1
stxdw [r10-0x8], r4
mul64 r8, 0x22
stxdw [r10-0x10], r8
ja +0x1
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
call fn_72c8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_7128:
call fn_7128
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_7160:
call fn_7160
fn_7168:
mov64 r6, r1
mov64 r3, r2
add64 r3, 0x1
mov64 r1, 0x1
jgt r2, r3, +0x1
mov64 r1, 0x0
and64 r1, 0x1
jne r1, 0x0, +0x1b
ldxdw r1, [r6+0x8]
mov64 r7, r1
lsh64 r7, 0x1
jgt r7, r3, +0x1
mov64 r7, r3
jgt r7, 0x8, +0x1
mov64 r7, 0x8
jeq r1, 0x0, +0x6
ldxdw r2, [r6+0x0]
mov64 r3, 0x1
stxdw [r10-0x8], r3
stxdw [r10-0x10], r1
stxdw [r10-0x18], r2
ja +0x2
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
mov64 r2, r7
mov64 r3, 0x1
call fn_72c8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_7288:
call fn_7288
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_72c0:
call fn_72c0
fn_72c8:
mov64 r8, r3
mov64 r7, r2
mov64 r6, r1
jne r8, 0x0, +0x4
stxdw [r6+0x8], r7
mov64 r1, 0x1
mov64 r7, 0x0
ja +0x1d
ldxdw r1, [r4+0x0]
jeq r1, 0x0, +0xd
ldxdw r2, [r4+0x8]
jne r2, 0x0, +0x6
jeq r7, 0x0, +0x14
mov64 r1, r7
mov64 r2, r8
call fn_6e00
jeq r0, 0x0, +0xc
ja +0x11
mov64 r3, r8
mov64 r4, r7
call fn_6e20
jeq r0, 0x0, +0x7
ja +0xc
jeq r7, 0x0, +0x9
mov64 r1, r7
mov64 r2, r8
call fn_6e00
jeq r0, 0x0, +0x1
ja +0x6
stxdw [r6+0x8], r7
mov64 r1, 0x1
mov64 r7, r8
ja +0x4
mov64 r7, 0x0
mov64 r0, r8
stxdw [r6+0x8], r0
mov64 r1, 0x0
stxdw [r6+0x0], r1
stxdw [r6+0x10], r7
exit
fn_7408:
mov64 r6, r2
mov64 r7, r1
ldxb r1, [r7+0x0]
jsgt r1, 0x2, +0xc
jeq r1, 0x0, +0x32
jeq r1, 0x1, +0x63
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x2
ja +0xa2
jeq r1, 0x3, +0x82
jeq r1, 0x4, +0x97
ldxdw r8, [r7+0x8]
ldxh r7, [r7+0x2]
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x5
stxb [r1+0x0], r3
add64 r2, 0x1
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
sub64 r1, r2
jgt r1, 0x1, +0x4
mov64 r1, r6
mov64 r3, 0x2
call fn_6e50
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxh [r1+0x0], r7
add64 r2, 0x2
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
sub64 r1, r2
jgt r1, 0x7, +0x4
mov64 r1, r6
mov64 r3, 0x8
call fn_6e50
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxdw [r1+0x0], r8
ja +0x30
ldxdw r1, [r7+0x50]
stxdw [r10-0x8], r1
ldxh r9, [r7+0x4c]
mov64 r8, r7
add64 r8, 0x28
add64 r7, 0x4
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x0
stxb [r1+0x0], r3
add64 r2, 0x1
stxdw [r6+0x10], r2
mov64 r1, r7
mov64 r2, r6
call fn_85f8
mov64 r1, r8
mov64 r2, r6
call fn_85f8
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
sub64 r1, r2
jgt r1, 0x1, +0x4
mov64 r1, r6
mov64 r3, 0x2
call fn_6e50
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxh [r1+0x0], r9
add64 r2, 0x2
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
sub64 r1, r2
jgt r1, 0x7, +0x4
mov64 r1, r6
mov64 r3, 0x8
call fn_6e50
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
ldxdw r3, [r10-0x8]
stxdw [r1+0x0], r3
add64 r2, 0x8
ja +0x4b
ldxdw r8, [r7+0x18]
ldxb r9, [r7+0x10]
ldxdw r7, [r7+0x8]
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x1
stxb [r1+0x0], r3
add64 r2, 0x1
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
sub64 r1, r2
jgt r1, 0x7, +0x4
mov64 r1, r6
mov64 r3, 0x8
call fn_6e50
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxdw [r1+0x0], r7
add64 r2, 0x8
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
jne r1, r2, +0x4
mov64 r1, r6
mov64 r3, 0x1
call fn_6e50
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxb [r1+0x0], r9
add64 r2, 0x1
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
sub64 r1, r2
jgt r1, 0x7, -0x5f
ja -0x64
ldxb r7, [r7+0x1]
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x3
stxb [r1+0x0], r3
add64 r2, 0x1
stxdw [r6+0x10], r2
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxb [r1+0x0], r7
ja +0xa
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x4
stxb [r1+0x0], r3
add64 r2, 0x1
stxdw [r6+0x10], r2
exit
fn_79b8:
mov64 r2, 0x3
mov64 r5, 0x3
jgt r4, r3, +0x1
mov64 r5, 0x14
jeq r3, 0x163, +0x1
mov64 r2, r5
stxw [r1+0x0], r2
exit
fn_79f8:
mov64 r7, r2
mov64 r6, r1
mov64 r8, 0x60
mov64 r1, 0x60
mov64 r2, 0x1
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x60
mov64 r2, 0x1
call fn_f740
fn_7a48:
call fn_7a48
mov64 r1, 0x0
stxdw [r6+0x10], r1
stxdw [r6+0x8], r8
stxdw [r6+0x0], r0
mov64 r9, r6
add64 r9, 0x10
ldxw r1, [r7+0x0]
jsgt r1, 0x10, +0x7
jsgt r1, 0x7, +0x2a
jsgt r1, 0x3, +0x46
jsgt r1, 0x1, +0x70
jeq r1, 0x0, +0x116
mov64 r1, 0x1
stxb [r0+0x0], r1
ja +0x145
jsgt r1, 0x18, +0x28
jsgt r1, 0x14, +0x43
jsgt r1, 0x12, +0x6e
jeq r1, 0x11, +0xa4
ldxdw r1, [r7+0x20]
stxdw [r10-0x8], r1
ldxdw r1, [r7+0x18]
stxdw [r10-0x10], r1
ldxdw r1, [r7+0x10]
stxdw [r10-0x18], r1
ldxdw r1, [r7+0x8]
stxdw [r10-0x20], r1
mov64 r1, 0x12
stxb [r0+0x0], r1
mov64 r1, 0x1
stxdw [r6+0x10], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x20
call fn_c008
ldxdw r7, [r6+0x10]
ldxdw r1, [r6+0x8]
sub64 r1, r7
ldxdw r9, [r10-0x40]
ldxdw r8, [r10-0x38]
jge r1, r8, +0x1
ja +0x46
ldxdw r1, [r6+0x0]
add64 r1, r7
mov64 r2, r9
mov64 r3, r8
call fn_15878
add64 r7, r8
stxdw [r6+0x10], r7
ja +0x122
jsgt r1, 0xb, +0x10
jsgt r1, 0x9, +0x66
jeq r1, 0x8, +0x83
mov64 r1, 0x9
ja +0x107
jsgt r1, 0x1c, +0x13
jsgt r1, 0x1a, +0x64
jeq r1, 0x19, +0x82
mov64 r1, 0x1a
stxb [r0+0x0], r1
mov64 r1, 0x1
stxdw [r6+0x10], r1
add64 r7, 0x8
mov64 r1, r7
mov64 r2, r6
call fn_7408
ja +0x111
jsgt r1, 0xd, +0x13
jeq r1, 0xc, +0x7d
ldxdw r1, [r7+0x8]
ldxb r2, [r7+0x10]
stxb [r0+0x9], r2
stxdw [r0+0x1], r1
mov64 r1, 0xd
ja +0xc4
jsgt r1, 0x1e, +0x2a
jeq r1, 0x1d, +0x7b
mov64 r1, 0x1e
ja +0xef
jsgt r1, 0x5, +0x50
jeq r1, 0x4, +0x93
mov64 r1, 0x5
ja +0xeb
jsgt r1, 0x16, +0x51
jeq r1, 0x15, +0x93
mov64 r1, 0x16
ja +0xe7
jeq r1, 0xe, +0xac
jeq r1, 0xf, +0xb1
ldxdw r1, [r7+0x20]
stxdw [r10-0x8], r1
ldxdw r1, [r7+0x18]
stxdw [r10-0x10], r1
ldxdw r1, [r7+0x10]
stxdw [r10-0x18], r1
ldxdw r1, [r7+0x8]
stxdw [r10-0x20], r1
mov64 r1, 0x10
stxb [r0+0x0], r1
mov64 r1, 0x1
stxdw [r6+0x10], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r10
add64 r2, -0x20
call fn_c008
ldxdw r7, [r6+0x10]
ldxdw r1, [r6+0x8]
sub64 r1, r7
ldxdw r9, [r10-0x50]
ldxdw r8, [r10-0x48]
jge r1, r8, -0x46
mov64 r1, r6
mov64 r2, r7
mov64 r3, r8
call fn_6e50
ldxdw r7, [r6+0x10]
ja -0x4c
jeq r1, 0x1f, +0x9b
jeq r1, 0x20, +0x9c
mov64 r1, 0x21
ja +0xc4
jeq r1, 0x2, +0x9b
ldxdw r1, [r7+0x8]
stxdw [r0+0x1], r1
mov64 r1, 0x3
ja +0xd2
jeq r1, 0x13, +0x9b
ldxb r1, [r7+0x8]
stxb [r0+0x1], r1
mov64 r1, 0x14
stxb [r0+0x0], r1
mov64 r1, 0x2
stxdw [r6+0x10], r1
mov64 r2, r7
add64 r2, 0x9
mov64 r1, r10
add64 r1, -0x30
call fn_c008
add64 r7, 0x2c
ldxdw r8, [r6+0x10]
ldxdw r1, [r6+0x8]
sub64 r1, r8
ldxdw r2, [r10-0x30]
ldxdw r9, [r10-0x28]
jge r1, r9, +0x1
ja +0xa0
ldxdw r1, [r6+0x0]
add64 r1, r8
mov64 r3, r9
call fn_15878
add64 r8, r9
stxdw [r6+0x10], r8
ja +0xcd
jeq r1, 0xa, +0xa0
mov64 r1, 0xb
ja +0xa1
jeq r1, 0x1b, +0x9f
mov64 r1, 0x1c
ja +0x9e
jeq r1, 0x6, +0xa0
ldxdw r1, [r7+0x8]
stxdw [r0+0x1], r1
mov64 r1, 0x7
ja +0xac
jeq r1, 0x17, +0xa8
mov64 r1, 0x18
stxb [r0+0x0], r1
mov64 r8, 0x1
stxdw [r9+0x0], r8
ldxdw r2, [r7+0x8]
ldxdw r7, [r7+0x10]
mov64 r1, 0x60
jgt r1, r7, +0x1
ja +0xbc
add64 r0, r8
mov64 r1, r0
mov64 r3, r7
call fn_15878
add64 r8, r7
stxdw [r9+0x0], r8
ja +0x9e
mov64 r1, 0x11
ja +0x86
ldxdw r1, [r7+0x8]
stxdw [r0+0x1], r1
mov64 r1, 0x8
ja +0x95
mov64 r1, 0x19
stxb [r0+0x0], r1
mov64 r1, 0x1
stxdw [r6+0x10], r1
add64 r7, 0x8
ja +0xa5
ldxdw r1, [r7+0x8]
ldxb r2, [r7+0x10]
stxb [r0+0x9], r2
stxdw [r0+0x1], r1
mov64 r1, 0xc
ja +0x47
mov64 r1, 0x1d
stxb [r0+0x0], r1
mov64 r2, 0x1
stxdw [r6+0x10], r2
ldxdw r8, [r7+0x18]
jeq r8, 0x0, +0x86
ldxdw r7, [r7+0x8]
mov64 r1, 0x60
lsh64 r8, 0x1
add64 r8, -0x2
ja +0x9
ldxdw r1, [r6+0x0]
add64 r1, r2
stxh [r1+0x0], r9
add64 r2, 0x2
stxdw [r6+0x10], r2
jeq r8, 0x0, +0x7b
add64 r7, 0x2
add64 r8, -0x2
ldxdw r1, [r6+0x8]
sub64 r1, r2
ldxh r9, [r7+0x0]
jgt r1, 0x1, -0xc
mov64 r1, r6
mov64 r3, 0x2
call fn_6e50
ldxdw r2, [r6+0x10]
ja -0x11
ldxdw r1, [r7+0x8]
stxdw [r0+0x1], r1
mov64 r1, 0x4
ja +0x69
mov64 r1, 0x15
stxb [r0+0x0], r1
mov64 r2, 0x1
stxdw [r6+0x10], r2
ldxdw r8, [r7+0x18]
jeq r8, 0x0, +0x66
ldxdw r7, [r7+0x8]
mov64 r1, 0x60
lsh64 r8, 0x1
add64 r8, -0x2
ja +0x9
ldxdw r1, [r6+0x0]
add64 r1, r2
stxh [r1+0x0], r9
add64 r2, 0x2
stxdw [r6+0x10], r2
jeq r8, 0x0, +0x5b
add64 r7, 0x2
add64 r8, -0x2
ldxdw r1, [r6+0x8]
sub64 r1, r2
ldxh r9, [r7+0x0]
jgt r1, 0x1, -0xc
mov64 r1, r6
mov64 r3, 0x2
call fn_6e50
ldxdw r2, [r6+0x10]
ja -0x11
ldxdw r1, [r7+0x8]
ldxb r2, [r7+0x10]
stxb [r0+0x9], r2
stxdw [r0+0x1], r1
mov64 r1, 0xe
ja +0x5
ldxdw r1, [r7+0x8]
ldxb r2, [r7+0x10]
stxb [r0+0x9], r2
stxdw [r0+0x1], r1
mov64 r1, 0xf
stxb [r0+0x0], r1
mov64 r1, 0xa
ja +0x41
mov64 r1, 0x1f
ja +0x2a
mov64 r1, 0x20
ja +0x28
ldxb r1, [r7+0x8]
stxb [r0+0x1], r1
mov64 r1, 0x2
stxb [r0+0x0], r1
ja +0x38
ldxb r1, [r7+0x8]
stxb [r0+0x1], r1
mov64 r1, 0x13
stxb [r0+0x0], r1
mov64 r1, 0x2
ja +0x32
ldxb r1, [r7+0x8]
stxb [r0+0x1], r1
mov64 r1, 0x0
stxb [r0+0x0], r1
mov64 r1, 0x2
stxdw [r6+0x10], r1
mov64 r2, r7
add64 r2, 0x9
mov64 r1, r10
add64 r1, -0x60
call fn_c008
add64 r7, 0x2c
ldxdw r8, [r6+0x10]
ldxdw r1, [r6+0x8]
sub64 r1, r8
ldxdw r2, [r10-0x60]
ldxdw r9, [r10-0x58]
jge r1, r9, -0xa0
mov64 r1, r6
stxdw [r10-0x68], r2
mov64 r2, r8
mov64 r3, r9
call fn_6e50
ldxdw r2, [r10-0x68]
ldxdw r8, [r6+0x10]
ja -0xa8
mov64 r1, 0xa
ja +0x1
mov64 r1, 0x1b
stxb [r0+0x0], r1
mov64 r1, 0x1
ja +0x12
mov64 r1, 0x6
stxb [r0+0x0], r1
mov64 r1, 0x1
stxdw [r9+0x0], r1
ldxb r2, [r7+0x8]
add64 r7, 0xc
and64 r2, 0x7
jsgt r2, 0x3, +0xc
jsgt r2, 0x1, +0xf
mov64 r1, 0x0
jeq r2, 0x0, +0x18
mov64 r1, 0x1
ja +0x16
ldxdw r1, [r7+0x8]
stxdw [r0+0x1], r1
mov64 r1, 0x17
stxb [r0+0x0], r1
mov64 r1, 0x9
stxdw [r9+0x0], r1
exit
jsgt r2, 0x5, +0x6
jeq r2, 0x4, +0x8
mov64 r1, 0x5
ja +0xb
jeq r2, 0x2, +0x7
mov64 r1, 0x3
ja +0x8
jeq r2, 0x6, +0x6
mov64 r1, 0x7
ja +0x5
mov64 r1, 0x4
ja +0x3
mov64 r1, 0x2
ja +0x1
mov64 r1, 0x6
stxb [r0+0x1], r1
mov64 r1, 0x2
stxdw [r6+0x10], r1
mov64 r1, r7
mov64 r2, r6
call fn_85f8
ja -0x17
mov64 r1, r6
mov64 r8, r2
mov64 r2, 0x1
mov64 r3, r7
call fn_6e50
mov64 r2, r8
ldxdw r0, [r6+0x0]
ldxdw r8, [r6+0x10]
ja -0xc5
fn_85f8:
mov64 r6, r2
mov64 r8, r1
ldxw r1, [r8+0x0]
jeq r1, 0x1, +0xd
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_7168
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
mov64 r3, 0x0
stxb [r1+0x0], r3
add64 r2, 0x1
stxdw [r6+0x10], r2
ja +0x32
add64 r8, 0x4
ldxdw r1, [r6+0x8]
ldxdw r7, [r6+0x10]
jne r7, r1, +0x5
mov64 r1, r6
mov64 r2, r7
call fn_7168
ldxdw r1, [r6+0x8]
ldxdw r7, [r6+0x10]
stxdw [r10-0x48], r1
ldxdw r9, [r6+0x0]
mov64 r1, r9
add64 r1, r7
mov64 r2, 0x1
stxb [r1+0x0], r2
add64 r7, 0x1
stxdw [r6+0x10], r7
ldxdw r1, [r8+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r8+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r8+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r8+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x20
call fn_c070
ldxdw r1, [r10-0x48]
sub64 r1, r7
jgt r1, 0x1f, +0x6
mov64 r1, r6
mov64 r2, r7
mov64 r3, 0x20
call fn_6e50
ldxdw r9, [r6+0x0]
ldxdw r7, [r6+0x10]
add64 r9, r7
ldxdw r1, [r10-0x28]
stxdw [r9+0x18], r1
ldxdw r1, [r10-0x30]
stxdw [r9+0x10], r1
ldxdw r1, [r10-0x38]
stxdw [r9+0x8], r1
ldxdw r1, [r10-0x40]
stxdw [r9+0x0], r1
add64 r7, 0x20
stxdw [r6+0x10], r7
exit
fn_8818:
mov64 r8, r5
stxdw [r10-0xc8], r4
mov64 r9, r3
mov64 r7, r2
mov64 r6, r1
mov64 r1, r7
lddw r2, 0x16dd7
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xd
stxdw [r10-0xd0], r9
mov64 r9, r10
add64 r9, -0xa8
mov64 r1, r9
call fn_b160
mov64 r1, r7
mov64 r2, r9
ldxdw r9, [r10-0xd0]
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, +0x61
ldxdw r1, [r8+0x18]
stxdw [r10-0x88], r1
ldxdw r1, [r8+0x10]
stxdw [r10-0x90], r1
ldxdw r1, [r8+0x8]
stxdw [r10-0x98], r1
ldxdw r1, [r8+0x0]
stxdw [r10-0xa0], r1
mov64 r1, 0x12
stxw [r10-0xa8], r1
mov64 r1, r10
add64 r1, -0xc0
mov64 r2, r10
add64 r2, -0xa8
call fn_79f8
ldxw r1, [r10-0xa8]
jeq r1, 0x15, +0x55
jeq r1, 0x1d, +0x1
ja +0x6
ldxdw r2, [r10-0x98]
jeq r2, 0x0, +0x4
ldxdw r1, [r10-0xa0]
jeq r1, 0x0, +0x2
lsh64 r2, 0x1
jne r2, 0x0, +0x53
stxdw [r10-0xd0], r7
mov64 r1, 0x44
mov64 r2, 0x1
call fn_6e00
mov64 r8, r0
jne r8, 0x0, +0x4
mov64 r1, 0x44
mov64 r2, 0x1
call fn_f740
fn_89f8:
call fn_89f8
ldxdw r1, [r9+0x18]
stxdw [r10-0x90], r1
ldxdw r1, [r9+0x10]
stxdw [r10-0x98], r1
ldxdw r1, [r9+0x8]
stxdw [r10-0xa0], r1
ldxdw r1, [r9+0x0]
stxdw [r10-0xa8], r1
mov64 r9, r10
add64 r9, -0x48
mov64 r2, r10
add64 r2, -0xa8
mov64 r1, r9
mov64 r3, 0x0
call fn_d9c8
ldxdw r2, [r10-0xc8]
ldxdw r1, [r2+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x20], r1
mov64 r7, r10
add64 r7, -0xa8
mov64 r2, r10
add64 r2, -0x20
mov64 r1, r7
mov64 r3, 0x0
call fn_da28
mov64 r1, r8
mov64 r2, r9
mov64 r3, 0x22
call fn_15878
mov64 r1, r8
add64 r1, 0x22
mov64 r2, r7
mov64 r3, 0x22
call fn_15878
ldxdw r2, [r10-0xd0]
ldxdw r1, [r2+0x18]
stxdw [r6+0x50], r1
ldxdw r1, [r2+0x10]
stxdw [r6+0x48], r1
ldxdw r1, [r2+0x8]
stxdw [r6+0x40], r1
ldxdw r1, [r2+0x0]
stxdw [r6+0x38], r1
ldxdw r1, [r10-0xc0]
stxdw [r6+0x20], r1
ldxdw r1, [r10-0xb8]
stxdw [r6+0x28], r1
ldxdw r1, [r10-0xb0]
stxdw [r6+0x30], r1
mov64 r1, 0x2
stxdw [r6+0x18], r1
stxdw [r6+0x10], r1
stxdw [r6+0x8], r8
mov64 r1, 0x0
stxdw [r6+0x0], r1
ja +0x4
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, 0x6
stxw [r6+0x8], r1
exit
ldxdw r2, [r10-0x98]
jeq r2, 0x0, -0x4f
ldxdw r1, [r10-0xa0]
jeq r1, 0x0, -0x51
lsh64 r2, 0x1
jeq r2, 0x0, -0x53
mov64 r3, 0x2
call fn_6e10
ja -0x56
fn_8c60:
mov64 r7, r5
stxdw [r10-0xd0], r4
stxdw [r10-0xd8], r3
mov64 r9, r2
stxdw [r10-0xc0], r1
mov64 r1, r9
lddw r2, 0x16dd7
mov64 r3, 0x20
call fn_15aa8
ldxdw r6, [r7-0xff0]
ldxdw r8, [r7-0xff8]
ldxdw r1, [r7-0x1000]
stxdw [r10-0xc8], r1
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xb
mov64 r7, r10
add64 r7, -0x50
mov64 r1, r7
call fn_b160
mov64 r1, r9
mov64 r2, r7
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, +0x26
stxdw [r10-0xe0], r9
ldxdw r1, [r10-0xc0]
mov64 r1, r10
add64 r1, -0xa0
lddw r2, 0x16cf8
call fn_79f8
mov64 r2, r6
add64 r2, 0x3
mov64 r1, r10
add64 r1, -0xb0
stxdw [r10-0xb8], r2
mov64 r3, 0x0
mov64 r4, 0x22
mov64 r5, 0x0
call fn_16790
mov64 r9, 0x1
ldxdw r1, [r10-0xa8]
jne r1, 0x0, +0x1
mov64 r9, 0x0
xor64 r9, 0x1
mov64 r1, r9
and64 r1, 0x1
jne r1, 0x0, +0x2
call fn_f708
fn_8e08:
call fn_8e08
ldxdw r1, [r10-0xb0]
jeq r1, 0x0, +0x10
stxdw [r10-0xe8], r1
mov64 r2, r9
call fn_6e00
mov64 r7, r0
jeq r7, 0x0, +0x1
ja +0xb
ldxdw r1, [r10-0xe8]
mov64 r2, r9
call fn_f740
fn_8e68:
call fn_8e68
mov64 r1, 0x1
ldxdw r2, [r10-0xc0]
stxdw [r2+0x0], r1
mov64 r1, 0x6
stxw [r2+0x8], r1
ja +0xb5
mov64 r7, r9
stxdw [r10-0x88], r7
mov64 r9, 0x0
stxdw [r10-0x78], r9
ldxdw r1, [r10-0xb8]
stxdw [r10-0x80], r1
ldxdw r2, [r10-0xd8]
ldxdw r1, [r2+0x18]
stxdw [r10-0x58], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x60], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x68], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x70], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r10
add64 r2, -0x70
mov64 r3, 0x0
call fn_d9c8
ldxdw r1, [r10-0xb8]
jeq r1, 0x0, +0x1
ja +0x8
mov64 r1, r10
add64 r1, -0x88
mov64 r2, 0x0
call fn_6fb0
ldxdw r1, [r10-0x80]
stxdw [r10-0xb8], r1
ldxdw r7, [r10-0x88]
ldxdw r9, [r10-0x78]
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x50
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x78], r9
ldxdw r2, [r10-0xd0]
ldxdw r1, [r2+0x18]
stxdw [r10-0x58], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x60], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x68], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x70], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r10
add64 r2, -0x70
mov64 r3, 0x0
call fn_d9c8
ldxdw r2, [r10-0xb8]
jne r9, r2, +0x6
mov64 r1, r10
add64 r1, -0x88
call fn_6fb0
ldxdw r2, [r10-0x80]
ldxdw r7, [r10-0x88]
ldxdw r9, [r10-0x78]
stxdw [r10-0xb8], r2
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x50
mov64 r3, 0x22
call fn_15878
mov64 r3, 0x1
jeq r6, 0x0, +0x1
mov64 r3, 0x0
add64 r9, 0x1
stxdw [r10-0x78], r9
ldxdw r2, [r10-0xc8]
ldxdw r1, [r2+0x18]
stxdw [r10-0x58], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x60], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x68], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x70], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r10
add64 r2, -0x70
call fn_da28
ldxdw r2, [r10-0xb8]
jne r9, r2, +0x5
mov64 r1, r10
add64 r1, -0x88
call fn_6fb0
ldxdw r7, [r10-0x88]
ldxdw r9, [r10-0x78]
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x50
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x78], r9
jeq r6, 0x0, +0x28
lsh64 r6, 0x3
ja +0xd
add64 r8, 0x8
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x50
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x78], r9
add64 r6, -0x8
jeq r6, 0x0, +0x19
ldxdw r1, [r8+0x0]
ldxdw r2, [r1+0x18]
stxdw [r10-0x58], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x60], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x68], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x70], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r10
add64 r2, -0x70
mov64 r3, 0x1
call fn_da28
ldxdw r1, [r10-0x80]
jeq r9, r1, +0x1
ja -0x1f
mov64 r1, r10
add64 r1, -0x88
mov64 r2, r9
call fn_6fb0
ldxdw r7, [r10-0x88]
ldxdw r9, [r10-0x78]
ja -0x26
ldxdw r2, [r10-0xe0]
ldxdw r1, [r2+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x20], r1
ldxdw r1, [r10-0x88]
stxdw [r10-0x50], r1
ldxdw r1, [r10-0x80]
stxdw [r10-0x48], r1
ldxdw r1, [r10-0x78]
stxdw [r10-0x40], r1
ldxdw r1, [r10-0xa0]
stxdw [r10-0x38], r1
ldxdw r1, [r10-0x98]
stxdw [r10-0x30], r1
ldxdw r1, [r10-0x90]
stxdw [r10-0x28], r1
ldxdw r6, [r10-0xc0]
mov64 r1, r6
add64 r1, 0x8
mov64 r2, r10
add64 r2, -0x50
mov64 r3, 0x50
call fn_15878
mov64 r1, 0x0
stxdw [r6+0x0], r1
exit
fn_9450:
mov64 r7, r5
stxdw [r10-0xe8], r4
stxdw [r10-0xf0], r3
mov64 r9, r2
stxdw [r10-0xd0], r1
mov64 r1, r9
lddw r2, 0x16dd7
mov64 r3, 0x20
call fn_15aa8
ldxdw r3, [r7-0xfd8]
ldxdw r2, [r7-0xfe0]
ldxdw r6, [r7-0xfe8]
ldxdw r8, [r7-0xff0]
ldxdw r1, [r7-0xff8]
stxdw [r10-0xd8], r1
ldxdw r1, [r7-0x1000]
stxdw [r10-0xe0], r1
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xf
mov64 r7, r10
add64 r7, -0x98
mov64 r1, r7
stxdw [r10-0xc8], r2
stxdw [r10-0xf8], r3
call fn_b160
mov64 r1, r9
mov64 r2, r7
mov64 r3, 0x20
call fn_15aa8
ldxdw r3, [r10-0xf8]
ldxdw r2, [r10-0xc8]
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, +0x33
stxdw [r10-0xf8], r9
stxb [r10-0x88], r3
stxdw [r10-0x90], r2
mov64 r1, 0xc
stxw [r10-0x98], r1
mov64 r1, r10
add64 r1, -0xb0
mov64 r2, r10
add64 r2, -0x98
call fn_79f8
ldxw r1, [r10-0x98]
jeq r1, 0x15, +0x105
jeq r1, 0x1d, +0x1
ja +0x6
ldxdw r2, [r10-0x88]
jeq r2, 0x0, +0x4
ldxdw r1, [r10-0x90]
jeq r1, 0x0, +0x2
lsh64 r2, 0x1
jne r2, 0x0, +0x103
mov64 r2, r6
add64 r2, 0x4
mov64 r1, r10
add64 r1, -0xc0
stxdw [r10-0xc8], r2
mov64 r3, 0x0
mov64 r4, 0x22
mov64 r5, 0x0
call fn_16790
mov64 r9, 0x1
ldxdw r1, [r10-0xb8]
jne r1, 0x0, +0x1
mov64 r9, 0x0
xor64 r9, 0x1
mov64 r1, r9
and64 r1, 0x1
jne r1, 0x0, +0x2
call fn_f708
fn_96a0:
call fn_96a0
ldxdw r1, [r10-0xc0]
jeq r1, 0x0, +0x10
stxdw [r10-0x100], r1
mov64 r2, r9
call fn_6e00
mov64 r7, r0
jeq r7, 0x0, +0x1
ja +0xb
ldxdw r1, [r10-0x100]
mov64 r2, r9
call fn_f740
fn_9700:
call fn_9700
mov64 r1, 0x1
ldxdw r2, [r10-0xd0]
stxdw [r2+0x0], r1
mov64 r1, 0x6
stxw [r2+0x8], r1
ja +0xd7
mov64 r7, r9
stxdw [r10-0x38], r7
mov64 r9, 0x0
stxdw [r10-0x28], r9
ldxdw r1, [r10-0xc8]
stxdw [r10-0x30], r1
ldxdw r2, [r10-0xf0]
ldxdw r1, [r2+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x98
mov64 r2, r10
add64 r2, -0x20
mov64 r3, 0x0
call fn_d9c8
ldxdw r1, [r10-0xc8]
jeq r1, 0x0, +0x1
ja +0x8
mov64 r1, r10
add64 r1, -0x38
mov64 r2, 0x0
call fn_6fb0
ldxdw r1, [r10-0x30]
stxdw [r10-0xc8], r1
ldxdw r7, [r10-0x38]
ldxdw r9, [r10-0x28]
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x98
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x28], r9
ldxdw r2, [r10-0xe8]
ldxdw r1, [r2+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x98
mov64 r2, r10
add64 r2, -0x20
mov64 r3, 0x0
call fn_da28
ldxdw r2, [r10-0xc8]
jne r9, r2, +0x6
mov64 r1, r10
add64 r1, -0x38
call fn_6fb0
ldxdw r2, [r10-0x30]
ldxdw r7, [r10-0x38]
ldxdw r9, [r10-0x28]
stxdw [r10-0xc8], r2
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x98
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x28], r9
ldxdw r2, [r10-0xe0]
ldxdw r1, [r2+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x98
mov64 r2, r10
add64 r2, -0x20
mov64 r3, 0x0
call fn_d9c8
ldxdw r2, [r10-0xc8]
jne r9, r2, +0x6
mov64 r1, r10
add64 r1, -0x38
call fn_6fb0
ldxdw r2, [r10-0x30]
ldxdw r7, [r10-0x38]
ldxdw r9, [r10-0x28]
stxdw [r10-0xc8], r2
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x98
mov64 r3, 0x22
call fn_15878
mov64 r3, 0x1
jeq r6, 0x0, +0x1
mov64 r3, 0x0
add64 r9, 0x1
stxdw [r10-0x28], r9
ldxdw r2, [r10-0xd8]
ldxdw r1, [r2+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x98
mov64 r2, r10
add64 r2, -0x20
call fn_da28
ldxdw r2, [r10-0xc8]
jne r9, r2, +0x5
mov64 r1, r10
add64 r1, -0x38
call fn_6fb0
ldxdw r7, [r10-0x38]
ldxdw r9, [r10-0x28]
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x98
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x28], r9
jeq r6, 0x0, +0x28
lsh64 r6, 0x3
ja +0xd
add64 r8, 0x8
mov64 r2, r9
mul64 r2, 0x22
mov64 r1, r7
add64 r1, r2
mov64 r2, r10
add64 r2, -0x98
mov64 r3, 0x22
call fn_15878
add64 r9, 0x1
stxdw [r10-0x28], r9
add64 r6, -0x8
jeq r6, 0x0, +0x19
ldxdw r1, [r8+0x0]
ldxdw r2, [r1+0x18]
stxdw [r10-0x8], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x10], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x18], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x98
mov64 r2, r10
add64 r2, -0x20
mov64 r3, 0x1
call fn_da28
ldxdw r1, [r10-0x30]
jeq r9, r1, +0x1
ja -0x1f
mov64 r1, r10
add64 r1, -0x38
mov64 r2, r9
call fn_6fb0
ldxdw r7, [r10-0x38]
ldxdw r9, [r10-0x28]
ja -0x26
ldxdw r2, [r10-0xf8]
ldxdw r1, [r2+0x18]
stxdw [r10-0x50], r1
ldxdw r1, [r2+0x10]
stxdw [r10-0x58], r1
ldxdw r1, [r2+0x8]
stxdw [r10-0x60], r1
ldxdw r1, [r2+0x0]
stxdw [r10-0x68], r1
ldxdw r1, [r10-0x38]
stxdw [r10-0x98], r1
ldxdw r1, [r10-0x30]
stxdw [r10-0x90], r1
ldxdw r1, [r10-0x28]
stxdw [r10-0x88], r1
ldxdw r1, [r10-0xb0]
stxdw [r10-0x80], r1
ldxdw r1, [r10-0xa8]
stxdw [r10-0x78], r1
ldxdw r1, [r10-0xa0]
stxdw [r10-0x70], r1
ldxdw r6, [r10-0xd0]
mov64 r1, r6
add64 r1, 0x8
mov64 r2, r10
add64 r2, -0x98
mov64 r3, 0x50
call fn_15878
mov64 r1, 0x0
stxdw [r6+0x0], r1
exit
ldxdw r2, [r10-0x88]
jeq r2, 0x0, -0xff
ldxdw r1, [r10-0x90]
jeq r1, 0x0, -0x101
lsh64 r2, 0x1
jeq r2, 0x0, -0x103
mov64 r3, 0x2
call fn_6e10
ja -0x106
fn_9e40:
stxdw [r10-0x88], r5
stxdw [r10-0x90], r4
mov64 r9, r3
mov64 r7, r2
mov64 r6, r1
mov64 r1, r7
lddw r2, 0x16dd7
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xb
mov64 r8, r10
add64 r8, -0x60
mov64 r1, r8
call fn_b160
mov64 r1, r7
mov64 r2, r8
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, +0x5a
stxdw [r10-0x98], r7
mov64 r1, 0x22
mov64 r2, 0x1
call fn_6e00
mov64 r7, r0
jne r7, 0x0, +0x4
mov64 r1, 0x22
mov64 r2, 0x1
call fn_f740
fn_9f48:
call fn_9f48
ldxdw r1, [r9+0x18]
stxdw [r10-0x68], r1
ldxdw r1, [r9+0x10]
stxdw [r10-0x70], r1
ldxdw r1, [r9+0x8]
stxdw [r10-0x78], r1
ldxdw r1, [r9+0x0]
stxdw [r10-0x80], r1
mov64 r8, r10
add64 r8, -0x60
mov64 r2, r10
add64 r2, -0x80
mov64 r9, 0x0
mov64 r1, r8
mov64 r3, 0x0
call fn_da28
mov64 r1, r7
mov64 r2, r8
mov64 r3, 0x22
call fn_15878
ldxdw r1, [r10-0x88]
mov64 r8, r1
add64 r8, r8
mov64 r2, 0x1
jgt r1, r8, +0x1
mov64 r2, 0x0
jne r2, 0x0, +0x1
mov64 r9, 0x2
jne r2, 0x1, +0x2
call fn_f708
fn_a040:
call fn_a040
jeq r8, 0x0, +0x6
mov64 r1, r8
mov64 r2, r9
call fn_6e00
mov64 r2, r9
mov64 r9, r0
jeq r9, 0x0, +0x38
ldxdw r8, [r10-0x88]
mov64 r3, r8
lsh64 r3, 0x1
mov64 r1, r9
ldxdw r2, [r10-0x90]
call fn_15878
stxdw [r10-0x48], r8
stxdw [r10-0x50], r8
stxdw [r10-0x58], r9
mov64 r1, 0x15
stxw [r10-0x60], r1
mov64 r1, r6
add64 r1, 0x20
mov64 r2, r10
add64 r2, -0x60
call fn_79f8
ldxdw r2, [r10-0x98]
ldxdw r1, [r2+0x18]
stxdw [r6+0x50], r1
ldxdw r1, [r2+0x10]
stxdw [r6+0x48], r1
ldxdw r1, [r2+0x8]
stxdw [r6+0x40], r1
ldxdw r1, [r2+0x0]
stxdw [r6+0x38], r1
mov64 r1, 0x1
stxdw [r6+0x18], r1
stxdw [r6+0x10], r1
stxdw [r6+0x8], r7
mov64 r1, 0x0
stxdw [r6+0x0], r1
ldxw r1, [r10-0x60]
jeq r1, 0x15, +0xe
jeq r1, 0x1d, +0x1
ja +0x6
ldxdw r2, [r10-0x50]
jeq r2, 0x0, +0x4
ldxdw r1, [r10-0x58]
jeq r1, 0x0, +0x2
lsh64 r2, 0x1
jne r2, 0x0, +0xc
ja +0xd
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, 0x6
stxw [r6+0x8], r1
ja +0x8
ldxdw r2, [r10-0x50]
jeq r2, 0x0, -0x8
ldxdw r1, [r10-0x58]
jeq r1, 0x0, -0xa
lsh64 r2, 0x1
jeq r2, 0x0, -0xc
mov64 r3, 0x2
call fn_6e10
exit
mov64 r1, r8
call fn_f740
fn_a250:
call fn_a250
fn_a258:
mov64 r8, r3
mov64 r7, r2
mov64 r6, r1
mov64 r1, r7
lddw r2, 0x16dd7
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jeq r0, 0x0, +0xb
mov64 r9, r10
add64 r9, -0x48
mov64 r1, r9
call fn_b160
mov64 r1, r7
mov64 r2, r9
mov64 r3, 0x20
call fn_15aa8
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, +0x2f
mov64 r1, 0x22
mov64 r2, 0x1
call fn_6e00
mov64 r9, r0
jne r9, 0x0, +0x4
mov64 r1, 0x22
mov64 r2, 0x1
call fn_f740
fn_a348:
call fn_a348
ldxdw r1, [r8+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r8+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r8+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r8+0x0]
stxdw [r10-0x20], r1
mov64 r8, r10
add64 r8, -0x48
mov64 r2, r10
add64 r2, -0x20
mov64 r1, r8
mov64 r3, 0x0
call fn_d9c8
mov64 r1, r9
mov64 r2, r8
mov64 r3, 0x22
call fn_15878
mov64 r1, r6
add64 r1, 0x20
lddw r2, 0x16d58
call fn_79f8
ldxdw r1, [r7+0x18]
stxdw [r6+0x50], r1
ldxdw r1, [r7+0x10]
stxdw [r6+0x48], r1
ldxdw r1, [r7+0x8]
stxdw [r6+0x40], r1
ldxdw r1, [r7+0x0]
stxdw [r6+0x38], r1
mov64 r1, 0x1
stxdw [r6+0x18], r1
stxdw [r6+0x10], r1
mov64 r1, 0x0
stxdw [r6+0x8], r9
ja +0x3
mov64 r1, 0x6
stxw [r6+0x8], r1
mov64 r1, 0x1
stxdw [r6+0x0], r1
exit
fn_a4a8:
ldxb r0, [r1+0x31]
exit
fn_a4b8:
mov64 r7, r2
mov64 r6, r1
jgt r3, 0x51, +0x6
mov64 r1, 0x52
mov64 r2, r3
lddw r3, 0x17bc8
call fn_12e60
fn_a4f8:
call fn_a4f8
ldxb r1, [r7+0x0]
jeq r1, 0x0, +0x12
jeq r1, 0x1, +0x31
mov64 r1, 0x3
stxw [r10-0x40], r1
ldxdw r1, [r10-0x38]
stxdw [r10-0x60], r1
ldxdw r2, [r10-0x30]
stxdw [r10-0x58], r2
ldxdw r3, [r10-0x28]
stxdw [r10-0x50], r3
ldxdw r4, [r10-0x40]
stxdw [r10-0x68], r4
stxdw [r6+0x20], r3
stxdw [r6+0x18], r2
stxdw [r6+0x10], r1
stxdw [r6+0x8], r4
mov64 r1, 0x1
stxdw [r6+0x0], r1
exit
ldxb r1, [r7+0x1]
jeq r1, 0x0, +0x1
ja -0x14
ldxb r1, [r7+0x2]
jne r1, 0x0, -0x16
mov64 r1, 0x0
ldxb r2, [r7+0x3]
jne r2, 0x0, -0x19
stxw [r10-0x44], r1
mov64 r8, r10
add64 r8, -0x6c
mov64 r2, r10
add64 r2, -0x44
mov64 r1, r8
mov64 r3, 0x24
call fn_15878
mov64 r1, r10
add64 r1, -0xb8
mov64 r2, r8
mov64 r3, 0x24
call fn_15878
mov64 r8, 0x0
ldxb r3, [r7+0x2c]
ldxdw r9, [r7+0x24]
ldxb r1, [r7+0x2d]
jeq r1, 0x0, +0x1e
jeq r1, 0x1, +0x1c
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, 0x3
stxw [r6+0x8], r1
ja -0x21
ldxb r1, [r7+0x1]
jne r1, 0x0, -0x33
ldxb r1, [r7+0x2]
jne r1, 0x0, -0x35
ldxb r1, [r7+0x3]
jne r1, 0x0, -0x37
mov64 r1, r7
add64 r1, 0x4
ldxdw r2, [r1+0x18]
stxdw [r10-0x78], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x80], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x88], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x90], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x90
call fn_c028
mov64 r1, 0x1
ja -0x2f
mov64 r8, 0x1
ldxb r1, [r7+0x2e]
jeq r1, 0x0, +0x2
jeq r1, 0x1, +0x2f
ja -0x4d
ldxb r1, [r7+0x2f]
jeq r1, 0x0, +0x1
ja -0x4
ldxb r1, [r7+0x30]
jne r1, 0x0, -0x6
mov64 r1, 0x0
ldxb r2, [r7+0x31]
jne r2, 0x0, -0x9
stxdw [r10-0xc0], r3
stxw [r10-0x44], r1
mov64 r7, r10
add64 r7, -0x6c
mov64 r2, r10
add64 r2, -0x44
mov64 r1, r7
mov64 r3, 0x24
call fn_15878
mov64 r1, r10
add64 r1, -0x90
stxdw [r10-0xc8], r1
mov64 r2, r7
mov64 r3, 0x24
call fn_15878
mov64 r1, r6
add64 r1, 0x8
mov64 r2, r10
add64 r2, -0xb8
mov64 r3, 0x24
call fn_15878
mov64 r1, r10
add64 r1, -0x46
ldxdw r2, [r10-0xc8]
mov64 r3, 0x24
call fn_15878
stxb [r6+0x39], r8
ldxdw r1, [r10-0xc0]
stxb [r6+0x38], r1
stxdw [r6+0x30], r9
mov64 r1, r6
add64 r1, 0x3a
mov64 r2, r10
add64 r2, -0x48
mov64 r3, 0x26
call fn_15878
mov64 r1, 0x0
ja -0x6c
ldxb r1, [r7+0x2f]
jne r1, 0x0, -0x31
ldxb r1, [r7+0x30]
jne r1, 0x0, -0x33
ldxb r1, [r7+0x31]
jne r1, 0x0, -0x35
add64 r7, 0x32
ldxdw r1, [r7+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r7+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r7+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r7+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x20
mov64 r7, r3
call fn_c028
mov64 r3, r7
mov64 r1, 0x1
ja -0x3e
fn_a9b0:
ldxb r1, [r1+0x6c]
mov64 r0, 0x1
jne r1, 0x0, +0x1
mov64 r0, 0x0
exit
fn_a9d8:
mov64 r7, r2
mov64 r6, r1
jgt r3, 0xa4, +0x6
mov64 r1, 0xa5
mov64 r2, r3
lddw r3, 0x17be0
call fn_12e60
fn_aa18:
call fn_aa18
ldxdw r1, [r7+0x18]
stxdw [r10-0x30], r1
ldxdw r1, [r7+0x10]
stxdw [r10-0x38], r1
ldxdw r1, [r7+0x8]
stxdw [r10-0x40], r1
ldxdw r1, [r7+0x0]
stxdw [r10-0x48], r1
mov64 r1, r10
add64 r1, -0xd8
mov64 r2, r10
add64 r2, -0x48
call fn_c028
ldxdw r1, [r7+0x38]
stxdw [r10-0x30], r1
ldxdw r1, [r7+0x30]
stxdw [r10-0x38], r1
ldxdw r1, [r7+0x28]
stxdw [r10-0x40], r1
ldxdw r1, [r7+0x20]
stxdw [r10-0x48], r1
mov64 r1, r10
add64 r1, -0xb8
mov64 r2, r10
add64 r2, -0x48
call fn_c028
ldxdw r8, [r7+0x40]
ldxb r1, [r7+0x48]
jeq r1, 0x0, +0x12
jeq r1, 0x1, +0x2d
mov64 r1, 0x3
stxw [r10-0x40], r1
ldxdw r1, [r10-0x38]
stxdw [r10-0x88], r1
ldxdw r2, [r10-0x30]
stxdw [r10-0x80], r2
ldxdw r3, [r10-0x28]
stxdw [r10-0x78], r3
ldxdw r4, [r10-0x40]
stxdw [r10-0x90], r4
stxdw [r6+0x20], r3
stxdw [r6+0x18], r2
stxdw [r6+0x10], r1
stxdw [r6+0x8], r4
mov64 r1, 0x1
stxdw [r6+0x0], r1
exit
ldxb r1, [r7+0x49]
jeq r1, 0x0, +0x1
ja -0x14
ldxb r1, [r7+0x4a]
jne r1, 0x0, -0x16
mov64 r1, 0x0
ldxb r2, [r7+0x4b]
jne r2, 0x0, -0x19
stxw [r10-0x44], r1
mov64 r1, r10
add64 r1, -0x94
mov64 r2, r10
add64 r2, -0x44
mov64 r3, 0x24
call fn_15878
ldxb r9, [r7+0x6c]
mov64 r1, 0x3
jgt r1, r9, +0x1
ja +0x20
ldxb r1, [r7+0x6d]
jeq r1, 0x1, +0x22
jne r1, 0x0, +0x2
ldxb r1, [r7+0x6e]
jeq r1, 0x0, +0x28
mov64 r1, 0x1
stxdw [r6+0x0], r1
mov64 r1, 0x3
ja +0x19
ldxb r1, [r7+0x49]
jne r1, 0x0, -0x2f
ldxb r1, [r7+0x4a]
jne r1, 0x0, -0x31
ldxb r1, [r7+0x4b]
jne r1, 0x0, -0x33
mov64 r1, r7
add64 r1, 0x4c
ldxdw r2, [r1+0x18]
stxdw [r10-0x58], r2
ldxdw r2, [r1+0x10]
stxdw [r10-0x60], r2
ldxdw r2, [r1+0x8]
stxdw [r10-0x68], r2
ldxdw r1, [r1+0x0]
stxdw [r10-0x70], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x70
call fn_c028
mov64 r1, 0x1
ja -0x2b
mov64 r2, 0x1
stxdw [r6+0x0], r2
stxw [r6+0x8], r1
ja -0x38
ldxb r1, [r7+0x6e]
jne r1, 0x0, -0x21
ldxb r1, [r7+0x6f]
jne r1, 0x0, -0x23
ldxb r1, [r7+0x70]
jne r1, 0x0, -0x25
mov64 r3, 0x1
ldxdw r4, [r7+0x71]
ja +0x6
ldxb r1, [r7+0x6f]
jne r1, 0x0, -0x2a
mov64 r3, 0x0
ldxb r1, [r7+0x70]
jeq r1, 0x0, +0x1
ja -0x2e
ldxdw r5, [r7+0x79]
ldxb r1, [r7+0x81]
jeq r1, 0x0, +0xc
jeq r1, 0x1, +0x14
mov64 r1, 0x3
stxw [r10-0x40], r1
ldxdw r1, [r10-0x38]
stxdw [r10-0x64], r1
ldxdw r2, [r10-0x30]
stxdw [r10-0x5c], r2
ldxdw r3, [r10-0x28]
stxdw [r10-0x54], r3
ldxdw r4, [r10-0x40]
stxdw [r10-0x6c], r4
ja -0x5c
ldxb r1, [r7+0x82]
jeq r1, 0x0, +0x1
ja -0xe
ldxb r1, [r7+0x83]
jne r1, 0x0, -0x10
mov64 r1, 0x0
ldxb r2, [r7+0x84]
jeq r2, 0x0, +0x1c
ja -0x14
ldxb r1, [r7+0x82]
jne r1, 0x0, -0x16
ldxb r1, [r7+0x83]
jne r1, 0x0, -0x18
ldxb r1, [r7+0x84]
jne r1, 0x0, -0x1a
add64 r7, 0x85
ldxdw r1, [r7+0x18]
stxdw [r10-0x8], r1
ldxdw r1, [r7+0x10]
stxdw [r10-0x10], r1
ldxdw r1, [r7+0x8]
stxdw [r10-0x18], r1
ldxdw r1, [r7+0x0]
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r10
add64 r2, -0x20
stxdw [r10-0x120], r3
mov64 r7, r4
stxdw [r10-0x128], r5
call fn_c028
ldxdw r5, [r10-0x128]
mov64 r4, r7
ldxdw r3, [r10-0x120]
mov64 r1, 0x1
stxdw [r10-0x128], r5
stxdw [r10-0x130], r4
stxdw [r10-0x120], r3
stxw [r10-0x44], r1
mov64 r7, r10
add64 r7, -0x70
mov64 r2, r10
add64 r2, -0x44
mov64 r1, r7
mov64 r3, 0x24
call fn_15878
mov64 r1, r6
add64 r1, 0x90
mov64 r2, r7
mov64 r3, 0x24
call fn_15878
ldxdw r1, [r10-0xd8]
stxdw [r10-0x118], r1
ldxdw r1, [r10-0xd0]
stxdw [r10-0x110], r1
ldxdw r1, [r10-0xc8]
stxdw [r10-0x108], r1
ldxdw r1, [r10-0xc0]
stxdw [r10-0x100], r1
ldxdw r1, [r10-0xb8]
stxdw [r10-0xf8], r1
ldxdw r1, [r10-0xb0]
stxdw [r10-0xf0], r1
ldxdw r1, [r10-0xa8]
stxdw [r10-0xe8], r1
ldxdw r1, [r10-0xa0]
stxdw [r10-0xe0], r1
mov64 r1, r6
add64 r1, 0x50
mov64 r2, r10
add64 r2, -0x94
mov64 r3, 0x24
call fn_15878
mov64 r1, r6
add64 r1, 0x8
mov64 r2, r10
add64 r2, -0x118
mov64 r3, 0x40
call fn_15878
ldxdw r1, [r10-0x128]
stxdw [r6+0x88], r1
ldxdw r1, [r10-0x130]
stxdw [r6+0x80], r1
ldxdw r1, [r10-0x120]
stxw [r6+0x78], r1
stxb [r6+0x74], r9
stxdw [r6+0x48], r8
mov64 r1, 0x0
ja -0xb1
fn_b110:
mov64 r4, r2
and64 r4, 0xff
jeq r4, 0x2, +0x3
jeq r4, 0x1, +0x2
mov64 r3, 0x1
jne r4, 0x0, +0x1
mov64 r3, 0x0
stxb [r1+0x1], r2
stxb [r1+0x0], r3
exit
fn_b160:
lddw r2, -0x56ff00817a0a73c6
stxdw [r1+0x18], r2
lddw r2, -0x6ec8a4a0127a4be4
stxdw [r1+0x10], r2
lddw r2, -0x53861431b91e3427
stxdw [r1+0x8], r2
lddw r2, -0x6c5e9a281e0922fa
stxdw [r1+0x0], r2
exit
exit
fn_b1d0:
ldxb r2, [r1+0x0]
jsgt r2, 0x9, +0x8
jeq r2, 0x3, +0x14
jeq r2, 0x9, +0x1
ja +0x7
ldxdw r2, [r1+0x50]
jeq r2, 0x0, +0x5
ldxdw r1, [r1+0x48]
jeq r1, 0x0, +0x3
ja +0x11
jeq r2, 0xa, +0x2
jeq r2, 0xb, +0x6
exit
ldxdw r2, [r1+0x50]
jeq r2, 0x0, -0x3
ldxdw r1, [r1+0x48]
jeq r1, 0x0, -0x5
ja +0x9
ldxdw r2, [r1+0x38]
jeq r2, 0x0, -0x8
ldxdw r1, [r1+0x30]
jeq r1, 0x0, -0xa
ja +0x4
ldxdw r2, [r1+0x50]
jeq r2, 0x0, -0xd
ldxdw r1, [r1+0x48]
jeq r1, 0x0, -0xf
mov64 r3, 0x1
call fn_6e10
ja -0x12
fn_b2c0:
ldxdw r1, [r1+0x8]
ldxdw r2, [r1+0x10]
lddw r3, 0x7fffffffffffffff
jgt r3, r2, +0xb
mov64 r3, r10
add64 r3, -0x8
lddw r1, 0x16e60
mov64 r2, 0x18
lddw r4, 0x17c50
lddw r5, 0x17bf8
call fn_10a58
fn_b338:
call fn_b338
mov64 r3, r2
add64 r3, 0x1
stxdw [r1+0x10], r3
ldxdw r3, [r1+0x18]
ldxdw r0, [r3+0x0]
stxdw [r1+0x10], r2
exit
fn_b378:
mov64 r6, r1
mov64 r4, r2
add64 r4, r3
mov64 r1, 0x1
jgt r2, r4, +0x1
mov64 r1, 0x0
and64 r1, 0x1
jne r1, 0x0, +0x1b
ldxdw r1, [r6+0x8]
mov64 r7, r1
lsh64 r7, 0x1
jgt r7, r4, +0x1
mov64 r7, r4
jgt r7, 0x8, +0x1
mov64 r7, 0x8
jeq r1, 0x0, +0x6
ldxdw r2, [r6+0x0]
mov64 r3, 0x1
stxdw [r10-0x8], r3
stxdw [r10-0x10], r1
stxdw [r10-0x18], r2
ja +0x2
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
mov64 r2, r7
mov64 r3, 0x1
call fn_b6a8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_b498:
call fn_b498
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_b4d0:
call fn_b4d0
fn_b4d8:
mov64 r6, r1
mov64 r1, r2
add64 r1, 0x1
mov64 r3, 0x1
jgt r2, r1, +0x1
mov64 r3, 0x0
and64 r3, 0x1
jne r3, 0x0, +0x29
ldxdw r9, [r6+0x8]
mov64 r7, r9
lsh64 r7, 0x1
jgt r7, r1, +0x1
mov64 r7, r1
jgt r7, 0x4, +0x1
mov64 r7, 0x4
mov64 r1, r10
add64 r1, -0x40
mov64 r8, 0x0
mov64 r2, r7
mov64 r3, 0x0
mov64 r4, 0x30
mov64 r5, 0x0
call fn_16790
mov64 r1, 0x1
ldxdw r2, [r10-0x38]
jne r2, 0x0, +0x1
mov64 r1, 0x0
jne r1, 0x0, +0x1
mov64 r8, 0x8
ldxdw r2, [r10-0x40]
jeq r9, 0x0, +0x6
ldxdw r1, [r6+0x0]
mov64 r3, 0x8
stxdw [r10-0x8], r3
mul64 r9, 0x30
stxdw [r10-0x10], r9
ja +0x1
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
mov64 r3, r8
call fn_b6a8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_b668:
call fn_b668
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_b6a0:
call fn_b6a0
fn_b6a8:
mov64 r8, r3
mov64 r7, r2
mov64 r6, r1
jne r8, 0x0, +0x4
stxdw [r6+0x8], r7
mov64 r1, 0x1
mov64 r7, 0x0
ja +0x1d
ldxdw r1, [r4+0x0]
jeq r1, 0x0, +0xd
ldxdw r2, [r4+0x8]
jne r2, 0x0, +0x6
jeq r7, 0x0, +0x14
mov64 r1, r7
mov64 r2, r8
call fn_6e00
jeq r0, 0x0, +0xc
ja +0x11
mov64 r3, r8
mov64 r4, r7
call fn_6e20
jeq r0, 0x0, +0x7
ja +0xc
jeq r7, 0x0, +0x9
mov64 r1, r7
mov64 r2, r8
call fn_6e00
jeq r0, 0x0, +0x1
ja +0x6
stxdw [r6+0x8], r7
mov64 r1, 0x1
mov64 r7, r8
ja +0x4
mov64 r7, 0x0
mov64 r0, r8
stxdw [r6+0x8], r0
mov64 r1, 0x0
stxdw [r6+0x0], r1
stxdw [r6+0x10], r7
exit
fn_b7e8:
mov64 r6, r1
stxdw [r10-0x40], r2
ldxdw r2, [r2+0x0]
mov64 r1, r10
add64 r1, -0x30
mov64 r7, 0x0
stxdw [r10-0x68], r2
mov64 r3, 0x0
mov64 r4, 0x30
mov64 r5, 0x0
call fn_16790
mov64 r1, 0x1
ldxdw r2, [r10-0x28]
jne r2, 0x0, +0x1
mov64 r1, 0x0
jne r1, 0x0, +0x1
mov64 r7, 0x8
jeq r1, 0x0, +0x2
call fn_f708
fn_b880:
call fn_b880
ldxdw r8, [r10-0x30]
stxdw [r10-0x80], r6
jeq r8, 0x0, +0xa
mov64 r1, r8
mov64 r2, r7
call fn_6e00
ldxdw r3, [r10-0x40]
jeq r0, 0x0, +0x1
ja +0x6
mov64 r1, r8
mov64 r2, r7
call fn_f740
fn_b8e8:
call fn_b8e8
mov64 r0, r7
ldxdw r3, [r10-0x40]
mov64 r1, 0x0
stxdw [r10-0x10], r1
stxdw [r10-0x20], r0
mov64 r9, 0x8
ldxdw r1, [r10-0x68]
stxdw [r10-0x18], r1
jeq r1, 0x0, +0x21
mov64 r9, 0x8
mov64 r7, r0
mov64 r2, 0x0
mov64 r4, 0x0
ja +0x2f
mov64 r1, r2
mul64 r1, 0x30
mov64 r3, r0
add64 r3, r1
stxb [r3+0x2a], r5
stxb [r3+0x29], r6
stxb [r3+0x28], r4
ldxdw r1, [r10-0x60]
stxdw [r3+0x20], r1
stxdw [r3+0x18], r7
stxdw [r3+0x10], r8
ldxdw r1, [r10-0x58]
stxdw [r3+0x8], r1
ldxdw r1, [r10-0x50]
stxdw [r3+0x0], r1
ldxw r1, [r10-0x5]
stxw [r3+0x2b], r1
ldxb r1, [r10-0x1]
stxb [r3+0x2f], r1
add64 r2, 0x1
stxdw [r10-0x10], r2
ldxdw r3, [r10-0x40]
ldxdw r4, [r10-0x38]
add64 r4, 0x1
add64 r9, 0x8
mov64 r7, r0
ldxdw r1, [r10-0x68]
jgt r1, r4, +0x13
mov64 r1, r3
add64 r1, r9
ldxdw r1, [r1+0x0]
ldxdw r2, [r10-0x10]
ldxdw r4, [r10-0x80]
stxdw [r4+0x18], r2
ldxdw r2, [r10-0x18]
stxdw [r4+0x10], r2
ldxdw r2, [r10-0x20]
stxdw [r4+0x8], r2
add64 r9, 0x8
mov64 r2, r3
add64 r2, r9
stxdw [r4+0x20], r2
stxdw [r4+0x28], r1
add64 r1, r9
add64 r3, r1
stxdw [r4+0x0], r3
exit
mov64 r1, r3
add64 r1, r9
ldxb r1, [r1+0x0]
stxdw [r10-0x38], r4
jeq r1, 0xff, +0x3b
jgt r2, r1, +0x4
lddw r3, 0x17c10
call fn_10918
fn_bb20:
call fn_bb20
stxdw [r10-0x48], r9
mul64 r1, 0x30
mov64 r4, r7
add64 r4, r1
ldxdw r6, [r4+0x8]
ldxdw r8, [r6+0x0]
add64 r8, 0x1
jgt r8, 0x1, +0x2
fn_bb68:
call fn_bb68
fn_bb70:
call fn_bb70
ldxb r5, [r4+0x29]
ldxb r3, [r4+0x28]
ldxdw r9, [r4+0x0]
stxdw [r10-0x50], r9
stxdw [r6+0x0], r8
ldxdw r8, [r4+0x10]
ldxdw r4, [r8+0x0]
add64 r4, 0x1
jgt r4, 0x1, +0x1
ja -0xc
stxdw [r10-0x58], r6
stxdw [r8+0x0], r4
mov64 r4, r5
mov64 r5, 0x1
mov64 r6, 0x1
jne r4, 0x0, +0x1
mov64 r6, 0x0
mov64 r4, 0x1
ldxdw r9, [r10-0x48]
jne r3, 0x0, +0x1
mov64 r4, 0x0
add64 r7, r1
ldxb r1, [r7+0x2a]
jne r1, 0x0, +0x1
mov64 r5, 0x0
ldxdw r1, [r7+0x20]
stxdw [r10-0x60], r1
ldxdw r7, [r7+0x18]
ldxdw r1, [r10-0x18]
jne r2, r1, -0x61
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x78], r7
mov64 r7, r5
stxdw [r10-0x70], r6
mov64 r6, r4
call fn_b4d8
mov64 r4, r6
ldxdw r6, [r10-0x70]
mov64 r5, r7
ldxdw r7, [r10-0x78]
ldxdw r0, [r10-0x20]
ldxdw r2, [r10-0x10]
ja -0x6f
stxdw [r10-0x48], r2
mov64 r6, r9
add64 r6, r3
ldxb r1, [r6+0x3]
stxdw [r10-0x60], r1
ldxb r1, [r6+0x2]
stxdw [r10-0x58], r1
ldxb r1, [r6+0x1]
stxdw [r10-0x50], r1
mov64 r1, 0x20
mov64 r2, 0x8
call fn_6e00
jne r0, 0x0, +0x2
mov64 r1, 0x20
ja +0x54
mov64 r1, 0x0
stxdw [r0+0x10], r1
mov64 r1, 0x1
stxdw [r0+0x8], r1
stxdw [r0+0x0], r1
mov64 r1, r6
add64 r1, 0x48
stxdw [r10-0x70], r0
stxdw [r0+0x18], r1
ldxdw r7, [r6+0x50]
stxw [r6+0x4], r7
mov64 r1, 0x28
mov64 r2, 0x8
call fn_6e00
mov64 r8, r0
jne r8, 0x0, +0x2
mov64 r1, 0x28
ja +0x42
ldxdw r1, [r10-0x60]
mov64 r3, r1
mov64 r4, 0x0
mov64 r1, 0x1
mov64 r5, 0x1
ldxdw r2, [r10-0x48]
jne r3, 0x0, +0x1
mov64 r5, 0x0
ldxdw r3, [r10-0x58]
stxdw [r8+0x10], r4
mov64 r4, 0x1
jne r3, 0x0, +0x1
mov64 r4, 0x0
ldxdw r3, [r10-0x50]
mov64 r0, 0x1
jne r3, 0x0, +0x1
mov64 r0, 0x0
stxdw [r10-0x58], r0
stxdw [r10-0x50], r4
mov64 r3, r6
add64 r3, 0x28
stxdw [r10-0x60], r3
add64 r6, 0x8
stxdw [r8+0x8], r1
stxdw [r8+0x0], r1
mov64 r1, r9
ldxdw r3, [r10-0x40]
add64 r1, r3
add64 r1, 0x58
stxdw [r8+0x18], r1
stxdw [r8+0x20], r7
add64 r9, r7
add64 r9, 0x285f
and64 r9, -0x8
mov64 r1, r3
add64 r1, r9
ldxdw r7, [r1+0x0]
ldxdw r1, [r10-0x18]
jne r2, r1, +0x7
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x48], r5
call fn_b4d8
ldxdw r5, [r10-0x48]
ldxdw r3, [r10-0x40]
ldxdw r2, [r10-0x10]
mov64 r1, r2
mul64 r1, 0x30
ldxdw r0, [r10-0x20]
mov64 r4, r0
add64 r4, r1
stxb [r4+0x2a], r5
ldxdw r1, [r10-0x50]
stxb [r4+0x29], r1
ldxdw r1, [r10-0x58]
stxb [r4+0x28], r1
stxdw [r4+0x20], r7
ldxdw r1, [r10-0x60]
stxdw [r4+0x18], r1
stxdw [r4+0x10], r8
ldxdw r1, [r10-0x70]
stxdw [r4+0x8], r1
stxdw [r4+0x0], r6
add64 r2, 0x1
stxdw [r10-0x10], r2
ja -0xbc
mov64 r2, 0x8
call fn_f740
fn_c000:
call fn_c000
fn_c008:
mov64 r3, 0x20
stxdw [r1+0x8], r3
stxdw [r1+0x0], r2
exit
fn_c028:
ldxdw r3, [r2+0x18]
stxdw [r1+0x18], r3
ldxdw r3, [r2+0x10]
stxdw [r1+0x10], r3
ldxdw r3, [r2+0x8]
stxdw [r1+0x8], r3
ldxdw r2, [r2+0x0]
stxdw [r1+0x0], r2
exit
fn_c070:
ldxdw r3, [r2+0x18]
stxdw [r1+0x18], r3
ldxdw r3, [r2+0x10]
stxdw [r1+0x10], r3
ldxdw r3, [r2+0x8]
stxdw [r1+0x8], r3
ldxdw r2, [r2+0x0]
stxdw [r1+0x0], r2
exit
fn_c0b8:
mov64 r7, r4
mov64 r9, r3
mov64 r6, r2
mov64 r8, r1
call fn_f150
ldxb r2, [r9+0x0]
stxdw [r10-0x20], r6
jsgt r2, 0x5, +0x6
jsgt r2, 0x2, +0xd
mov64 r6, 0x34
jeq r2, 0x0, +0x21
jeq r2, 0x1, +0xd
mov64 r6, 0xc
ja +0x1e
jsgt r2, 0x8, +0x3
jeq r2, 0x6, +0x9
jeq r2, 0x7, +0x8
ja -0x6
jsgt r2, 0xa, +0x8
jeq r2, 0x9, +0xa
mov64 r1, 0x4c
ja +0xb
jeq r2, 0x3, +0x9
jeq r2, 0x4, +0x4
ja -0xd
mov64 r6, 0x24
ja +0x11
jeq r2, 0xb, +0x8
mov64 r6, 0x4
ja +0xe
mov64 r1, 0x54
ja +0x1
mov64 r1, 0x5c
mov64 r3, r9
add64 r3, 0x58
ja +0x3
mov64 r1, 0x34
mov64 r3, r9
add64 r3, 0x40
ldxdw r6, [r3+0x0]
add64 r6, r1
mov64 r0, 0x1
mov64 r1, 0x0
jeq r6, 0x0, +0x6
mov64 r1, r6
mov64 r2, 0x1
call fn_6e00
jeq r0, 0x0, +0x2ee
ldxb r2, [r9+0x0]
mov64 r1, r6
mov64 r3, 0x0
stxdw [r10-0x8], r3
stxdw [r10-0x10], r1
stxdw [r10-0x18], r0
mov64 r3, r10
add64 r3, -0x10
stxdw [r10-0x28], r7
stxdw [r10-0x30], r8
stxdw [r10-0x38], r3
jsgt r2, 0x5, +0x11
jsgt r2, 0x2, +0x58
jeq r2, 0x0, +0x78
jeq r2, 0x1, +0xb2
mov64 r2, 0x0
jgt r1, 0x3, +0x1
ja +0x29c
add64 r0, r2
mov64 r1, 0x2
stxw [r0+0x0], r1
add64 r2, 0x4
stxdw [r10-0x8], r2
ldxdw r1, [r10-0x10]
sub64 r1, r2
ldxdw r6, [r9+0x8]
mov64 r3, 0x8
jgt r3, r1, +0x5d
ja +0x15
jsgt r2, 0x8, +0x19
jeq r2, 0x6, +0xc5
jeq r2, 0x7, +0xe7
mov64 r2, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
mov64 r1, 0x8
stxw [r0+0x0], r1
add64 r2, 0x4
stxdw [r10-0x8], r2
ldxdw r3, [r10-0x10]
sub64 r3, r2
ldxdw r6, [r9+0x8]
jgt r1, r3, +0x47
ldxdw r1, [r10-0x18]
add64 r1, r2
stxdw [r1+0x0], r6
add64 r2, 0x8
ja +0x18d
jsgt r2, 0xa, +0x47
stxdw [r10-0x40], r9
jeq r2, 0x9, +0xf0
mov64 r8, 0x0
mov64 r6, 0x0
jgt r1, 0x3, +0x1
ja +0x278
add64 r0, r6
mov64 r1, 0xa
stxw [r0+0x0], r1
add64 r9, 0x1
add64 r6, 0x4
stxdw [r10-0x8], r6
ja +0x14
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r7
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
jne r8, 0x20, +0xd
ldxdw r1, [r10-0x10]
sub64 r1, r6
ldxdw r9, [r10-0x40]
ldxdw r8, [r9+0x58]
ldxdw r7, [r9+0x48]
jgt r1, 0x7, +0x10b
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
ldxdw r6, [r10-0x8]
ja +0x104
mov64 r1, r9
add64 r1, r8
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0x19
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x20
jeq r2, 0x3, +0x11d
jeq r2, 0x4, +0x150
mov64 r2, 0x0
ldxdw r6, [r9+0x8]
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
mov64 r1, 0x5
stxw [r0+0x0], r1
add64 r2, 0x4
stxdw [r10-0x8], r2
ldxdw r1, [r10-0x10]
sub64 r1, r2
jgt r1, 0x7, -0x47
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x8
call fn_b378
ldxdw r2, [r10-0x8]
ja -0x4d
jeq r2, 0xb, +0x15e
mov64 r2, 0x0
jgt r1, 0x3, +0x1
ja +0x23b
add64 r0, r2
mov64 r1, 0xc
ja +0x13c
mov64 r6, 0x0
mov64 r2, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
stxw [r0+0x0], r6
add64 r2, 0x4
stxdw [r10-0x8], r2
ldxdw r1, [r10-0x10]
sub64 r1, r2
ldxdw r6, [r9+0x28]
mov64 r3, 0x8
jgt r3, r1, +0x22d
ldxdw r1, [r10-0x18]
add64 r1, r2
stxdw [r1+0x0], r6
add64 r2, 0x8
stxdw [r10-0x8], r2
ldxdw r1, [r10-0x10]
sub64 r1, r2
ldxdw r6, [r9+0x30]
jgt r1, 0x7, +0x5
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x8
call fn_b378
ldxdw r2, [r10-0x8]
ldxdw r1, [r10-0x18]
add64 r1, r2
stxdw [r1+0x0], r6
mov64 r6, 0x0
add64 r9, 0x1
add64 r2, 0x8
stxdw [r10-0x8], r2
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r2
stxb [r1+0x0], r7
add64 r2, 0x1
stxdw [r10-0x8], r2
add64 r6, 0x1
jeq r6, 0x20, +0x10f
mov64 r1, r9
add64 r1, r6
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r2, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x1
call fn_b378
ldxdw r2, [r10-0x8]
ja -0x12
mov64 r6, 0x0
mov64 r2, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
mov64 r1, 0x1
stxw [r0+0x0], r1
add64 r9, 0x1
add64 r2, 0x4
stxdw [r10-0x8], r2
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r2
stxb [r1+0x0], r7
add64 r2, 0x1
stxdw [r10-0x8], r2
add64 r6, 0x1
jeq r6, 0x20, +0xec
mov64 r1, r9
add64 r1, r6
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r2, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x1
call fn_b378
ldxdw r2, [r10-0x8]
ja -0x12
mov64 r6, 0x0
mov64 r2, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
mov64 r1, 0x6
stxw [r0+0x0], r1
add64 r9, 0x1
add64 r2, 0x4
stxdw [r10-0x8], r2
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r2
stxb [r1+0x0], r8
add64 r2, 0x1
stxdw [r10-0x8], r2
add64 r6, 0x1
jeq r6, 0x20, +0xc9
mov64 r1, r9
add64 r1, r6
ldxb r8, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r2, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x1
call fn_b378
ldxdw r2, [r10-0x8]
ja -0x12
mov64 r6, 0x0
mov64 r2, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
mov64 r1, 0x7
stxw [r0+0x0], r1
add64 r9, 0x1
add64 r2, 0x4
stxdw [r10-0x8], r2
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r2
stxb [r1+0x0], r8
add64 r2, 0x1
stxdw [r10-0x8], r2
add64 r6, 0x1
jeq r6, 0x20, +0xa6
mov64 r1, r9
add64 r1, r6
ldxb r8, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r2, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x1
call fn_b378
ldxdw r2, [r10-0x8]
ja -0x12
mov64 r8, 0x0
mov64 r6, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r6, [r10-0x8]
add64 r0, r6
mov64 r1, 0x9
stxw [r0+0x0], r1
add64 r9, 0x1
add64 r6, 0x4
stxdw [r10-0x8], r6
ja +0x16
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r7
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
jne r8, 0x20, +0xf
ldxdw r1, [r10-0x10]
sub64 r1, r6
ldxdw r2, [r10-0x40]
ldxdw r7, [r2+0x58]
ldxdw r2, [r2+0x48]
jgt r1, 0x7, +0xe5
mov64 r1, r10
add64 r1, -0x18
mov64 r8, r2
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
mov64 r2, r8
ldxdw r6, [r10-0x8]
ja +0xdc
mov64 r1, r9
add64 r1, r8
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0x1b
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x22
ldxdw r1, [r10-0x18]
add64 r1, r6
stxdw [r1+0x0], r8
add64 r6, 0x8
stxdw [r10-0x8], r6
ldxdw r1, [r10-0x10]
sub64 r1, r6
jge r1, r8, +0x1
ja +0x166
ldxdw r1, [r10-0x18]
add64 r1, r6
mov64 r2, r7
mov64 r3, r8
call fn_15878
add64 r6, r8
mov64 r8, 0x0
add64 r9, 0x21
stxdw [r10-0x8], r6
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r7
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
jeq r8, 0x20, +0x4e
mov64 r1, r9
add64 r1, r8
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x13
mov64 r8, 0x0
mov64 r6, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r6, [r10-0x8]
add64 r0, r6
mov64 r1, 0x3
stxw [r0+0x0], r1
stxdw [r10-0x40], r9
add64 r9, 0x1
add64 r6, 0x4
stxdw [r10-0x8], r6
ja +0x16
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r7
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
jne r8, 0x20, +0xf
ldxdw r1, [r10-0x10]
sub64 r1, r6
ldxdw r2, [r10-0x40]
ldxdw r7, [r2+0x58]
ldxdw r2, [r2+0x48]
jgt r1, 0x7, +0xc4
mov64 r1, r10
add64 r1, -0x18
mov64 r8, r2
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
mov64 r2, r8
ldxdw r6, [r10-0x8]
ja +0xbb
mov64 r1, r9
add64 r1, r8
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0x1b
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x22
mov64 r2, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
add64 r0, r2
mov64 r1, 0x4
stxw [r0+0x0], r1
add64 r2, 0x4
stxdw [r10-0x8], r2
ldxdw r3, [r10-0x38]
ldxdw r1, [r3+0x8]
ldxdw r2, [r10-0x18]
ldxdw r4, [r10-0x30]
stxdw [r4+0x28], r1
ldxdw r1, [r3+0x0]
stxdw [r4+0x20], r1
ldxdw r3, [r10-0x20]
ldxdw r1, [r3+0x18]
stxdw [r4+0x48], r1
ldxdw r1, [r3+0x10]
stxdw [r4+0x40], r1
ldxdw r1, [r3+0x8]
stxdw [r4+0x38], r1
ldxdw r1, [r3+0x0]
stxdw [r4+0x30], r1
ldxdw r3, [r10-0x28]
ldxdw r1, [r3+0x0]
stxdw [r4+0x0], r1
ldxdw r1, [r3+0x8]
stxdw [r4+0x8], r1
ldxdw r1, [r3+0x10]
stxdw [r4+0x10], r1
stxdw [r4+0x18], r2
exit
mov64 r6, 0x0
jgt r1, 0x3, +0x7
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r6, [r10-0x8]
add64 r0, r6
mov64 r1, 0xb
stxw [r0+0x0], r1
add64 r6, 0x4
stxdw [r10-0x8], r6
ldxdw r1, [r10-0x10]
sub64 r1, r6
ldxdw r8, [r9+0x28]
mov64 r2, 0x8
jgt r2, r1, +0xe2
ldxdw r1, [r10-0x18]
add64 r1, r6
stxdw [r1+0x0], r8
add64 r6, 0x8
stxdw [r10-0x8], r6
ldxdw r1, [r10-0x10]
sub64 r1, r6
ldxdw r8, [r9+0x40]
ldxdw r7, [r9+0x30]
jgt r1, 0x7, +0x6
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
ldxdw r6, [r10-0x8]
ldxdw r1, [r10-0x18]
add64 r1, r6
stxdw [r1+0x0], r8
add64 r6, 0x8
stxdw [r10-0x8], r6
ldxdw r1, [r10-0x10]
sub64 r1, r6
jge r1, r8, +0x6
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, r8
call fn_b378
ldxdw r6, [r10-0x8]
ldxdw r1, [r10-0x18]
add64 r1, r6
mov64 r2, r7
mov64 r3, r8
call fn_15878
add64 r6, r8
mov64 r8, 0x0
add64 r9, 0x1
stxdw [r10-0x8], r6
ja +0x8
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r9
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
mov64 r9, r7
jeq r8, 0x20, -0x5c
mov64 r7, r9
add64 r9, r8
ldxb r9, [r9+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0xd
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x14
ldxdw r1, [r10-0x18]
add64 r1, r6
stxdw [r1+0x0], r7
add64 r6, 0x8
stxdw [r10-0x8], r6
ldxdw r9, [r10-0x10]
mov64 r1, r9
sub64 r1, r6
jge r1, r7, +0x1
ja +0xa3
ldxdw r8, [r10-0x18]
mov64 r1, r8
add64 r1, r6
mov64 r3, r7
call fn_15878
add64 r6, r7
stxdw [r10-0x8], r6
sub64 r9, r6
ldxdw r7, [r10-0x40]
ldxdw r1, [r7+0x60]
jgt r9, 0x7, +0x9
mov64 r8, r1
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
mov64 r1, r8
ldxdw r8, [r10-0x18]
ldxdw r6, [r10-0x8]
add64 r8, r6
stxdw [r8+0x0], r1
mov64 r8, 0x0
add64 r7, 0x21
add64 r6, 0x8
stxdw [r10-0x8], r6
mov64 r9, r7
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r7
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
jeq r8, 0x20, -0x95
mov64 r1, r9
add64 r1, r8
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x13
ldxdw r1, [r10-0x18]
add64 r1, r6
stxdw [r1+0x0], r7
add64 r6, 0x8
stxdw [r10-0x8], r6
ldxdw r9, [r10-0x10]
mov64 r1, r9
sub64 r1, r6
jge r1, r7, +0x1
ja +0x74
ldxdw r8, [r10-0x18]
mov64 r1, r8
add64 r1, r6
mov64 r3, r7
call fn_15878
add64 r6, r7
stxdw [r10-0x8], r6
sub64 r9, r6
ldxdw r7, [r10-0x40]
ldxdw r1, [r7+0x60]
jgt r9, 0x7, +0x9
mov64 r8, r1
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
mov64 r1, r8
ldxdw r8, [r10-0x18]
ldxdw r6, [r10-0x8]
add64 r8, r6
stxdw [r8+0x0], r1
add64 r6, 0x8
stxdw [r10-0x8], r6
ldxdw r1, [r10-0x10]
sub64 r1, r6
ldxdw r8, [r7+0x68]
mov64 r9, r7
jgt r1, 0x7, +0x6
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
ldxdw r6, [r10-0x8]
ldxdw r1, [r10-0x18]
add64 r1, r6
stxdw [r1+0x0], r8
mov64 r8, 0x0
add64 r9, 0x21
add64 r6, 0x8
stxdw [r10-0x8], r6
ja +0x7
ldxdw r1, [r10-0x18]
add64 r1, r6
stxb [r1+0x0], r7
add64 r6, 0x1
stxdw [r10-0x8], r6
add64 r8, 0x1
jeq r8, 0x20, -0xdd
mov64 r1, r9
add64 r1, r8
ldxb r7, [r1+0x0]
ldxdw r1, [r10-0x10]
jne r1, r6, -0xc
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x1
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x13
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
ja -0x2a4
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r6, [r10-0x8]
ja -0x280
mov64 r1, r10
add64 r1, -0x18
mov64 r2, 0x0
mov64 r3, 0x4
call fn_b378
ldxdw r0, [r10-0x18]
ldxdw r2, [r10-0x8]
ja -0x243
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x8
call fn_b378
ldxdw r2, [r10-0x8]
ja -0x233
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, r8
call fn_b378
ldxdw r6, [r10-0x8]
ja -0x16d
mov64 r1, r10
add64 r1, -0x18
mov64 r2, r6
mov64 r3, 0x8
call fn_b378
ldxdw r6, [r10-0x8]
ja -0xe9
mov64 r1, r10
add64 r1, -0x18
mov64 r8, r2
mov64 r2, r6
mov64 r3, r7
call fn_b378
mov64 r2, r8
ldxdw r9, [r10-0x10]
ldxdw r6, [r10-0x8]
ja -0xad
mov64 r1, r10
add64 r1, -0x18
mov64 r8, r2
mov64 r2, r6
mov64 r3, r7
call fn_b378
mov64 r2, r8
ldxdw r9, [r10-0x10]
ldxdw r6, [r10-0x8]
ja -0x7e
mov64 r1, r6
mov64 r2, 0x1
call fn_f740
fn_d9c0:
call fn_d9c0
fn_d9c8:
ldxdw r4, [r2+0x18]
stxdw [r1+0x18], r4
ldxdw r4, [r2+0x10]
stxdw [r1+0x10], r4
ldxdw r4, [r2+0x8]
stxdw [r1+0x8], r4
ldxdw r2, [r2+0x0]
stxdw [r1+0x0], r2
mov64 r2, 0x1
stxb [r1+0x21], r2
stxb [r1+0x20], r3
exit
fn_da28:
ldxdw r4, [r2+0x18]
stxdw [r1+0x18], r4
ldxdw r4, [r2+0x10]
stxdw [r1+0x10], r4
ldxdw r4, [r2+0x8]
stxdw [r1+0x8], r4
ldxdw r2, [r2+0x0]
stxdw [r1+0x0], r2
mov64 r2, 0x0
stxb [r1+0x21], r2
stxb [r1+0x20], r3
exit
fn_da88:
lddw r5, 0x16e60
stxdw [r10-0x1000], r5
mov64 r5, 0x0
stxdw [r10-0xff8], r5
mov64 r5, r10
call fn_dac8
exit
fn_dac8:
stxdw [r10-0x40], r4
stxdw [r10-0x48], r3
stxdw [r10-0x58], r1
stxdw [r10-0x50], r2
ldxdw r1, [r2+0x10]
ldxdw r2, [r5-0xff8]
stxdw [r10-0x80], r2
ldxdw r2, [r5-0x1000]
stxdw [r10-0x88], r2
jeq r1, 0x0, +0x4d
ldxdw r2, [r10-0x50]
ldxdw r7, [r2+0x0]
mul64 r1, 0x22
mov64 r2, r7
add64 r2, r1
stxdw [r10-0x18], r2
ldxdw r1, [r10-0x40]
mul64 r1, 0x30
stxdw [r10-0x8], r1
ldxdw r1, [r10-0x48]
add64 r1, -0x28
stxdw [r10-0x10], r1
ja +0x3b
jne r8, 0x0, +0x1
ja +0x37
ldxdw r2, [r9+0x28]
mov64 r1, r6
mov64 r3, 0x20
call fn_15aa8
add64 r8, -0x30
add64 r9, 0x30
lsh64 r0, 0x20
rsh64 r0, 0x20
jne r0, 0x0, -0xb
ldxb r1, [r6+0x21]
jne r1, 0x0, +0x18
ldxdw r1, [r9+0x0]
ldxdw r2, [r1+0x10]
lddw r3, 0x7fffffffffffffff
jgt r3, r2, +0x1
ja +0x4a
mov64 r3, r1
add64 r3, 0x10
stxdw [r10-0x60], r3
stxdw [r3+0x0], r2
ldxdw r2, [r9+0x8]
ldxdw r3, [r2+0x10]
lddw r4, 0x7fffffffffffffff
jgt r4, r3, +0x1
ja +0x47
mov64 r3, r2
add64 r3, 0x10
stxdw [r10-0x70], r3
add64 r2, 0x18
add64 r1, 0x18
stxdw [r10-0x68], r1
stxdw [r10-0x78], r2
ja +0x14
ldxdw r1, [r9+0x0]
ldxdw r2, [r1+0x10]
mov64 r4, 0x0
jne r2, 0x0, +0x26
mov64 r2, r1
add64 r2, 0x10
stxdw [r10-0x20], r2
stxdw [r2+0x0], r4
ldxdw r2, [r9+0x8]
ldxdw r3, [r2+0x10]
jeq r3, 0x0, +0x1
ja +0x25
mov64 r3, r2
add64 r3, 0x10
stxdw [r10-0x28], r3
stxdw [r2+0x10], r4
add64 r2, 0x18
add64 r1, 0x18
stxdw [r10-0x30], r2
stxdw [r10-0x38], r1
ldxdw r1, [r10-0x18]
jeq r7, r1, +0x5
mov64 r6, r7
add64 r7, 0x22
ldxdw r8, [r10-0x8]
ldxdw r9, [r10-0x10]
ja -0x40
ldxdw r1, [r10-0x50]
ldxdw r2, [r10-0x48]
ldxdw r3, [r10-0x40]
ldxdw r4, [r10-0x88]
ldxdw r5, [r10-0x80]
fn_dda8:
call fn_dda8
jne r0, 0x0, +0x4
mov64 r1, 0x14
ldxdw r2, [r10-0x58]
stxw [r2+0x0], r1
ja +0x22
ldxdw r1, [r10-0x58]
mov64 r2, r0
call fn_e398
ja +0x1e
ldxdw r2, [r10-0x58]
ldxdw r1, [r10-0x20]
stxdw [r2+0x8], r1
lddw r1, -0x100000000
ldxdw r3, [r10-0x38]
ja +0x14
ldxdw r2, [r10-0x58]
ldxdw r1, [r10-0x28]
stxdw [r2+0x8], r1
lddw r1, -0x100000000
ldxdw r3, [r10-0x30]
ja +0xd
ldxdw r2, [r10-0x58]
ldxdw r1, [r10-0x60]
stxdw [r2+0x8], r1
lddw r1, -0x100000000
ldxdw r3, [r10-0x68]
ja +0x6
ldxdw r2, [r10-0x58]
ldxdw r1, [r10-0x70]
stxdw [r2+0x8], r1
lddw r1, -0x100000000
ldxdw r3, [r10-0x78]
and64 r3, r1
or64 r3, 0xb
stxdw [r2+0x0], r3
exit
fn_def0:
mov64 r6, r1
mov64 r7, r10
add64 r7, -0x440
mov64 r9, 0x0
mov64 r8, 0x400
mov64 r1, r7
mov64 r2, 0x0
mov64 r3, 0x400
call fn_15990
stxdw [r10-0x28], r9
stxdw [r10-0x30], r9
stxdw [r10-0x38], r9
stxdw [r10-0x40], r9
mov64 r3, r10
add64 r3, -0x40
mov64 r1, r7
mov64 r2, 0x400
fn_df78:
call fn_df78
mov64 r7, r0
jne r7, 0x0, +0x2
stxdw [r6+0x20], r9
ja +0x23
ldxdw r1, [r10-0x28]
stxdw [r10-0x8], r1
ldxdw r1, [r10-0x30]
stxdw [r10-0x10], r1
ldxdw r1, [r10-0x38]
stxdw [r10-0x18], r1
ldxdw r1, [r10-0x40]
stxdw [r10-0x20], r1
jgt r8, r7, +0x1
mov64 r7, 0x400
mov64 r1, r7
mov64 r2, 0x1
call fn_6e00
mov64 r8, r0
jne r8, 0x0, +0x4
mov64 r1, r7
mov64 r2, 0x1
call fn_f740
fn_e030:
call fn_e030
mov64 r2, r10
add64 r2, -0x440
mov64 r1, r8
mov64 r3, r7
call fn_15878
ldxdw r1, [r10-0x20]
stxdw [r6+0x0], r1
ldxdw r1, [r10-0x18]
stxdw [r6+0x8], r1
ldxdw r1, [r10-0x10]
stxdw [r6+0x10], r1
ldxdw r1, [r10-0x8]
stxdw [r6+0x18], r1
stxdw [r6+0x30], r7
stxdw [r6+0x28], r7
stxdw [r6+0x20], r8
exit
fn_e0c0:
ldxw r2, [r1+0x0]
jsgt r2, 0x9, +0x6
jsgt r2, 0x4, +0xb
jsgt r2, 0x1, +0x14
jeq r2, 0x0, +0x27
lddw r6, 0x200000000
ja +0x4a
jsgt r2, 0xe, +0xa
jsgt r2, 0xb, +0x13
jeq r2, 0xa, +0x27
lddw r6, 0xc00000000
ja +0x44
jsgt r2, 0x6, +0x13
jeq r2, 0x5, +0x25
lddw r6, 0x700000000
ja +0x3f
jsgt r2, 0x10, +0x13
jeq r2, 0xf, +0x23
lddw r6, 0x1100000000
ja +0x3a
jeq r2, 0x2, +0x22
jeq r2, 0x3, +0x24
lddw r6, 0x500000000
ja +0x35
jeq r2, 0xc, +0x23
jeq r2, 0xd, +0x25
lddw r6, 0xf00000000
ja +0x30
jeq r2, 0x7, +0x24
jeq r2, 0x8, +0x26
lddw r6, 0xa00000000
ja +0x2b
jeq r2, 0x11, +0x25
jeq r2, 0x12, +0x27
lddw r6, 0x1400000000
ja +0x26
lddw r6, 0x100000000
ldxw r3, [r1+0x4]
jeq r3, 0x0, +0x22
mov64 r6, r3
ja +0x20
lddw r6, 0xb00000000
ja +0x1d
lddw r6, 0x600000000
ja +0x1a
lddw r6, 0x1000000000
ja +0x17
lddw r6, 0x300000000
ja +0x14
lddw r6, 0x400000000
ja +0x11
lddw r6, 0xd00000000
ja +0xe
lddw r6, 0xe00000000
ja +0xb
lddw r6, 0x800000000
ja +0x8
lddw r6, 0x900000000
ja +0x5
lddw r6, 0x1200000000
ja +0x2
lddw r6, 0x1300000000
jne r2, 0xe, +0x6
ldxdw r2, [r1+0x10]
jeq r2, 0x0, +0x4
ldxdw r1, [r1+0x8]
jeq r1, 0x0, +0x2
mov64 r3, 0x1
call fn_6e10
mov64 r0, r6
exit
fn_e398:
mov64 r6, r1
lddw r3, -0x100000000
mov64 r1, r2
add64 r1, r3
mov64 r3, r1
rsh64 r3, 0x20
lsh64 r1, 0x20
or64 r1, r3
jsgt r1, 0x9, +0x6
jsgt r1, 0x4, +0xc
jsgt r1, 0x1, +0x17
jeq r1, 0x0, +0x35
mov64 r3, 0x1
jeq r1, 0x1, +0x56
ja +0x2f
jsgt r1, 0xe, +0xc
jsgt r1, 0xb, +0x17
jeq r1, 0xa, +0x32
jeq r1, 0xb, +0x1
ja +0x2a
mov64 r3, 0xb
ja +0x4e
jsgt r1, 0x6, +0x1e
jeq r1, 0x5, +0x2e
jeq r1, 0x6, +0x1
ja +0x24
mov64 r3, 0x6
ja +0x48
jsgt r1, 0x10, +0x1e
jeq r1, 0xf, +0x2a
jeq r1, 0x10, +0x1
ja +0x1e
mov64 r3, 0x10
ja +0x42
jeq r1, 0x2, +0x27
jeq r1, 0x3, +0x28
jeq r1, 0x4, +0x1
ja +0x18
mov64 r3, 0x4
ja +0x3c
jeq r1, 0xc, +0x25
jeq r1, 0xd, +0x26
jeq r1, 0xe, +0x1
ja +0x12
mov64 r7, 0x7
mov64 r1, 0x7
mov64 r2, 0x1
call fn_6e00
jne r0, 0x0, +0x2b
mov64 r1, 0x7
mov64 r2, 0x1
call fn_f740
fn_e540:
call fn_e540
jeq r1, 0x7, +0x1c
jeq r1, 0x8, +0x1d
jeq r1, 0x9, +0x1
ja +0x5
mov64 r3, 0x9
ja +0x29
jeq r1, 0x11, +0x1a
jeq r1, 0x12, +0x1b
jeq r1, 0x13, +0x1c
stxw [r6+0x4], r2
mov64 r3, 0x0
ja +0x23
mov64 r3, 0x0
stxw [r6+0x4], r3
ja +0x20
mov64 r3, 0xa
ja +0x1e
mov64 r3, 0x5
ja +0x1c
mov64 r3, 0xf
ja +0x1a
mov64 r3, 0x2
ja +0x18
mov64 r3, 0x3
ja +0x16
mov64 r3, 0xc
ja +0x14
mov64 r3, 0xd
ja +0x12
mov64 r3, 0x7
ja +0x10
mov64 r3, 0x8
ja +0xe
mov64 r3, 0x11
ja +0xc
mov64 r3, 0x12
ja +0xa
mov64 r3, 0x13
ja +0x8
mov64 r1, 0x6e776f6e
stxw [r0+0x3], r1
mov64 r1, 0x6e6b6e55
stxw [r0+0x0], r1
stxdw [r6+0x18], r7
stxdw [r6+0x10], r7
stxdw [r6+0x8], r0
mov64 r3, 0xe
stxw [r6+0x0], r3
exit
fn_e6d0:
mov64 r0, r4
mov64 r6, r1
mov64 r1, 0x0
stxdw [r10-0x18], r1
stxdw [r10-0x20], r1
stxdw [r10-0x28], r1
stxdw [r10-0x30], r1
mov64 r1, 0xff
stxb [r10-0x31], r1
mov64 r4, r10
add64 r4, -0x30
mov64 r5, r10
add64 r5, -0x31
mov64 r1, r2
mov64 r2, r3
mov64 r3, r0
fn_e750:
call fn_e750
jne r0, 0x0, +0x9
ldxdw r1, [r10-0x18]
stxdw [r10-0x40], r1
ldxdw r1, [r10-0x20]
stxdw [r10-0x48], r1
ldxdw r1, [r10-0x28]
stxdw [r10-0x50], r1
ldxdw r1, [r10-0x30]
stxdw [r10-0x58], r1
ldxb r1, [r10-0x31]
jeq r0, 0x0, +0x11
lddw r1, 0x16e60
stxdw [r10-0x10], r1
mov64 r1, 0x0
stxdw [r10-0x8], r1
stxdw [r10-0x20], r1
mov64 r1, 0x1
stxdw [r10-0x28], r1
lddw r1, 0x17c28
stxdw [r10-0x30], r1
mov64 r1, r10
add64 r1, -0x30
lddw r2, 0x17c38
call fn_109f8
fn_e830:
call fn_e830
ldxdw r2, [r10-0x40]
stxdw [r6+0x18], r2
ldxdw r2, [r10-0x48]
stxdw [r6+0x10], r2
ldxdw r2, [r10-0x50]
stxdw [r6+0x8], r2
ldxdw r2, [r10-0x58]
stxdw [r6+0x0], r2
stxb [r6+0x20], r1
exit
fn_e888:
mov64 r6, r1
add64 r2, 0x80
ldxdw r1, [r6+0x0]
mul64 r1, r2
call fn_16708
ldxdw r1, [r6+0x8]
mov64 r2, r0
call fn_14f48
mov64 r6, r0
mov64 r1, r6
call fn_14e70
mov64 r7, r0
mov64 r8, 0x0
mov64 r1, r6
mov64 r2, 0x0
call fn_15758
lsh64 r0, 0x20
arsh64 r0, 0x20
jsgt r8, r0, +0x1
mov64 r8, r7
mov64 r1, r6
lddw r2, 0x43efffffffffffff
call fn_15c08
mov64 r1, r0
lsh64 r1, 0x20
arsh64 r1, 0x20
mov64 r0, -0x1
jsgt r1, 0x0, +0x1
mov64 r0, r8
exit
fn_e980:
mov64 r6, r5
mov64 r7, r4
mov64 r8, r3
mov64 r9, r2
stxdw [r10-0xb0], r1
mov64 r1, 0x44
mov64 r2, 0x1
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x44
mov64 r2, 0x1
call fn_f740
fn_e9e0:
call fn_e9e0
ldxdw r2, [r6-0xff8]
ldxdw r1, [r6-0x1000]
ldxdw r3, [r9+0x18]
stxdw [r0+0x18], r3
ldxdw r3, [r9+0x10]
stxdw [r0+0x10], r3
ldxdw r3, [r9+0x8]
stxdw [r0+0x8], r3
ldxdw r3, [r9+0x0]
stxdw [r0+0x0], r3
mov64 r3, 0x101
stxh [r0+0x20], r3
ldxdw r4, [r8+0x0]
stxdw [r0+0x22], r4
ldxdw r4, [r8+0x8]
stxdw [r0+0x2a], r4
ldxdw r4, [r8+0x10]
stxdw [r0+0x32], r4
ldxdw r4, [r8+0x18]
stxdw [r0+0x3a], r4
stxh [r0+0x42], r3
mov64 r3, 0x0
stxdw [r10-0x90], r3
stxdw [r10-0x98], r3
stxdw [r10-0xa0], r3
stxdw [r10-0xa8], r3
ldxdw r4, [r2+0x18]
stxdw [r10-0x6f], r4
ldxdw r4, [r2+0x10]
stxdw [r10-0x77], r4
ldxdw r4, [r2+0x8]
stxdw [r10-0x7f], r4
ldxdw r2, [r2+0x0]
stxdw [r10-0x87], r2
stxdw [r10-0x58], r1
stxdw [r10-0x60], r7
stxb [r10-0x88], r3
mov64 r1, 0x2
stxdw [r10-0x8], r1
stxdw [r10-0x10], r1
stxdw [r10-0x18], r0
mov64 r2, r10
add64 r2, -0xa8
mov64 r6, r10
add64 r6, -0x88
mov64 r4, r10
add64 r4, -0x18
ldxdw r1, [r10-0xb0]
mov64 r3, r6
call fn_c0b8
mov64 r1, r6
call fn_b1d0
exit
fn_eb90:
mov64 r7, r3
mov64 r8, r2
mov64 r6, r1
mov64 r9, 0x1
mov64 r1, 0x22
mov64 r2, 0x1
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x22
mov64 r2, 0x1
call fn_f740
fn_ebe8:
call fn_ebe8
ldxdw r1, [r8+0x18]
stxdw [r0+0x18], r1
ldxdw r1, [r8+0x10]
stxdw [r0+0x10], r1
ldxdw r1, [r8+0x8]
stxdw [r0+0x8], r1
ldxdw r1, [r8+0x0]
stxdw [r0+0x0], r1
mov64 r1, 0x101
stxh [r0+0x20], r1
mov64 r1, 0x0
stxdw [r10-0x90], r1
stxdw [r10-0x98], r1
stxdw [r10-0xa0], r1
stxdw [r10-0xa8], r1
ldxdw r1, [r7+0x18]
stxdw [r10-0x6f], r1
ldxdw r1, [r7+0x10]
stxdw [r10-0x77], r1
ldxdw r1, [r7+0x8]
stxdw [r10-0x7f], r1
ldxdw r1, [r7+0x0]
stxdw [r10-0x87], r1
stxb [r10-0x88], r9
stxdw [r10-0x8], r9
stxdw [r10-0x10], r9
stxdw [r10-0x18], r0
mov64 r2, r10
add64 r2, -0xa8
mov64 r7, r10
add64 r7, -0x88
mov64 r4, r10
add64 r4, -0x18
mov64 r1, r6
mov64 r3, r7
call fn_c0b8
mov64 r1, r7
call fn_b1d0
exit
fn_ed28:
mov64 r7, r4
mov64 r8, r3
mov64 r9, r2
mov64 r6, r1
mov64 r1, 0x44
mov64 r2, 0x1
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x44
mov64 r2, 0x1
call fn_f740
fn_ed80:
call fn_ed80
ldxdw r1, [r9+0x0]
ldxdw r2, [r9+0x8]
ldxdw r3, [r9+0x10]
ldxdw r4, [r9+0x18]
mov64 r5, 0x101
stxh [r0+0x20], r5
stxdw [r0+0x18], r4
stxdw [r0+0x10], r3
stxdw [r0+0x8], r2
stxdw [r0+0x0], r1
ldxdw r1, [r8+0x0]
stxdw [r0+0x22], r1
ldxdw r1, [r8+0x8]
stxdw [r0+0x2a], r1
ldxdw r1, [r8+0x10]
stxdw [r0+0x32], r1
ldxdw r1, [r8+0x18]
stxdw [r0+0x3a], r1
mov64 r1, 0x100
stxh [r0+0x42], r1
mov64 r1, 0x0
stxdw [r10-0x90], r1
stxdw [r10-0x98], r1
stxdw [r10-0xa0], r1
stxdw [r10-0xa8], r1
stxdw [r10-0x80], r7
mov64 r1, 0x2
stxb [r10-0x88], r1
stxdw [r10-0x8], r1
stxdw [r10-0x10], r1
stxdw [r10-0x18], r0
mov64 r2, r10
add64 r2, -0xa8
mov64 r7, r10
add64 r7, -0x88
mov64 r4, r10
add64 r4, -0x18
mov64 r1, r6
mov64 r3, r7
call fn_c0b8
mov64 r1, r7
call fn_b1d0
exit
fn_eee0:
mov64 r7, r3
mov64 r8, r2
mov64 r6, r1
mov64 r9, 0x1
mov64 r1, 0x22
mov64 r2, 0x1
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x22
mov64 r2, 0x1
call fn_f740
fn_ef38:
call fn_ef38
ldxdw r1, [r8+0x18]
stxdw [r0+0x18], r1
ldxdw r1, [r8+0x10]
stxdw [r0+0x10], r1
ldxdw r1, [r8+0x8]
stxdw [r0+0x8], r1
ldxdw r1, [r8+0x0]
stxdw [r0+0x0], r1
mov64 r1, 0x101
stxh [r0+0x20], r1
mov64 r1, 0x0
stxdw [r10-0x90], r1
stxdw [r10-0x98], r1
stxdw [r10-0xa0], r1
stxdw [r10-0xa8], r1
mov64 r1, 0x8
stxb [r10-0x88], r1
stxdw [r10-0x80], r7
stxdw [r10-0x8], r9
stxdw [r10-0x10], r9
stxdw [r10-0x18], r0
mov64 r2, r10
add64 r2, -0xa8
mov64 r7, r10
add64 r7, -0x88
mov64 r4, r10
add64 r4, -0x18
mov64 r1, r6
mov64 r3, r7
call fn_c0b8
mov64 r1, r7
call fn_b1d0
exit
fn_f048:
mov64 r2, 0x0
stxdw [r1+0x18], r2
stxdw [r1+0x10], r2
stxdw [r1+0x8], r2
stxdw [r1+0x0], r2
exit
fn_f078:
mov64 r6, r1
mov64 r1, 0x32
stxb [r10-0x8], r1
lddw r1, 0x4000000000000000
stxdw [r10-0x10], r1
mov64 r1, 0xd98
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x18
fn_f0c8:
call fn_f0c8
mov64 r1, r6
add64 r1, 0x8
jne r0, 0x0, +0x8
ldxdw r2, [r10-0x8]
stxdw [r1+0x10], r2
ldxdw r2, [r10-0x10]
stxdw [r1+0x8], r2
ldxdw r2, [r10-0x18]
stxdw [r1+0x0], r2
mov64 r1, 0x0
ja +0x3
mov64 r2, r0
call fn_e398
mov64 r1, 0x1
stxdw [r6+0x0], r1
exit
fn_f150:
exit
ldxdw r3, [r2+0x10]
stxdw [r1+0x8], r3
ldxdw r2, [r2+0x0]
stxdw [r1+0x0], r2
exit
mov64 r3, r2
ldxdw r2, [r1+0x10]
ldxdw r1, [r1+0x0]
call fn_128e0
exit
mov64 r3, r2
ldxdw r2, [r1+0x10]
ldxdw r1, [r1+0x0]
call fn_11eb8
exit
fn_f1d0:
mov64 r8, r4
mov64 r7, r3
mov64 r9, r2
mov64 r6, r1
mov64 r1, 0x18
mov64 r2, 0x8
call fn_6e00
jne r0, 0x0, +0x4
mov64 r1, 0x18
mov64 r2, 0x8
call fn_f740
fn_f228:
call fn_f228
stxb [r0+0x10], r9
stxdw [r0+0x8], r8
stxdw [r0+0x0], r7
stxdw [r6+0x8], r0
mov64 r1, 0x3
stxdw [r6+0x0], r1
exit
fn_f268:
call fn_f2e0
fn_f270:
call fn_f270
fn_f278:
lddw r1, 0x16e78
mov64 r2, 0x2e
call fn_f2b8
call fn_f268
fn_f2a0:
call fn_f2a0
fn_f2a8:
call fn_f2c8
fn_f2b0:
call fn_f2b0
fn_f2b8:
call fn_f2b8
exit
fn_f2c8:
call fn_f2c8
fn_f2d0:
call fn_f2d0
fn_f2d8:
call fn_f2d8
fn_f2e0:
call fn_f2e0
fn_f2e8:
call fn_f2e8
fn_f2f0:
call fn_f750
fn_f2f8:
call fn_f2f8
exit
fn_f308:
mov64 r6, r1
mov64 r4, r2
add64 r4, r3
mov64 r1, 0x1
jgt r2, r4, +0x1
mov64 r1, 0x0
and64 r1, 0x1
jne r1, 0x0, +0x1b
ldxdw r1, [r6+0x8]
mov64 r7, r1
lsh64 r7, 0x1
jgt r7, r4, +0x1
mov64 r7, r4
jgt r7, 0x8, +0x1
mov64 r7, 0x8
jeq r1, 0x0, +0x6
ldxdw r2, [r6+0x0]
mov64 r3, 0x1
stxdw [r10-0x8], r3
stxdw [r10-0x10], r1
stxdw [r10-0x18], r2
ja +0x2
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
mov64 r2, r7
mov64 r3, 0x1
call fn_f5c8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_f428:
call fn_f428
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_f460:
call fn_f460
fn_f468:
mov64 r6, r1
mov64 r3, r2
add64 r3, 0x1
mov64 r1, 0x1
jgt r2, r3, +0x1
mov64 r1, 0x0
and64 r1, 0x1
jne r1, 0x0, +0x1b
ldxdw r1, [r6+0x8]
mov64 r7, r1
lsh64 r7, 0x1
jgt r7, r3, +0x1
mov64 r7, r3
jgt r7, 0x8, +0x1
mov64 r7, 0x8
jeq r1, 0x0, +0x6
ldxdw r2, [r6+0x0]
mov64 r3, 0x1
stxdw [r10-0x8], r3
stxdw [r10-0x10], r1
stxdw [r10-0x18], r2
ja +0x2
mov64 r1, 0x0
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x30
mov64 r4, r10
add64 r4, -0x18
mov64 r2, r7
mov64 r3, 0x1
call fn_f5c8
ldxdw r1, [r10-0x30]
jne r1, 0x1, +0x4
ldxdw r2, [r10-0x20]
jne r2, 0x0, +0x6
call fn_f708
fn_f588:
call fn_f588
ldxdw r1, [r10-0x28]
stxdw [r6+0x8], r7
stxdw [r6+0x0], r1
exit
ldxdw r1, [r10-0x28]
call fn_f740
fn_f5c0:
call fn_f5c0
fn_f5c8:
mov64 r8, r3
mov64 r7, r2
mov64 r6, r1
jne r8, 0x0, +0x4
stxdw [r6+0x8], r7
mov64 r1, 0x1
mov64 r7, 0x0
ja +0x1d
ldxdw r1, [r4+0x0]
jeq r1, 0x0, +0xd
ldxdw r2, [r4+0x8]
jne r2, 0x0, +0x6
jeq r7, 0x0, +0x14
mov64 r1, r7
mov64 r2, r8
call fn_6e00
jeq r0, 0x0, +0xc
ja +0x11
mov64 r3, r8
mov64 r4, r7
call fn_6e20
jeq r0, 0x0, +0x7
ja +0xc
jeq r7, 0x0, +0x9
mov64 r1, r7
mov64 r2, r8
call fn_6e00
jeq r0, 0x0, +0x1
ja +0x6
stxdw [r6+0x8], r7
mov64 r1, 0x1
mov64 r7, r8
ja +0x4
mov64 r7, 0x0
mov64 r0, r8
stxdw [r6+0x8], r0
mov64 r1, 0x0
stxdw [r6+0x0], r1
stxdw [r6+0x10], r7
exit
fn_f708:
lddw r1, 0x16ec2
mov64 r2, 0x11
lddw r3, 0x17c70
call fn_10888
fn_f738:
call fn_f738
fn_f740:
call fn_f770
fn_f748:
call fn_f748
fn_f750:
call fn_6e40
fn_f758:
call fn_f758
fn_f760:
call fn_f278
fn_f768:
call fn_f768
fn_f770:
call fn_f2f0
fn_f778:
call fn_f778
fn_f780:
mov64 r6, r2
mov64 r7, r1
mov64 r8, 0x0
ldxdw r3, [r6+0x28]
ldxdw r1, [r6+0x0]
ldxdw r2, [r6+0x8]
mov64 r4, r2
lsh64 r4, 0x4
jeq r4, 0x0, +0x9
mov64 r0, 0x0
mov64 r5, r1
add64 r5, 0x8
ldxdw r8, [r5+0x0]
add64 r8, r0
add64 r5, 0x10
add64 r4, -0x10
mov64 r0, r8
jne r4, 0x0, -0x6
jeq r3, 0x0, +0x11
jeq r2, 0x0, +0x6
ldxdw r1, [r1+0x8]
jne r1, 0x0, +0x4
mov64 r0, 0x1
mov64 r1, 0x0
mov64 r2, 0x10
jgt r2, r8, +0x16
mov64 r2, r8
add64 r2, r2
mov64 r1, 0x0
mov64 r0, 0x1
mov64 r3, 0x1
jgt r8, r2, +0x1
mov64 r3, 0x0
and64 r3, 0x1
mov64 r8, r2
jne r3, 0x0, +0xc
mov64 r0, 0x1
mov64 r1, 0x0
jeq r8, 0x0, +0x9
mov64 r1, r8
mov64 r2, 0x1
call fn_6e00
mov64 r1, r8
jne r0, 0x0, +0x4
mov64 r1, r8
mov64 r2, 0x1
call fn_f740
fn_f8f8:
call fn_f8f8
mov64 r2, 0x0
stxdw [r7+0x10], r2
stxdw [r7+0x8], r1
stxdw [r7+0x0], r0
stxdw [r10-0x38], r7
mov64 r7, r10
add64 r7, -0x30
mov64 r1, r7
mov64 r2, r6
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x38
lddw r2, 0x17cc0
mov64 r3, r7
call fn_10b58
jeq r0, 0x0, +0xb
mov64 r3, r10
add64 r3, -0x30
lddw r1, 0x16ed3
mov64 r2, 0x33
lddw r4, 0x17ca0
lddw r5, 0x17c88
call fn_10a58
fn_f9e0:
call fn_f9e0
exit
fn_f9f0:
mov64 r7, r2
mov64 r6, r1
mov64 r1, r7
lsh64 r1, 0x20
rsh64 r1, 0x20
jgt r1, 0x7f, +0xc
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x8]
jne r2, r1, +0x3
mov64 r1, r6
call fn_f468
ldxdw r2, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r2
stxb [r1+0x0], r7
add64 r2, 0x1
stxdw [r6+0x10], r2
ja +0x42
mov64 r2, 0x0
stxw [r10-0x4], r2
mov64 r2, 0x800
jgt r2, r1, +0x13
mov64 r1, r7
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0x10000
jgt r2, r1, +0x1
ja +0x16
and64 r7, 0x3f
or64 r7, 0x80
stxb [r10-0x2], r7
mov64 r2, r1
rsh64 r2, 0xc
or64 r2, 0xe0
stxb [r10-0x4], r2
rsh64 r1, 0x6
and64 r1, 0x3f
or64 r1, 0x80
stxb [r10-0x3], r1
mov64 r7, 0x3
ja +0x1a
mov64 r1, r7
and64 r1, 0x3f
or64 r1, 0x80
stxb [r10-0x3], r1
rsh64 r7, 0x6
or64 r7, 0xc0
stxb [r10-0x4], r7
mov64 r7, 0x2
ja +0x11
and64 r7, 0x3f
or64 r7, 0x80
stxb [r10-0x1], r7
mov64 r2, r1
rsh64 r2, 0x12
or64 r2, 0xf0
stxb [r10-0x4], r2
mov64 r2, r1
rsh64 r2, 0x6
and64 r2, 0x3f
or64 r2, 0x80
stxb [r10-0x2], r2
rsh64 r1, 0xc
and64 r1, 0x3f
or64 r1, 0x80
stxb [r10-0x3], r1
mov64 r7, 0x4
ldxdw r8, [r6+0x10]
ldxdw r1, [r6+0x8]
sub64 r1, r8
jge r1, r7, +0x5
mov64 r1, r6
mov64 r2, r8
mov64 r3, r7
call fn_f308
ldxdw r8, [r6+0x10]
ldxdw r1, [r6+0x0]
add64 r1, r8
mov64 r2, r10
add64 r2, -0x4
mov64 r3, r7
call fn_15878
add64 r8, r7
stxdw [r6+0x10], r8
exit
mov64 r6, r3
mov64 r8, r2
ldxdw r7, [r1+0x0]
ldxdw r9, [r7+0x10]
ldxdw r1, [r7+0x8]
sub64 r1, r9
jge r1, r6, +0x5
mov64 r1, r7
mov64 r2, r9
mov64 r3, r6
call fn_f308
ldxdw r9, [r7+0x10]
ldxdw r1, [r7+0x0]
add64 r1, r9
mov64 r2, r8
mov64 r3, r6
call fn_15878
add64 r9, r6
stxdw [r7+0x10], r9
mov64 r0, 0x0
exit
ldxdw r1, [r1+0x0]
call fn_f9f0
mov64 r0, 0x0
exit
ldxdw r1, [r1+0x0]
stxdw [r10-0x38], r1
mov64 r6, r10
add64 r6, -0x30
mov64 r1, r6
mov64 r3, 0x30
call fn_15878
mov64 r1, r10
add64 r1, -0x38
lddw r2, 0x17cc0
mov64 r3, r6
call fn_10b58
exit
ldxdw r1, [r1+0x0]
fn_fdd8:
call fn_fdd8
fn_fde0:
call fn_fde0
exit
mov64 r6, r2
mov64 r7, r1
call fn_13d60
mov64 r1, r0
mov64 r0, 0x1
jne r1, 0x0, +0x13
ldxdw r2, [r6+0x28]
ldxdw r1, [r6+0x20]
lddw r3, 0x16f20
stxdw [r10-0x10], r3
mov64 r3, 0x0
stxdw [r10-0x8], r3
stxdw [r10-0x20], r3
lddw r3, 0x17cf0
stxdw [r10-0x30], r3
mov64 r3, 0x1
stxdw [r10-0x28], r3
mov64 r3, r10
add64 r3, -0x30
call fn_10b58
mov64 r1, r0
mov64 r0, 0x1
jeq r1, 0x0, +0x1
exit
add64 r7, 0x8
mov64 r1, r7
mov64 r2, r6
call fn_13d60
mov64 r1, r0
mov64 r0, 0x0
jeq r1, 0x0, -0x8
mov64 r0, 0x1
ja -0xa
lddw r0, -0x378ec6423c928e8e
exit
ldxdw r1, [r2+0x20]
ldxdw r2, [r2+0x28]
ldxdw r4, [r2+0x18]
lddw r2, 0x16f22
mov64 r3, 0xb
callx r4
exit
fn_ff60:
mov64 r7, r2
mov64 r6, r1
mov64 r1, 0x2
mov64 r5, r7
lsh64 r5, 0x20
rsh64 r5, 0x20
jsgt r5, 0x21, +0x9
mov64 r4, 0x74
jeq r5, 0x9, +0xad
jeq r5, 0xa, +0x4
jeq r5, 0xd, +0x1
ja +0x7
mov64 r4, 0x72
ja +0xa8
mov64 r4, 0x6e
ja +0xa6
jeq r5, 0x22, +0x5c
jeq r5, 0x27, +0xa0
jeq r5, 0x5c, +0x5f
and64 r3, 0x1
jeq r3, 0x0, +0x3
mov64 r1, r7
call fn_14b00
jne r0, 0x0, +0x1a
mov64 r1, r7
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0x10000
jgt r2, r1, +0x57
mov64 r2, 0x20000
jgt r2, r1, +0x1
ja +0x67
lddw r1, 0x1755c
stxdw [r10-0xff8], r1
mov64 r1, 0x1b6
stxdw [r10-0xff0], r1
mov64 r1, 0xc0
stxdw [r10-0x1000], r1
mov64 r5, r10
mov64 r1, r7
lddw r2, 0x17448
mov64 r3, 0x2a
lddw r4, 0x1749c
call fn_13770
mov64 r1, 0x1
mov64 r4, r7
jne r0, 0x0, +0x84
mov64 r1, r7
or64 r1, 0x1
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, r1
rsh64 r2, 0x1
or64 r1, r2
mov64 r2, r1
rsh64 r2, 0x2
or64 r1, r2
mov64 r2, r1
rsh64 r2, 0x4
or64 r1, r2
lsh64 r7, 0x20
rsh64 r7, 0x20
lddw r2, 0x500000000
or64 r7, r2
mov64 r2, r1
rsh64 r2, 0x8
or64 r1, r2
mov64 r2, r1
rsh64 r2, 0x10
or64 r1, r2
mov64 r2, r1
rsh64 r2, 0x20
or64 r1, r2
xor64 r1, -0x1
lddw r2, 0x5555555555555555
mov64 r3, r1
rsh64 r3, 0x1
and64 r3, r2
sub64 r1, r3
lddw r3, 0x3333333333333333
mov64 r2, r1
and64 r2, r3
rsh64 r1, 0x2
and64 r1, r3
add64 r2, r1
mov64 r1, r2
rsh64 r1, 0x4
add64 r2, r1
lddw r1, 0xf0f0f0f0f0f0f0f
and64 r2, r1
lddw r1, 0x101010101010101
mul64 r2, r1
rsh64 r2, 0x38
add64 r2, -0x20
lddw r1, 0xfffffffc
and64 r2, r1
mov64 r1, 0x3
rsh64 r2, 0x2
xor64 r2, 0x7
ja +0x49
mov64 r4, 0x22
mov64 r5, r3
and64 r5, 0x10000
jeq r5, 0x0, -0x5e
ja +0x44
mov64 r4, 0x5c
ja +0x42
lddw r1, 0x17319
stxdw [r10-0xff8], r1
mov64 r1, 0x12f
stxdw [r10-0xff0], r1
mov64 r1, 0x120
stxdw [r10-0x1000], r1
mov64 r5, r10
mov64 r1, r7
lddw r2, 0x171a9
mov64 r3, 0x28
lddw r4, 0x171f9
call fn_13770
mov64 r1, 0x1
mov64 r4, r7
jne r0, 0x0, +0x30
ja -0x55
mov64 r1, r7
and64 r1, 0x1fffe0
jeq r1, 0x2a6e0, -0x58
mov64 r1, r7
add64 r1, -0x2b739
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0x7
jgt r2, r1, -0x5e
mov64 r1, r7
and64 r1, 0x1ffffe
jeq r1, 0x2b81e, -0x61
mov64 r1, r7
add64 r1, -0x2cea2
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0xe
jgt r2, r1, -0x67
mov64 r1, r7
add64 r1, -0x2ebe1
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0xc1f
jgt r2, r1, -0x6d
mov64 r1, r7
add64 r1, -0x2fa1e
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0x5e2
jgt r2, r1, -0x73
mov64 r1, r7
add64 r1, -0x3134b
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r2, 0xaedb5
jgt r2, r1, -0x79
mov64 r1, 0x1
mov64 r3, r7
lsh64 r3, 0x20
rsh64 r3, 0x20
mov64 r4, r7
jgt r3, 0xe01ef, -0x7f
ja +0x4
mov64 r4, 0x27
mov64 r5, r3
and64 r5, 0x100
jeq r5, 0x0, -0xa3
stxdw [r6+0x8], r2
stxw [r6+0x4], r4
stxw [r6+0x0], r1
stxdw [r6+0x10], r7
exit
fn_10538:
mov64 r8, r1
ldxdw r6, [r2+0x20]
ldxdw r7, [r2+0x28]
ldxdw r4, [r7+0x18]
mov64 r1, r6
lddw r2, 0x16f5d
mov64 r3, 0xc
callx r4
mov64 r9, 0x1
jne r0, 0x0, +0x5d
ldxdw r1, [r8+0x10]
jeq r1, 0x0, +0x1a
stxdw [r10-0x68], r1
lddw r1, 0x14a98
stxdw [r10-0x58], r1
mov64 r1, r10
add64 r1, -0x68
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x10], r1
mov64 r1, 0x0
stxdw [r10-0x20], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
lddw r1, 0x17d50
stxdw [r10-0x30], r1
mov64 r9, 0x1
stxdw [r10-0x8], r9
mov64 r3, r10
add64 r3, -0x30
mov64 r1, r6
mov64 r2, r7
call fn_10b58
jne r0, 0x0, +0x42
ja +0x21
ldxdw r9, [r8+0x0]
ldxdw r1, [r8+0x8]
ldxdw r2, [r1+0x18]
mov64 r1, r9
callx r2
lddw r1, 0x7ef2a91eecc7bcf4
jne r0, r1, +0x19
stxdw [r10-0x68], r9
lddw r1, 0x14a30
stxdw [r10-0x58], r1
mov64 r1, r10
add64 r1, -0x68
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x10], r1
mov64 r1, 0x0
stxdw [r10-0x20], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
lddw r1, 0x17d50
stxdw [r10-0x30], r1
mov64 r9, 0x1
stxdw [r10-0x8], r9
mov64 r3, r10
add64 r3, -0x30
mov64 r1, r6
mov64 r2, r7
call fn_10b58
jne r0, 0x0, +0x20
ldxdw r1, [r8+0x18]
mov64 r2, r1
add64 r2, 0x14
stxdw [r10-0x40], r2
lddw r2, 0x14410
stxdw [r10-0x38], r2
stxdw [r10-0x48], r2
mov64 r2, r1
add64 r2, 0x10
stxdw [r10-0x50], r2
lddw r2, 0x14a68
stxdw [r10-0x58], r2
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x10], r1
mov64 r1, 0x0
stxdw [r10-0x20], r1
mov64 r1, 0x3
stxdw [r10-0x8], r1
stxdw [r10-0x28], r1
lddw r1, 0x17d00
stxdw [r10-0x30], r1
mov64 r3, r10
add64 r3, -0x30
mov64 r1, r6
mov64 r2, r7
call fn_10b58
mov64 r9, r0
mov64 r0, r9
exit
fn_10888:
lddw r4, 0x16f20
stxdw [r10-0x20], r4
mov64 r4, 0x0
stxdw [r10-0x18], r4
stxdw [r10-0x30], r4
mov64 r4, 0x1
stxdw [r10-0x38], r4
mov64 r4, r10
add64 r4, -0x10
stxdw [r10-0x40], r4
stxdw [r10-0x8], r2
stxdw [r10-0x10], r1
mov64 r1, r10
add64 r1, -0x40
mov64 r2, r3
call fn_109f8
fn_10910:
call fn_10910
fn_10918:
stxdw [r10-0x58], r2
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x30], r1
mov64 r1, 0x0
stxdw [r10-0x40], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
stxdw [r10-0x48], r1
lddw r1, 0x17d70
stxdw [r10-0x50], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x10], r1
lddw r1, 0x146e8
stxdw [r10-0x8], r1
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x58
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r3
call fn_109f8
fn_109f0:
call fn_109f0
fn_109f8:
stxdw [r10-0x8], r2
stxdw [r10-0x10], r1
lddw r1, 0x17d30
stxdw [r10-0x18], r1
lddw r1, 0x16f20
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x20
call fn_f2a8
fn_10a50:
call fn_10a50
fn_10a58:
stxdw [r10-0x68], r2
stxdw [r10-0x70], r1
stxdw [r10-0x58], r4
stxdw [r10-0x60], r3
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x30], r1
mov64 r1, 0x0
stxdw [r10-0x40], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
stxdw [r10-0x48], r1
lddw r1, 0x17d90
stxdw [r10-0x50], r1
lddw r1, 0x14a00
stxdw [r10-0x8], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x10], r1
lddw r1, 0x14a68
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x70
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r5
call fn_109f8
fn_10b50:
call fn_10b50
fn_10b58:
mov64 r4, 0x3
stxb [r10-0x8], r4
lddw r4, 0x2000000000
stxdw [r10-0x10], r4
stxdw [r10-0x18], r2
stxdw [r10-0x20], r1
mov64 r7, 0x0
stxdw [r10-0x30], r7
stxdw [r10-0x40], r7
ldxdw r8, [r3+0x10]
stxdw [r10-0x48], r3
jne r8, 0x0, +0x1e
ldxdw r6, [r3+0x28]
jeq r6, 0x0, +0x6b
ldxdw r1, [r10-0x48]
ldxdw r8, [r1+0x20]
mov64 r7, 0x0
lsh64 r6, 0x4
add64 r8, 0x8
ldxdw r9, [r1+0x0]
add64 r9, 0x8
ldxdw r3, [r9+0x0]
jne r3, 0x0, +0x1
ja +0x6
ldxdw r1, [r10-0x18]
ldxdw r4, [r1+0x18]
ldxdw r2, [r9-0x8]
ldxdw r1, [r10-0x20]
callx r4
jne r0, 0x0, +0x6e
ldxdw r1, [r8-0x8]
ldxdw r3, [r8+0x0]
mov64 r2, r10
add64 r2, -0x40
callx r3
jne r0, 0x0, +0x68
add64 r7, 0x1
add64 r8, 0x10
add64 r9, 0x10
add64 r6, -0x10
jeq r6, 0x0, +0x50
ja -0x15
ldxdw r9, [r3+0x18]
jeq r9, 0x0, +0x4d
mov64 r7, 0x0
add64 r8, 0x30
mul64 r9, 0x38
ldxdw r1, [r10-0x48]
ldxdw r6, [r1+0x0]
add64 r6, 0x8
ldxdw r3, [r6+0x0]
jne r3, 0x0, +0xe
ldxdw r1, [r10-0x48]
ldxdw r2, [r1+0x20]
ldxw r1, [r8-0x8]
stxw [r10-0xc], r1
ldxb r1, [r8+0x0]
stxb [r10-0x8], r1
ldxw r1, [r8-0x4]
stxw [r10-0x10], r1
ldxdw r1, [r8-0x10]
ldxdw r4, [r8-0x18]
jeq r4, 0x0, +0xa
mov64 r3, 0x0
jeq r4, 0x1, +0xa
ja +0x13
ldxdw r1, [r10-0x18]
ldxdw r4, [r1+0x18]
ldxdw r2, [r6-0x8]
ldxdw r1, [r10-0x20]
callx r4
jne r0, 0x0, +0x44
ja -0x15
mov64 r3, 0x1
ja +0xa
lsh64 r1, 0x4
mov64 r4, r2
add64 r4, r1
ldxdw r5, [r4+0x8]
lddw r0, 0xfdd0
jne r5, r0, +0x3
mov64 r3, 0x1
ldxdw r1, [r4+0x0]
ldxdw r1, [r1+0x0]
stxdw [r10-0x38], r1
stxdw [r10-0x40], r3
ldxdw r1, [r8-0x20]
ldxdw r4, [r8-0x28]
jeq r4, 0x0, +0x3
mov64 r3, 0x0
jeq r4, 0x1, +0x3
ja +0xc
mov64 r3, 0x1
ja +0xa
lsh64 r1, 0x4
mov64 r4, r2
add64 r4, r1
ldxdw r5, [r4+0x8]
lddw r0, 0xfdd0
jne r5, r0, +0x3
mov64 r3, 0x1
ldxdw r1, [r4+0x0]
ldxdw r1, [r1+0x0]
stxdw [r10-0x28], r1
stxdw [r10-0x30], r3
ldxdw r1, [r8-0x30]
lsh64 r1, 0x4
add64 r2, r1
ldxdw r1, [r2+0x0]
ldxdw r3, [r2+0x8]
mov64 r2, r10
add64 r2, -0x40
callx r3
jne r0, 0x0, +0x18
add64 r7, 0x1
add64 r8, 0x38
add64 r6, 0x10
add64 r9, -0x38
jne r9, 0x0, -0x47
mov64 r2, r7
lsh64 r2, 0x4
ldxdw r3, [r10-0x48]
ldxdw r1, [r3+0x0]
add64 r1, r2
ldxdw r2, [r3+0x8]
jgt r2, r7, +0x1
mov64 r1, 0x0
jgt r2, r7, +0x1
ja +0x7
ldxdw r2, [r10-0x18]
ldxdw r4, [r2+0x18]
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
ldxdw r1, [r10-0x20]
callx r4
jne r0, 0x0, +0x2
mov64 r0, 0x0
ja +0x1
mov64 r0, 0x1
exit
fn_10fd0:
ldxdw r0, [r5-0xff8]
jeq r2, 0x0, +0x9
mov64 r8, r3
mov64 r7, 0x110000
ldxw r9, [r1+0x30]
mov64 r2, r9
and64 r2, 0x1
mov64 r6, r0
jeq r2, 0x0, +0x7
mov64 r7, 0x2b
ja +0x3
mov64 r8, r3
mov64 r7, 0x2d
ldxw r9, [r1+0x30]
mov64 r6, r0
add64 r6, 0x1
stxdw [r10-0x18], r0
mov64 r3, 0x0
mov64 r2, r9
and64 r2, 0x4
jeq r2, 0x0, +0x1
ja +0xa
ldxdw r2, [r5-0x1000]
stxdw [r10-0x20], r2
ldxdw r2, [r1+0x0]
jeq r2, 0x1, +0x1f
mov64 r6, r1
mov64 r2, r7
call fn_116f8
mov64 r7, 0x1
jne r0, 0x0, +0x3e
ja +0x36
stxdw [r10-0x28], r7
mov64 r2, 0x0
stxdw [r10-0x10], r4
mov64 r3, r8
jeq r4, 0x0, +0x8
mov64 r2, 0x0
ldxdw r4, [r10-0x10]
mov64 r0, r3
ja +0x9
add64 r2, r7
add64 r0, 0x1
add64 r4, -0x1
jne r4, 0x0, +0x5
add64 r2, r6
mov64 r6, r2
ldxdw r4, [r10-0x10]
ldxdw r7, [r10-0x28]
ja -0x1c
ldxb r8, [r0+0x0]
lsh64 r8, 0x38
arsh64 r8, 0x38
mov64 r7, 0x1
jsgt r8, -0x41, -0xe
mov64 r7, 0x0
ja -0x10
ldxdw r8, [r1+0x8]
jge r6, r8, +0x16
and64 r9, 0x8
stxdw [r10-0x30], r1
jeq r9, 0x0, +0x1
ja +0x21
stxdw [r10-0x40], r3
stxdw [r10-0x10], r4
ldxb r2, [r1+0x38]
mov64 r1, 0x1
jeq r2, 0x3, +0x1
mov64 r1, r2
sub64 r8, r6
mov64 r9, 0x0
and64 r1, 0x3
stxdw [r10-0x38], r8
jeq r1, 0x0, +0x35
jeq r1, 0x1, +0x31
mov64 r9, r8
rsh64 r9, 0x1
add64 r8, 0x1
rsh64 r8, 0x1
stxdw [r10-0x38], r8
ja +0x2e
mov64 r6, r1
mov64 r2, r7
call fn_116f8
mov64 r7, 0x1
jne r0, 0x0, +0x7
ldxdw r1, [r6+0x20]
ldxdw r2, [r6+0x28]
ldxdw r4, [r2+0x18]
ldxdw r2, [r10-0x20]
ldxdw r3, [r10-0x18]
callx r4
mov64 r7, r0
and64 r7, 0x1
mov64 r0, r7
exit
ldxw r2, [r1+0x34]
stxdw [r10-0x28], r2
mov64 r2, 0x30
stxw [r1+0x34], r2
ldxb r2, [r1+0x38]
stxdw [r10-0x38], r2
mov64 r2, r7
mov64 r7, 0x1
stxb [r1+0x38], r7
call fn_116f8
jne r0, 0x0, -0xe
ldxdw r1, [r10-0x30]
ldxb r2, [r1+0x38]
mov64 r1, 0x1
jeq r2, 0x3, +0x1
mov64 r1, r2
sub64 r8, r6
mov64 r9, 0x0
and64 r1, 0x3
stxdw [r10-0x10], r8
jeq r1, 0x0, +0x41
jeq r1, 0x1, +0x3d
mov64 r9, r8
rsh64 r9, 0x1
add64 r8, 0x1
rsh64 r8, 0x1
stxdw [r10-0x10], r8
ja +0x3a
mov64 r1, 0x0
stxdw [r10-0x38], r1
mov64 r9, r8
stxdw [r10-0x28], r7
add64 r9, 0x1
ldxdw r1, [r10-0x30]
ldxw r2, [r1+0x34]
stxdw [r10-0x8], r2
ldxdw r8, [r1+0x28]
ldxdw r6, [r1+0x20]
mov64 r7, 0x1
add64 r9, -0x1
jeq r9, 0x0, +0x6
ldxdw r3, [r8+0x20]
mov64 r1, r6
ldxdw r2, [r10-0x8]
callx r3
jne r0, 0x0, -0x31
ja -0x8
mov64 r7, 0x1
ldxdw r1, [r10-0x8]
jeq r1, 0x110000, -0x35
ldxdw r1, [r10-0x30]
ldxdw r2, [r10-0x28]
ldxdw r3, [r10-0x40]
ldxdw r4, [r10-0x10]
call fn_116f8
jne r0, 0x0, -0x3b
ldxdw r2, [r10-0x30]
ldxdw r1, [r2+0x20]
ldxdw r2, [r2+0x28]
ldxdw r4, [r2+0x18]
ldxdw r2, [r10-0x20]
ldxdw r3, [r10-0x18]
callx r4
jne r0, 0x0, -0x43
mov64 r7, 0x0
ldxdw r1, [r10-0x30]
ldxdw r8, [r1+0x28]
ldxdw r6, [r1+0x20]
ldxdw r9, [r10-0x38]
mov64 r1, r9
jeq r9, r7, +0x8
ldxdw r3, [r8+0x20]
mov64 r1, r6
ldxdw r2, [r10-0x8]
callx r3
add64 r7, 0x1
jeq r0, 0x0, -0x8
add64 r7, -0x1
mov64 r1, r7
mov64 r7, 0x1
jgt r9, r1, -0x54
mov64 r7, 0x0
ja -0x56
mov64 r1, 0x0
stxdw [r10-0x10], r1
mov64 r9, r8
add64 r9, 0x1
ldxdw r1, [r10-0x30]
ldxw r2, [r1+0x34]
stxdw [r10-0x8], r2
ldxdw r8, [r1+0x28]
ldxdw r6, [r1+0x20]
mov64 r7, 0x1
add64 r9, -0x1
jeq r9, 0x0, +0x6
ldxdw r3, [r8+0x20]
mov64 r1, r6
ldxdw r2, [r10-0x8]
callx r3
jne r0, 0x0, -0x67
ja -0x8
mov64 r7, 0x1
ldxdw r1, [r10-0x8]
jeq r1, 0x110000, -0x6b
ldxdw r2, [r10-0x30]
ldxdw r1, [r2+0x20]
ldxdw r2, [r2+0x28]
ldxdw r4, [r2+0x18]
ldxdw r2, [r10-0x20]
ldxdw r3, [r10-0x18]
callx r4
jne r0, 0x0, -0x73
mov64 r9, 0x0
ldxdw r1, [r10-0x30]
ldxdw r8, [r1+0x28]
ldxdw r6, [r1+0x20]
ldxdw r1, [r10-0x10]
jeq r1, r9, +0x9
ldxdw r3, [r8+0x20]
mov64 r1, r6
ldxdw r2, [r10-0x8]
callx r3
add64 r9, 0x1
jeq r0, 0x0, -0x8
add64 r9, -0x1
ldxdw r1, [r10-0x10]
jgt r1, r9, -0x82
ldxdw r1, [r10-0x30]
ldxdw r2, [r10-0x38]
stxb [r1+0x38], r2
ldxdw r2, [r10-0x28]
stxw [r1+0x34], r2
ja -0x34
fn_116f8:
mov64 r6, r4
mov64 r7, r3
mov64 r8, r1
mov64 r1, r2
lsh64 r1, 0x20
rsh64 r1, 0x20
jeq r1, 0x110000, +0x7
ldxdw r1, [r8+0x20]
ldxdw r3, [r8+0x28]
ldxdw r3, [r3+0x20]
callx r3
mov64 r1, r0
mov64 r0, 0x1
jne r1, 0x0, +0x2
mov64 r0, 0x0
jne r7, 0x0, +0x1
exit
ldxdw r1, [r8+0x20]
ldxdw r2, [r8+0x28]
ldxdw r4, [r2+0x18]
mov64 r2, r7
mov64 r3, r6
callx r4
ja -0x8
fn_117b8:
ldxdw r4, [r1+0x10]
ldxdw r5, [r1+0x0]
jeq r5, 0x1, +0x2
jeq r4, 0x1, +0x3
ja +0x65
jeq r4, 0x1, +0x1
ja +0x48
stxdw [r10-0x8], r5
mov64 r5, 0x0
mov64 r4, r2
stxdw [r10-0x18], r3
add64 r4, r3
ldxdw r3, [r1+0x18]
stxdw [r10-0x10], r2
mov64 r8, r2
jeq r3, 0x0, +0x28
mov64 r5, 0x0
ldxdw r8, [r10-0x10]
mov64 r7, 0x0
mov64 r9, r8
jeq r9, r4, +0x35
mov64 r8, r9
add64 r8, 0x1
ldxb r0, [r9+0x0]
mov64 r6, r0
lsh64 r6, 0x38
arsh64 r6, 0x38
jsgt r6, -0x1, +0x18
mov64 r8, r9
add64 r8, 0x2
mov64 r2, 0xe0
jgt r2, r0, +0x14
mov64 r8, r9
add64 r8, 0x3
mov64 r2, 0xf0
jgt r2, r0, +0x10
ldxb r6, [r9+0x1]
and64 r6, 0x3f
lsh64 r6, 0xc
ldxb r2, [r9+0x2]
and64 r2, 0x3f
lsh64 r2, 0x6
or64 r2, r6
ldxb r6, [r9+0x3]
and64 r6, 0x3f
or64 r2, r6
lsh64 r0, 0x12
and64 r0, 0x1c0000
or64 r2, r0
mov64 r8, r9
add64 r8, 0x4
jeq r2, 0x110000, +0x16
add64 r7, 0x1
sub64 r5, r9
add64 r5, r8
jgt r3, r7, -0x25
jeq r8, r4, +0x11
ldxb r4, [r8+0x0]
mov64 r2, 0xf0
jgt r2, r4, +0x42
ldxb r2, [r8+0x1]
and64 r2, 0x3f
lsh64 r2, 0xc
ldxb r3, [r8+0x2]
and64 r3, 0x3f
lsh64 r3, 0x6
or64 r3, r2
ldxb r2, [r8+0x3]
and64 r2, 0x3f
or64 r3, r2
lsh64 r4, 0x12
and64 r4, 0x1c0000
or64 r3, r4
jne r3, 0x110000, +0x34
ldxdw r3, [r10-0x18]
ldxdw r2, [r10-0x10]
ldxdw r4, [r10-0x8]
jeq r4, 0x1, +0x1
ja +0x1b
mov64 r8, 0x0
ldxdw r9, [r1+0x8]
jeq r3, 0x0, +0x8
mov64 r8, 0x0
mov64 r4, r3
mov64 r5, r2
ja +0xd
add64 r8, r0
add64 r5, 0x1
add64 r4, -0x1
jne r4, 0x0, +0x9
jge r8, r9, +0xf
stxdw [r10-0x10], r2
stxdw [r10-0x18], r3
ldxb r5, [r1+0x38]
mov64 r7, 0x0
mov64 r4, 0x0
jeq r5, 0x3, +0x12
mov64 r4, r5
ja +0x10
ldxb r6, [r5+0x0]
lsh64 r6, 0x38
arsh64 r6, 0x38
mov64 r0, 0x1
jsgt r6, -0x41, -0x12
mov64 r0, 0x0
ja -0x14
ldxdw r5, [r1+0x20]
ldxdw r1, [r1+0x28]
ldxdw r4, [r1+0x18]
mov64 r1, r5
callx r4
mov64 r6, r0
and64 r6, 0x1
mov64 r0, r6
exit
sub64 r9, r8
and64 r4, 0x3
stxdw [r10-0x20], r9
jeq r4, 0x0, +0x13
jeq r4, 0x1, +0xf
mov64 r7, r9
rsh64 r7, 0x1
add64 r9, 0x1
rsh64 r9, 0x1
stxdw [r10-0x20], r9
ja +0xc
mov64 r3, 0x0
ldxdw r6, [r10-0x18]
ldxdw r7, [r10-0x10]
jeq r5, 0x0, +0x3b
jgt r6, r5, +0x31
mov64 r4, 0x0
mov64 r3, r6
jeq r5, r6, +0x37
ja +0x38
mov64 r2, 0x0
stxdw [r10-0x20], r2
mov64 r7, r9
add64 r7, 0x1
ldxw r8, [r1+0x34]
ldxdw r2, [r1+0x28]
stxdw [r10-0x8], r2
ldxdw r9, [r1+0x20]
mov64 r6, 0x1
add64 r7, -0x1
jeq r7, 0x0, +0x7
ldxdw r1, [r10-0x8]
ldxdw r3, [r1+0x20]
mov64 r1, r9
mov64 r2, r8
callx r3
jne r0, 0x0, -0x28
ja -0x9
mov64 r6, 0x1
mov64 r1, r8
jeq r1, 0x110000, -0x2c
ldxdw r1, [r10-0x8]
ldxdw r4, [r1+0x18]
mov64 r1, r9
ldxdw r2, [r10-0x10]
ldxdw r3, [r10-0x18]
callx r4
jne r0, 0x0, -0x33
mov64 r6, 0x0
ldxdw r7, [r10-0x20]
mov64 r1, r7
jeq r7, r6, +0x9
ldxdw r1, [r10-0x8]
ldxdw r3, [r1+0x20]
mov64 r1, r9
mov64 r2, r8
callx r3
add64 r6, 0x1
jeq r0, 0x0, -0x9
add64 r6, -0x1
mov64 r1, r6
mov64 r6, 0x1
jgt r7, r1, -0x42
mov64 r6, 0x0
ja -0x44
mov64 r2, r7
add64 r2, r5
mov64 r4, 0x0
ldxb r2, [r2+0x0]
lsh64 r2, 0x38
arsh64 r2, 0x38
mov64 r0, -0x40
mov64 r3, r5
jsgt r0, r2, +0x2
mov64 r5, r3
mov64 r4, r7
jeq r4, 0x0, +0x1
mov64 r6, r5
stxdw [r10-0x18], r6
jeq r4, 0x0, +0x1
mov64 r7, r4
stxdw [r10-0x10], r7
ja -0x7c
fn_11de8:
ldxdw r4, [r1+0x20]
ldxdw r1, [r1+0x28]
ldxdw r5, [r1+0x18]
mov64 r1, r4
callx r5
exit
fn_11e18:
ldxdw r6, [r1+0x28]
ldxdw r7, [r1+0x20]
mov64 r8, r10
add64 r8, -0x30
mov64 r1, r8
mov64 r3, 0x30
call fn_15878
mov64 r1, r7
mov64 r2, r6
mov64 r3, r8
call fn_10b58
exit
fn_11e78:
ldxw r0, [r1+0x30]
and64 r0, 0x10
rsh64 r0, 0x4
exit
fn_11e98:
ldxw r0, [r1+0x30]
and64 r0, 0x20
rsh64 r0, 0x5
exit
fn_11eb8:
mov64 r8, r2
mov64 r6, r1
ldxdw r7, [r3+0x20]
ldxdw r1, [r3+0x28]
stxdw [r10-0x38], r1
ldxdw r3, [r1+0x20]
mov64 r1, r7
mov64 r2, 0x22
stxdw [r10-0x20], r3
callx r3
mov64 r1, 0x1
jne r0, 0x0, +0x137
mov64 r1, 0x0
jeq r8, 0x0, +0x126
mov64 r1, r6
stxdw [r10-0x58], r8
add64 r1, r8
stxdw [r10-0x68], r1
mov64 r1, 0x0
stxdw [r10-0x28], r1
mov64 r8, r6
mov64 r0, r6
mov64 r1, 0x0
stxdw [r10-0x30], r1
stxdw [r10-0x70], r8
mov64 r1, r0
ldxb r3, [r1+0x0]
mov64 r2, r3
lsh64 r2, 0x38
arsh64 r2, 0x38
jsgt r2, -0x1, +0x2b
mov64 r6, r1
add64 r6, 0x2
ldxb r9, [r1+0x1]
and64 r9, 0x3f
mov64 r4, r3
and64 r4, 0x1f
mov64 r2, r4
lsh64 r2, 0x6
or64 r2, r9
jgt r3, 0xdf, +0x1
ja +0x23
lsh64 r9, 0x6
ldxb r5, [r1+0x2]
and64 r5, 0x3f
or64 r9, r5
mov64 r6, r1
add64 r6, 0x3
mov64 r5, r4
lsh64 r5, 0xc
mov64 r2, r9
or64 r2, r5
mov64 r5, 0xf0
jgt r5, r3, +0x17
lsh64 r9, 0x6
ldxb r3, [r1+0x3]
and64 r3, 0x3f
or64 r9, r3
lsh64 r4, 0x12
and64 r4, 0x1c0000
or64 r9, r4
add64 r1, 0x4
mov64 r6, r1
mov64 r2, r9
jne r9, 0x110000, +0xc
mov64 r1, 0x0
mov64 r6, r8
ldxdw r8, [r10-0x58]
ldxdw r3, [r10-0x28]
jeq r3, 0x0, +0xee
jgt r8, r3, +0xdf
mov64 r1, r3
jeq r3, r8, +0xeb
ja +0xe3
add64 r1, 0x1
mov64 r6, r1
mov64 r2, r3
stxdw [r10-0x48], r6
stxdw [r10-0x40], r0
mov64 r1, r10
add64 r1, -0x18
stxdw [r10-0x60], r2
mov64 r3, 0x10001
call fn_ff60
ldxw r6, [r10-0x18]
jsgt r6, 0x1, +0xa
ldxdw r3, [r10-0x30]
jeq r6, 0x0, +0x1d
ldxdw r1, [r10-0x40]
sub64 r3, r1
ldxdw r0, [r10-0x48]
add64 r3, r0
stxdw [r10-0x30], r3
ldxdw r1, [r10-0x68]
jeq r0, r1, -0x1e
ja -0x47
ldxdw r3, [r10-0x30]
jeq r6, 0x2, +0x13
ldxb r2, [r10-0x4]
jsgt r2, 0x2, +0x5
mov64 r1, 0x0
jeq r2, 0x0, +0xc
jeq r2, 0x1, +0x6
mov64 r1, 0x2
ja +0x9
jeq r2, 0x3, +0x5
jeq r2, 0x4, +0x6
mov64 r1, 0x5
ja +0x5
mov64 r1, 0x1
ja +0x3
mov64 r1, 0x3
ja +0x1
mov64 r1, 0x4
ldxdw r2, [r10-0x10]
add64 r1, r2
jeq r1, 0x1, -0x1d
ldxdw r5, [r10-0x58]
ldxdw r0, [r10-0x28]
jgt r0, r3, +0x5f
jeq r0, 0x0, +0xa
jgt r5, r0, +0x2
jeq r0, r5, +0x8
ja +0x5b
mov64 r1, r8
add64 r1, r0
ldxb r1, [r1+0x0]
lsh64 r1, 0x38
arsh64 r1, 0x38
mov64 r2, -0x40
jsgt r2, r1, +0x54
jeq r3, 0x0, +0x3
jgt r5, r3, +0x4c
jeq r3, r5, +0x1
ja +0x50
add64 r8, r0
sub64 r3, r0
ldxdw r1, [r10-0x38]
ldxdw r4, [r1+0x18]
mov64 r1, r7
mov64 r2, r8
callx r4
jne r0, 0x0, +0x57
ldxb r9, [r10-0x4]
ldxw r1, [r10-0x8]
stxdw [r10-0x50], r1
ldxdw r8, [r10-0x10]
ldxw r1, [r10-0x14]
stxdw [r10-0x28], r1
jeq r1, 0x110000, +0x52
mov64 r1, r8
lsh64 r6, 0x20
mov64 r3, r6
rsh64 r3, 0x20
jsgt r3, 0x1, +0x1
ja +0xe
mov64 r6, 0x1
mov64 r2, 0x5c
mov64 r8, r1
jeq r3, 0x2, +0xf
mov64 r6, 0x3
mov64 r3, r9
and64 r3, 0xff
jsgt r3, 0x2, +0x10
mov64 r9, 0x0
mov64 r2, 0x7d
mov64 r8, r1
jeq r3, 0x1, +0x7
jeq r3, 0x2, +0xf
ja +0x46
jeq r3, 0x1, +0x1
ja +0x44
mov64 r6, 0x0
ldxdw r2, [r10-0x28]
mov64 r8, r1
mov64 r1, r7
ldxdw r3, [r10-0x20]
callx r3
jne r0, 0x0, +0x33
ja -0x1e
jeq r3, 0x3, +0x14
jeq r3, 0x4, +0x16
mov64 r9, 0x4
ja -0xa
mov64 r2, r1
lsh64 r2, 0x2
and64 r2, 0x1c
ldxdw r3, [r10-0x50]
rsh64 r3, r2
and64 r3, 0xf
mov64 r2, 0x30
mov64 r4, 0xa
jgt r4, r3, +0x1
mov64 r2, 0x57
add64 r2, r3
mov64 r8, 0x0
mov64 r9, 0x1
jeq r1, 0x0, -0x17
mov64 r9, 0x2
add64 r1, -0x1
ja -0x1b
mov64 r9, 0x2
mov64 r2, 0x7b
ja -0x1e
mov64 r9, 0x3
mov64 r2, 0x75
mov64 r8, r1
mov64 r6, 0x3
ja -0x22
mov64 r1, r8
add64 r1, r3
ldxb r1, [r1+0x0]
lsh64 r1, 0x38
arsh64 r1, 0x38
jsgt r1, -0x41, -0x50
mov64 r1, r8
mov64 r2, r5
mov64 r4, r3
mov64 r3, r0
lddw r5, 0x17dc8
call fn_13020
fn_125a8:
call fn_125a8
mov64 r9, 0x2
mov64 r2, 0x7b
mov64 r8, r1
mov64 r1, r7
ldxdw r3, [r10-0x20]
callx r3
jeq r0, 0x0, +0x2
mov64 r1, 0x1
ja +0x5b
mov64 r1, r8
mov64 r2, 0x5c
lsh64 r6, 0x20
mov64 r3, r6
rsh64 r3, 0x20
mov64 r6, 0x1
jeq r3, 0x2, -0xd
jeq r3, 0x3, +0x8
ldxdw r5, [r10-0x58]
ldxdw r8, [r10-0x70]
mov64 r0, 0x1
mov64 r1, 0x80
ldxdw r3, [r10-0x30]
ldxdw r2, [r10-0x60]
jgt r1, r2, +0x2c
ja +0x24
mov64 r6, 0x3
mov64 r3, r9
and64 r3, 0xff
jsgt r3, 0x2, +0x6
mov64 r9, 0x0
mov64 r2, 0x7d
mov64 r8, r1
jeq r3, 0x1, -0x1e
jeq r3, 0x2, +0x5
ja -0x12
jeq r3, 0x3, -0x24
jeq r3, 0x4, +0x13
mov64 r9, 0x4
ja -0x25
mov64 r2, r1
lsh64 r2, 0x2
and64 r2, 0x1c
ldxdw r3, [r10-0x50]
rsh64 r3, r2
and64 r3, 0xf
mov64 r2, 0x30
mov64 r4, 0xa
jgt r4, r3, +0x1
mov64 r2, 0x57
add64 r2, r3
mov64 r8, 0x0
mov64 r9, 0x1
jeq r1, 0x0, -0x32
mov64 r9, 0x2
add64 r1, -0x1
ja -0x36
mov64 r9, 0x3
mov64 r2, 0x75
mov64 r8, r1
mov64 r6, 0x3
ja -0x3a
mov64 r0, 0x2
mov64 r1, 0x800
jgt r1, r2, +0x4
mov64 r0, 0x3
mov64 r1, 0x10000
jgt r1, r2, +0x1
mov64 r0, 0x4
add64 r0, r3
stxdw [r10-0x28], r0
ja -0xce
mov64 r1, r6
add64 r1, r3
ldxb r2, [r1+0x0]
lsh64 r2, 0x38
arsh64 r2, 0x38
mov64 r1, r3
jsgt r2, -0x41, +0x7
mov64 r1, r6
mov64 r2, r8
mov64 r4, r8
lddw r5, 0x17de0
call fn_13020
fn_12850:
call fn_12850
add64 r6, r1
sub64 r8, r1
ldxdw r1, [r10-0x38]
ldxdw r4, [r1+0x18]
mov64 r1, r7
mov64 r2, r6
mov64 r3, r8
callx r4
mov64 r1, 0x1
jne r0, 0x0, +0x5
mov64 r1, r7
mov64 r2, 0x22
ldxdw r3, [r10-0x20]
callx r3
mov64 r1, r0
mov64 r0, r1
exit
fn_128e0:
mov64 r4, r2
mov64 r2, r1
mov64 r1, r3
mov64 r3, r4
call fn_117b8
exit
mov64 r8, r1
ldxdw r1, [r2+0x20]
ldxdw r2, [r2+0x28]
ldxdw r3, [r2+0x20]
stxdw [r10-0x20], r1
mov64 r2, 0x27
stxdw [r10-0x28], r3
callx r3
mov64 r7, 0x1
jne r0, 0x0, +0x56
ldxw r2, [r8+0x0]
mov64 r1, r10
add64 r1, -0x18
mov64 r3, 0x101
call fn_ff60
ldxb r9, [r10-0x4]
ldxw r1, [r10-0x8]
stxdw [r10-0x38], r1
ldxdw r6, [r10-0x10]
ldxw r8, [r10-0x18]
ldxw r1, [r10-0x14]
stxdw [r10-0x30], r1
jeq r1, 0x110000, +0x2
mov64 r7, 0x1
ja +0x10
mov64 r7, 0x1
ja +0x47
jeq r3, 0x1, +0x6
ldxdw r1, [r10-0x20]
mov64 r2, 0x27
ldxdw r3, [r10-0x28]
callx r3
mov64 r7, r0
ja +0x3e
mov64 r8, 0x0
ldxdw r2, [r10-0x30]
mov64 r6, r1
ldxdw r1, [r10-0x20]
ldxdw r3, [r10-0x28]
callx r3
jne r0, 0x0, +0x37
mov64 r1, r6
lsh64 r8, 0x20
mov64 r3, r8
rsh64 r3, 0x20
jsgt r3, 0x1, +0x1
ja -0x14
mov64 r8, 0x1
mov64 r2, 0x5c
mov64 r6, r1
jeq r3, 0x2, -0xe
mov64 r8, 0x3
mov64 r3, r9
and64 r3, 0xff
jsgt r3, 0x2, +0x6
mov64 r9, 0x0
mov64 r2, 0x7d
mov64 r6, r1
jeq r3, 0x1, -0x16
jeq r3, 0x2, +0x5
ja -0x21
jeq r3, 0x3, +0x14
jeq r3, 0x4, +0x16
mov64 r9, 0x4
ja -0x1d
mov64 r2, r1
lsh64 r2, 0x2
and64 r2, 0x1c
ldxdw r3, [r10-0x38]
rsh64 r3, r2
and64 r3, 0xf
mov64 r2, 0x30
mov64 r4, 0xa
jgt r4, r3, +0x1
mov64 r2, 0x57
add64 r2, r3
mov64 r6, 0x0
mov64 r9, 0x1
jeq r1, 0x0, -0x2a
mov64 r9, 0x2
add64 r1, -0x1
ja -0x2e
mov64 r9, 0x2
mov64 r2, 0x7b
ja -0x31
mov64 r8, 0x3
mov64 r2, 0x75
mov64 r9, 0x3
ja -0x35
mov64 r9, 0x2
mov64 r2, 0x7b
mov64 r6, r1
ldxdw r1, [r10-0x20]
ldxdw r3, [r10-0x28]
callx r3
jeq r0, 0x0, +0x2
mov64 r0, r7
exit
mov64 r1, r6
mov64 r2, 0x5c
lsh64 r8, 0x20
mov64 r3, r8
rsh64 r3, 0x20
mov64 r8, 0x1
jeq r3, 0x2, -0xd
jeq r3, 0x3, +0x1
ja -0x4f
mov64 r8, 0x3
mov64 r3, r9
and64 r3, 0xff
jsgt r3, 0x2, +0x6
mov64 r9, 0x0
mov64 r2, 0x7d
mov64 r6, r1
jeq r3, 0x1, -0x17
jeq r3, 0x2, +0x5
ja -0x59
jeq r3, 0x3, -0x1d
jeq r3, 0x4, +0x13
mov64 r9, 0x4
ja -0x1e
mov64 r2, r1
lsh64 r2, 0x2
and64 r2, 0x1c
ldxdw r3, [r10-0x38]
rsh64 r3, r2
and64 r3, 0xf
mov64 r2, 0x30
mov64 r4, 0xa
jgt r4, r3, +0x1
mov64 r2, 0x57
add64 r2, r3
mov64 r6, 0x0
mov64 r9, 0x1
jeq r1, 0x0, -0x2b
mov64 r9, 0x2
add64 r1, -0x1
ja -0x2f
mov64 r8, 0x3
mov64 r2, 0x75
mov64 r9, 0x3
ja -0x33
fn_12d80:
stxdw [r10-0x58], r2
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x30], r1
mov64 r1, 0x0
stxdw [r10-0x40], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
stxdw [r10-0x48], r1
lddw r1, 0x17df8
stxdw [r10-0x50], r1
mov64 r1, r10
add64 r1, -0x58
stxdw [r10-0x10], r1
lddw r1, 0x146e8
stxdw [r10-0x8], r1
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r3
call fn_109f8
fn_12e58:
call fn_12e58
fn_12e60:
stxdw [r10-0x58], r2
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x30], r1
mov64 r1, 0x0
stxdw [r10-0x40], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
stxdw [r10-0x48], r1
lddw r1, 0x17e18
stxdw [r10-0x50], r1
mov64 r1, r10
add64 r1, -0x58
stxdw [r10-0x10], r1
lddw r1, 0x146e8
stxdw [r10-0x8], r1
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r3
call fn_109f8
fn_12f38:
call fn_12f38
fn_12f40:
stxdw [r10-0x58], r2
stxdw [r10-0x60], r1
mov64 r1, r10
add64 r1, -0x20
stxdw [r10-0x30], r1
mov64 r1, 0x0
stxdw [r10-0x40], r1
mov64 r1, 0x2
stxdw [r10-0x28], r1
stxdw [r10-0x48], r1
lddw r1, 0x17e38
stxdw [r10-0x50], r1
mov64 r1, r10
add64 r1, -0x58
stxdw [r10-0x10], r1
lddw r1, 0x146e8
stxdw [r10-0x8], r1
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0x60
stxdw [r10-0x20], r1
mov64 r1, r10
add64 r1, -0x50
mov64 r2, r3
call fn_109f8
fn_13018:
call fn_13018
fn_13020:
stxdw [r10-0xc8], r4
stxdw [r10-0xd0], r3
lddw r6, 0x16f20
mov64 r7, 0x0
mov64 r0, 0x101
mov64 r9, r2
jgt r0, r2, +0x9
mov64 r0, 0x100
mov64 r8, -0x40
mov64 r9, 0x0
mov64 r7, 0x5
ja +0xc
lddw r6, 0x17124
add64 r0, -0x1
jne r0, 0x0, +0x8
stxdw [r10-0xb8], r9
stxdw [r10-0xc0], r1
stxdw [r10-0xa8], r7
stxdw [r10-0xb0], r6
jgt r3, r2, +0x16
jgt r4, r2, +0x15
jgt r3, r4, +0x32
ja +0x50
mov64 r6, r1
add64 r6, r0
ldxb r6, [r6+0x0]
lsh64 r6, 0x38
arsh64 r6, 0x38
jsgt r8, r6, -0x12
lddw r6, 0x17124
mov64 r7, 0x5
mov64 r9, r0
jgt r2, r0, -0x13
mov64 r9, r2
jeq r2, r0, -0x15
mov64 r3, 0x0
mov64 r4, r0
lddw r5, 0x17e58
call fn_13020
fn_13178:
call fn_13178
jgt r3, r2, +0x1
mov64 r3, r4
stxdw [r10-0x90], r3
mov64 r1, r10
add64 r1, -0x50
stxdw [r10-0x60], r1
mov64 r1, 0x0
stxdw [r10-0x70], r1
mov64 r1, 0x3
stxdw [r10-0x58], r1
stxdw [r10-0x78], r1
lddw r1, 0x17e70
stxdw [r10-0x80], r1
mov64 r1, r10
add64 r1, -0xb0
stxdw [r10-0x30], r1
lddw r1, 0x14a68
stxdw [r10-0x28], r1
stxdw [r10-0x38], r1
mov64 r1, r10
add64 r1, -0xc0
stxdw [r10-0x40], r1
lddw r1, 0x146e8
stxdw [r10-0x48], r1
mov64 r1, r10
add64 r1, -0x90
ja +0x8e
mov64 r1, r10
add64 r1, -0x50
stxdw [r10-0x60], r1
mov64 r1, 0x0
stxdw [r10-0x70], r1
mov64 r1, 0x4
stxdw [r10-0x58], r1
stxdw [r10-0x78], r1
lddw r1, 0x17ea0
stxdw [r10-0x80], r1
mov64 r1, r10
add64 r1, -0xb0
stxdw [r10-0x20], r1
lddw r1, 0x14a68
stxdw [r10-0x18], r1
stxdw [r10-0x28], r1
mov64 r1, r10
add64 r1, -0xc0
stxdw [r10-0x30], r1
mov64 r1, r10
add64 r1, -0xc8
stxdw [r10-0x40], r1
lddw r1, 0x146e8
stxdw [r10-0x38], r1
stxdw [r10-0x48], r1
mov64 r1, r10
add64 r1, -0xd0
ja +0x6f
jeq r3, 0x0, +0xa
jgt r2, r3, +0x2
jeq r2, r3, +0x8
ja +0x8
mov64 r0, r1
add64 r0, r3
ldxb r0, [r0+0x0]
lsh64 r0, 0x38
arsh64 r0, 0x38
mov64 r6, -0x40
jsgt r6, r0, +0x1
mov64 r3, r4
stxdw [r10-0xa0], r3
jeq r3, 0x0, +0xc
jgt r2, r3, +0x2
jeq r2, r3, +0x2e
ja +0x6
mov64 r4, r1
add64 r4, r3
ldxb r4, [r4+0x0]
lsh64 r4, 0x38
arsh64 r4, 0x38
jsgt r4, -0x41, +0x4
add64 r3, -0x1
jeq r3, 0x0, +0x1
ja -0xc
mov64 r3, 0x0
jeq r3, r2, +0x22
add64 r1, r3
ldxb r0, [r1+0x0]
mov64 r2, r0
lsh64 r2, 0x38
arsh64 r2, 0x38
jsgt r2, -0x1, +0x22
ldxb r2, [r1+0x1]
and64 r2, 0x3f
mov64 r4, r0
and64 r4, 0x1f
mov64 r6, r4
lsh64 r6, 0x6
or64 r6, r2
jgt r0, 0xdf, +0x1
ja +0x4a
lsh64 r2, 0x6
ldxb r6, [r1+0x2]
and64 r6, 0x3f
or64 r2, r6
mov64 r7, r4
lsh64 r7, 0xc
mov64 r6, r2
or64 r6, r7
mov64 r7, 0xf0
jgt r7, r0, +0x40
lsh64 r2, 0x6
ldxb r1, [r1+0x3]
and64 r1, 0x3f
or64 r2, r1
lsh64 r4, 0x12
and64 r4, 0x1c0000
or64 r2, r4
mov64 r6, r2
jne r2, 0x110000, +0x37
lddw r1, 0x16f31
mov64 r2, 0x2b
mov64 r3, r5
call fn_10888
fn_13580:
call fn_13580
stxw [r10-0x94], r0
mov64 r1, 0x1
stxdw [r10-0x90], r3
add64 r1, r3
stxdw [r10-0x88], r1
mov64 r1, r10
add64 r1, -0x50
stxdw [r10-0x60], r1
mov64 r1, 0x0
stxdw [r10-0x70], r1
mov64 r1, 0x5
stxdw [r10-0x58], r1
stxdw [r10-0x78], r1
lddw r1, 0x17ee0
stxdw [r10-0x80], r1
mov64 r1, r10
add64 r1, -0xb0
stxdw [r10-0x10], r1
lddw r1, 0x14a68
stxdw [r10-0x8], r1
stxdw [r10-0x18], r1
mov64 r1, r10
add64 r1, -0xc0
stxdw [r10-0x20], r1
lddw r1, 0xfdf0
stxdw [r10-0x28], r1
mov64 r1, r10
add64 r1, -0x90
stxdw [r10-0x30], r1
lddw r1, 0x12910
stxdw [r10-0x38], r1
mov64 r1, r10
add64 r1, -0x94
stxdw [r10-0x40], r1
lddw r1, 0x146e8
stxdw [r10-0x48], r1
mov64 r1, r10
add64 r1, -0xa0
stxdw [r10-0x50], r1
mov64 r1, r10
add64 r1, -0x80
mov64 r2, r5
call fn_109f8
fn_13708:
call fn_13708
mov64 r1, 0x1
stxw [r10-0x94], r6
mov64 r2, 0x80
jgt r2, r6, -0x33
mov64 r1, 0x2
mov64 r2, 0x800
jgt r2, r6, -0x36
mov64 r1, 0x3
mov64 r2, 0x10000
jgt r2, r6, -0x39
mov64 r1, 0x4
ja -0x3b
fn_13770:
mov64 r9, r1
ldxdw r1, [r5-0xff0]
stxdw [r10-0x10], r1
ldxdw r6, [r5-0xff8]
jeq r3, 0x0, +0x2a
lsh64 r3, 0x1
mov64 r1, r2
add64 r1, r3
stxdw [r10-0x8], r1
ldxdw r8, [r5-0x1000]
mov64 r3, r9
and64 r3, 0xff00
rsh64 r3, 0x8
mov64 r0, 0x0
stxdw [r10-0x20], r4
stxdw [r10-0x18], r8
ja +0x4
jgt r1, r3, +0x1d
mov64 r0, r5
ldxdw r1, [r10-0x8]
jeq r2, r1, +0x1a
ldxb r7, [r2+0x1]
mov64 r5, r0
add64 r5, r7
ldxb r1, [r2+0x0]
add64 r2, 0x2
jeq r1, r3, +0x1
ja -0xb
jgt r0, r5, +0x39
jgt r5, r8, +0x3e
add64 r4, r0
jeq r7, 0x0, +0x9
mov64 r0, 0x0
add64 r7, -0x1
mov64 r1, r9
and64 r1, 0xff
ldxb r8, [r4+0x0]
add64 r4, 0x1
jne r8, r1, -0x8
and64 r0, 0x1
exit
mov64 r0, r5
ldxdw r4, [r10-0x20]
ldxdw r8, [r10-0x18]
ldxdw r1, [r10-0x8]
jeq r2, r1, +0x1
ja -0x1a
mov64 r0, 0x1
ldxdw r1, [r10-0x10]
jeq r1, 0x0, -0xb
mov64 r2, r6
ldxdw r1, [r10-0x10]
add64 r2, r1
mov64 r0, 0x1
and64 r9, 0xffff
mov64 r3, 0x0
ja +0x7
mov64 r6, r5
sub64 r9, r4
lsh64 r9, 0x20
arsh64 r9, 0x20
jsgt r3, r9, -0x17
xor64 r0, 0x1
jeq r6, r2, -0x19
mov64 r5, r6
add64 r5, 0x1
ldxb r4, [r6+0x0]
mov64 r1, r4
lsh64 r1, 0x38
arsh64 r1, 0x38
jsgt r3, r1, +0x1
ja -0xf
jne r5, r2, +0x7
lddw r1, 0x16f31
mov64 r2, 0x2b
lddw r3, 0x17f48
call fn_10888
fn_139e8:
call fn_139e8
and64 r4, 0x7f
lsh64 r4, 0x8
ldxb r1, [r6+0x1]
or64 r4, r1
add64 r6, 0x2
ja -0x1c
mov64 r1, r0
mov64 r2, r5
lddw r3, 0x17f30
call fn_12f40
fn_13a48:
call fn_13a48
mov64 r1, r5
ldxdw r2, [r10-0x18]
lddw r3, 0x17f30
call fn_12e60
fn_13a78:
call fn_13a78
fn_13a80:
mov64 r3, 0x0
ldxb r4, [r1+0x0]
mov64 r1, 0xa
ja +0x14
add64 r5, r0
mov64 r0, r10
add64 r0, -0x80
add64 r0, r3
stxb [r0+0x7f], r5
add64 r3, -0x1
mov64 r5, r4
and64 r5, 0xff
mov64 r4, r5
rsh64 r4, 0x4
jgt r5, 0xf, +0x9
mov64 r1, r3
add64 r1, 0x80
mov64 r4, 0x81
jgt r4, r1, +0xb
mov64 r2, 0x80
lddw r3, 0x17db0
call fn_12d80
fn_13b38:
call fn_13b38
mov64 r0, r4
and64 r0, 0xf
mov64 r5, 0x30
jgt r1, r0, -0x18
mov64 r5, 0x57
ja -0x1a
mov64 r1, r3
neg64 r1
stxdw [r10-0xff8], r1
mov64 r1, r10
add64 r1, -0x80
add64 r1, r3
add64 r1, 0x80
stxdw [r10-0x1000], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16fbd
mov64 r4, 0x2
call fn_10fd0
exit
fn_13bf0:
mov64 r3, 0x0
ldxb r4, [r1+0x0]
mov64 r1, 0xa
ja +0x14
add64 r5, r0
mov64 r0, r10
add64 r0, -0x80
add64 r0, r3
stxb [r0+0x7f], r5
add64 r3, -0x1
mov64 r5, r4
and64 r5, 0xff
mov64 r4, r5
rsh64 r4, 0x4
jgt r5, 0xf, +0x9
mov64 r1, r3
add64 r1, 0x80
mov64 r4, 0x81
jgt r4, r1, +0xb
mov64 r2, 0x80
lddw r3, 0x17db0
call fn_12d80
fn_13ca8:
call fn_13ca8
mov64 r0, r4
and64 r0, 0xf
mov64 r5, 0x30
jgt r1, r0, -0x18
mov64 r5, 0x37
ja -0x1a
mov64 r1, r3
neg64 r1
stxdw [r10-0xff8], r1
mov64 r1, r10
add64 r1, -0x80
add64 r1, r3
add64 r1, 0x80
stxdw [r10-0x1000], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16fbd
mov64 r4, 0x2
call fn_10fd0
exit
fn_13d60:
ldxw r3, [r2+0x30]
mov64 r4, r3
and64 r4, 0x10
jne r4, 0x0, +0x32
and64 r3, 0x20
jeq r3, 0x0, +0x1
ja +0x33
mov64 r3, 0x27
ldxdw r1, [r1+0x0]
mov64 r4, 0x2710
jgt r4, r1, +0x20
mov64 r3, 0x0
mov64 r4, r1
div64 r1, 0x2710
mov64 r5, r1
mul64 r5, 0x2710
mov64 r0, r4
sub64 r0, r5
mov64 r5, r0
and64 r5, 0xffff
div64 r5, 0x64
mov64 r6, r5
mul64 r6, 0x64
sub64 r0, r6
mov64 r6, r10
add64 r6, -0x80
add64 r6, r3
lsh64 r5, 0x1
lddw r7, 0x16fbf
add64 r7, r5
ldxh r5, [r7+0x0]
stxh [r6+0x23], r5
and64 r0, 0xffff
lsh64 r0, 0x1
lddw r5, 0x16fbf
add64 r5, r0
ldxh r5, [r5+0x0]
stxh [r6+0x25], r5
add64 r3, -0x4
jgt r4, 0x5f5e0ff, -0x1e
add64 r3, 0x27
jsgt r1, 0x63, +0x4f
mov64 r4, 0xa
jsgt r4, r1, +0x1
ja +0x5f
add64 r3, -0x1
mov64 r4, r10
add64 r4, -0x80
add64 r4, r3
add64 r1, 0x30
stxb [r4+0x0], r1
ja +0x62
mov64 r3, 0x0
ldxdw r5, [r1+0x0]
mov64 r1, 0xa
ja +0x2b
mov64 r3, 0x0
ldxdw r5, [r1+0x0]
mov64 r1, 0xa
ja +0xe
add64 r5, r0
mov64 r0, r10
add64 r0, -0x80
add64 r0, r3
stxb [r0+0x7f], r5
add64 r3, -0x1
mov64 r5, r4
rsh64 r5, 0x4
jgt r4, 0xf, +0x5
mov64 r1, r3
add64 r1, 0x80
mov64 r4, 0x81
jgt r4, r1, +0x21
ja +0x14
mov64 r4, r5
mov64 r0, r4
and64 r0, 0xf
mov64 r5, 0x30
jgt r1, r0, -0x13
mov64 r5, 0x37
ja -0x15
add64 r5, r0
mov64 r0, r10
add64 r0, -0x80
add64 r0, r3
stxb [r0+0x7f], r5
add64 r3, -0x1
mov64 r5, r4
rsh64 r5, 0x4
jgt r4, 0xf, +0x9
mov64 r1, r3
add64 r1, 0x80
mov64 r4, 0x81
jgt r4, r1, +0xc
mov64 r2, 0x80
lddw r3, 0x17db0
call fn_12d80
fn_14080:
call fn_14080
mov64 r4, r5
mov64 r0, r4
and64 r0, 0xf
mov64 r5, 0x30
jgt r1, r0, -0x17
mov64 r5, 0x57
ja -0x19
mov64 r1, r3
neg64 r1
stxdw [r10-0xff8], r1
mov64 r1, r10
add64 r1, -0x80
add64 r1, r3
add64 r1, 0x80
stxdw [r10-0x1000], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16fbd
mov64 r4, 0x2
ja +0x2a
mov64 r4, r1
and64 r4, 0xffff
div64 r4, 0x64
mov64 r5, r4
mul64 r5, 0x64
sub64 r1, r5
and64 r1, 0xffff
lsh64 r1, 0x1
lddw r5, 0x16fbf
add64 r5, r1
add64 r3, -0x2
mov64 r1, r10
add64 r1, -0x80
add64 r1, r3
ldxh r5, [r5+0x0]
stxh [r1+0x0], r5
mov64 r1, r4
ja -0x62
lsh64 r1, 0x1
lddw r4, 0x16fbf
add64 r4, r1
add64 r3, -0x2
mov64 r1, r10
add64 r1, -0x80
add64 r1, r3
ldxh r4, [r4+0x0]
stxh [r1+0x0], r4
mov64 r1, r10
add64 r1, -0x80
add64 r1, r3
stxdw [r10-0x1000], r1
mov64 r1, 0x27
sub64 r1, r3
stxdw [r10-0xff8], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16f20
mov64 r4, 0x0
call fn_10fd0
exit
fn_14298:
ldxb r1, [r1+0x0]
jgt r1, 0x63, +0xb
mov64 r3, 0x26
mov64 r4, 0xa
jgt r4, r1, +0x16
lsh64 r1, 0x1
lddw r3, 0x16fbf
add64 r3, r1
ldxh r1, [r3+0x0]
stxh [r10-0x2], r1
mov64 r3, 0x25
ja +0x13
mov64 r4, r1
div64 r4, 0x64
mov64 r3, r4
mul64 r3, 0x64
sub64 r1, r3
and64 r1, 0xff
lsh64 r1, 0x1
lddw r3, 0x16fbf
add64 r3, r1
ldxh r1, [r3+0x0]
stxh [r10-0x2], r1
mov64 r3, 0x24
mov64 r1, r4
mov64 r4, r10
add64 r4, -0x27
add64 r4, r3
add64 r1, 0x30
stxb [r4+0x0], r1
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
stxdw [r10-0x1000], r1
mov64 r1, 0x27
sub64 r1, r3
stxdw [r10-0xff8], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16f20
mov64 r4, 0x0
call fn_10fd0
exit
mov64 r3, 0x27
ldxw r1, [r1+0x0]
mov64 r4, 0x2710
jgt r4, r1, +0x20
mov64 r3, 0x0
mov64 r4, r1
div64 r1, 0x2710
mov64 r5, r1
mul64 r5, 0x2710
mov64 r0, r4
sub64 r0, r5
mov64 r5, r0
and64 r5, 0xffff
div64 r5, 0x64
mov64 r6, r5
mul64 r6, 0x64
sub64 r0, r6
mov64 r6, r10
add64 r6, -0x27
add64 r6, r3
lsh64 r5, 0x1
lddw r7, 0x16fbf
add64 r7, r5
ldxh r5, [r7+0x0]
stxh [r6+0x23], r5
and64 r0, 0xffff
lsh64 r0, 0x1
lddw r5, 0x16fbf
add64 r5, r0
ldxh r5, [r5+0x0]
stxh [r6+0x25], r5
add64 r3, -0x4
jgt r4, 0x5f5e0ff, -0x1e
add64 r3, 0x27
jgt r1, 0x63, +0xa
mov64 r4, 0xa
jsgt r4, r1, +0x1
ja +0x1a
add64 r3, -0x1
mov64 r4, r10
add64 r4, -0x27
add64 r4, r3
add64 r1, 0x30
stxb [r4+0x0], r1
ja +0x1d
mov64 r4, r1
and64 r4, 0xffff
div64 r4, 0x64
mov64 r5, r4
mul64 r5, 0x64
sub64 r1, r5
and64 r1, 0xffff
lsh64 r1, 0x1
lddw r5, 0x16fbf
add64 r5, r1
add64 r3, -0x2
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
ldxh r5, [r5+0x0]
stxh [r1+0x0], r5
mov64 r1, r4
ja -0x1d
lsh64 r1, 0x1
lddw r4, 0x16fbf
add64 r4, r1
add64 r3, -0x2
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
ldxh r4, [r4+0x0]
stxh [r1+0x0], r4
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
stxdw [r10-0x1000], r1
mov64 r1, 0x27
sub64 r1, r3
stxdw [r10-0xff8], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16f20
mov64 r4, 0x0
call fn_10fd0
exit
mov64 r3, 0x27
ldxdw r1, [r1+0x0]
mov64 r4, 0x2710
jgt r4, r1, +0x20
mov64 r3, 0x0
mov64 r4, r1
div64 r1, 0x2710
mov64 r5, r1
mul64 r5, 0x2710
mov64 r0, r4
sub64 r0, r5
mov64 r5, r0
and64 r5, 0xffff
div64 r5, 0x64
mov64 r6, r5
mul64 r6, 0x64
sub64 r0, r6
mov64 r6, r10
add64 r6, -0x27
add64 r6, r3
lsh64 r5, 0x1
lddw r7, 0x16fbf
add64 r7, r5
ldxh r5, [r7+0x0]
stxh [r6+0x23], r5
and64 r0, 0xffff
lsh64 r0, 0x1
lddw r5, 0x16fbf
add64 r5, r0
ldxh r5, [r5+0x0]
stxh [r6+0x25], r5
add64 r3, -0x4
jgt r4, 0x5f5e0ff, -0x1e
add64 r3, 0x27
jsgt r1, 0x63, +0xa
mov64 r4, 0xa
jsgt r4, r1, +0x1
ja +0x1a
add64 r3, -0x1
mov64 r4, r10
add64 r4, -0x27
add64 r4, r3
add64 r1, 0x30
stxb [r4+0x0], r1
ja +0x1d
mov64 r4, r1
and64 r4, 0xffff
div64 r4, 0x64
mov64 r5, r4
mul64 r5, 0x64
sub64 r1, r5
and64 r1, 0xffff
lsh64 r1, 0x1
lddw r5, 0x16fbf
add64 r5, r1
add64 r3, -0x2
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
ldxh r5, [r5+0x0]
stxh [r1+0x0], r5
mov64 r1, r4
ja -0x1d
lsh64 r1, 0x1
lddw r4, 0x16fbf
add64 r4, r1
add64 r3, -0x2
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
ldxh r4, [r4+0x0]
stxh [r1+0x0], r4
mov64 r1, r10
add64 r1, -0x27
add64 r1, r3
stxdw [r10-0x1000], r1
mov64 r1, 0x27
sub64 r1, r3
stxdw [r10-0xff8], r1
mov64 r5, r10
mov64 r1, r2
mov64 r2, 0x1
lddw r3, 0x16f20
mov64 r4, 0x0
call fn_10fd0
exit
ldxdw r1, [r2+0x20]
ldxdw r2, [r2+0x28]
ldxdw r4, [r2+0x18]
lddw r2, 0x1773a
mov64 r3, 0x5
callx r4
exit
ldxdw r3, [r1+0x0]
ldxdw r1, [r1+0x8]
ldxdw r4, [r1+0x18]
mov64 r1, r3
callx r4
exit
mov64 r4, r2
ldxdw r1, [r1+0x0]
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
mov64 r1, r4
call fn_117b8
exit
mov64 r4, r2
ldxdw r3, [r1+0x8]
ldxdw r2, [r1+0x0]
mov64 r1, r4
call fn_117b8
exit
ldxdw r6, [r2+0x28]
ldxdw r7, [r2+0x20]
ldxdw r2, [r1+0x0]
mov64 r8, r10
add64 r8, -0x30
mov64 r1, r8
mov64 r3, 0x30
call fn_15878
mov64 r1, r7
mov64 r2, r6
mov64 r3, r8
call fn_10b58
exit
fn_14b00:
mov64 r2, 0x0
mov64 r3, 0x20
mov64 r4, r1
lsh64 r4, 0xb
mov64 r5, 0x20
ja +0x6
add64 r3, 0x1
mov64 r2, r3
mov64 r3, r5
sub64 r3, r2
jgt r5, r2, +0x1
ja +0x14
rsh64 r3, 0x1
add64 r3, r2
mov64 r0, r3
lsh64 r0, 0x2
lddw r6, 0x17740
add64 r6, r0
ldxw r0, [r6+0x0]
lsh64 r0, 0xb
lsh64 r0, 0x20
mov64 r6, r4
lsh64 r6, 0x20
rsh64 r0, 0x20
rsh64 r6, 0x20
jgt r6, r0, -0x15
mov64 r5, r3
jeq r0, r6, +0x1
ja -0x15
add64 r3, 0x1
mov64 r2, r3
jgt r2, 0x1f, +0x45
mov64 r5, r2
lsh64 r5, 0x2
lddw r0, 0x17740
mov64 r4, 0x2c3
jeq r2, 0x1f, +0x4
mov64 r3, r5
add64 r3, r0
ldxw r4, [r3+0x4]
rsh64 r4, 0x15
mov64 r3, r2
add64 r3, -0x1
mov64 r6, 0x0
mov64 r7, 0x1
jgt r3, r2, +0x1
mov64 r7, 0x0
and64 r7, 0x1
jne r7, 0x0, +0xe
mov64 r2, 0x20
jgt r2, r3, +0x6
mov64 r1, r3
mov64 r2, 0x20
lddw r3, 0x17f90
call fn_10918
fn_14cd0:
call fn_14cd0
lsh64 r3, 0x2
lddw r2, 0x17740
add64 r2, r3
ldxw r6, [r2+0x0]
and64 r6, 0x1fffff
add64 r0, r5
ldxw r0, [r0+0x0]
rsh64 r0, 0x15
mov64 r2, r0
xor64 r2, -0x1
add64 r4, r2
jeq r4, 0x0, +0x16
sub64 r1, r6
lddw r3, 0x177c0
add64 r3, r0
mov64 r5, 0x0
lsh64 r1, 0x20
rsh64 r1, 0x20
mov64 r6, 0x0
mov64 r2, r0
add64 r2, r6
jgt r2, 0x2c2, +0xd
mov64 r2, r3
add64 r2, r6
ldxb r2, [r2+0x0]
add64 r5, r2
mov64 r2, r5
lsh64 r2, 0x20
rsh64 r2, 0x20
jgt r2, r1, +0x2
add64 r6, 0x1
jgt r4, r6, -0xd
add64 r0, r6
and64 r0, 0x1
exit
mov64 r1, r2
mov64 r2, 0x2c3
lddw r3, 0x17f78
call fn_10918
fn_14e28:
call fn_14e28
mov64 r1, r2
mov64 r2, 0x20
lddw r3, 0x17f60
call fn_10918
fn_14e58:
call fn_14e58
fn_14e60:
call fn_15d28
exit
fn_14e70:
mov64 r0, 0x0
mov64 r2, r1
rsh64 r2, 0x34
and64 r2, 0x7ff
mov64 r3, 0x3ff
jgt r3, r2, +0x14
mov64 r3, 0x0
jsgt r3, r1, +0x12
mov64 r0, -0x1
jgt r2, 0x43e, +0x10
lddw r3, 0xfffffffffffff
and64 r1, r3
lddw r3, 0x10000000000000
or64 r1, r3
mov64 r3, 0x433
jgt r3, r2, +0x4
add64 r2, -0x433
and64 r2, 0xffff
lsh64 r1, r2
ja +0x3
sub64 r3, r2
and64 r3, 0xffff
rsh64 r1, r3
mov64 r0, r1
exit
fn_14f48:
call fn_14f58
exit
fn_14f58:
mov64 r6, r2
mov64 r3, r6
xor64 r3, r1
lddw r2, -0x8000000000000000
and64 r3, r2
stxdw [r10-0x18], r3
lddw r5, 0xfffffffffffff
mov64 r2, r6
and64 r2, r5
mov64 r4, r1
and64 r4, r5
mov64 r7, r6
rsh64 r7, 0x34
and64 r7, 0x7ff
mov64 r8, r1
rsh64 r8, 0x34
and64 r8, 0x7ff
mov64 r5, r8
add64 r5, -0x1
jgt r5, 0x7fd, +0x25
mov64 r9, 0x0
mov64 r5, r7
add64 r5, -0x1
jgt r5, 0x7fd, +0x21
lsh64 r2, 0xb
lddw r1, -0x8000000000000000
or64 r2, r1
lddw r6, 0x10000000000000
or64 r4, r6
mov64 r1, r10
add64 r1, -0x10
mov64 r3, 0x0
mov64 r5, 0x0
call fn_16790
add64 r7, r8
add64 r7, r9
ldxdw r2, [r10-0x8]
mov64 r3, r2
and64 r3, r6
ldxdw r1, [r10-0x10]
jeq r3, 0x0, +0x1
ja +0x1d
lsh64 r2, 0x1
mov64 r3, r1
rsh64 r3, 0x3f
or64 r2, r3
lsh64 r1, 0x1
add64 r7, -0x3ff
ldxdw r0, [r10-0x18]
jsgt r7, 0x7fe, +0x1
ja +0x17
lddw r1, 0x7ff0000000000000
or64 r0, r1
ja +0x48
lddw r9, 0x7fffffffffffffff
mov64 r5, r1
and64 r5, r9
lddw r0, 0x7ff0000000000000
jgt r5, r0, +0x14
mov64 r3, r6
and64 r3, r9
jgt r3, r0, +0x1
ja +0x15
lddw r1, 0x8000000000000
or64 r6, r1
mov64 r0, r6
ja +0x38
add64 r7, -0x3fe
ldxdw r0, [r10-0x18]
jsgt r7, 0x7fe, -0x17
mov64 r3, 0x1
jsgt r3, r7, +0x18
lddw r3, 0xfffffffffffff
and64 r2, r3
lsh64 r7, 0x34
or64 r7, r2
ja +0x20
lddw r2, 0x8000000000000
or64 r1, r2
mov64 r0, r1
ja +0x28
lddw r0, 0x7ff0000000000000
jeq r5, r0, +0x1
ja +0x25
lddw r0, 0x7ff8000000000000
jeq r3, 0x0, +0x21
lddw r2, -0x8000000000000000
and64 r6, r2
xor64 r6, r1
mov64 r0, r6
ja +0x1b
sub64 r3, r7
lsh64 r3, 0x20
rsh64 r3, 0x20
jgt r3, 0x3f, +0x17
add64 r7, -0x1
and64 r7, 0x3f
mov64 r4, r1
or64 r4, r2
lsh64 r4, r7
rsh64 r1, r3
or64 r4, r1
rsh64 r2, r3
mov64 r1, r4
mov64 r7, r2
mov64 r2, r7
or64 r2, r0
lddw r3, -0x8000000000000000
jgt r1, r3, +0x6
mov64 r0, r2
jeq r1, r3, +0x1
ja +0x5
and64 r7, 0x1
add64 r2, r7
ja +0x1
add64 r2, 0x1
mov64 r0, r2
exit
jeq r3, r0, +0x1
ja +0x9
lddw r0, 0x7ff8000000000000
jeq r5, 0x0, -0x6
lddw r2, -0x8000000000000000
and64 r1, r2
xor64 r1, r6
mov64 r0, r1
ja -0xc
ldxdw r0, [r10-0x18]
jeq r5, 0x0, -0xe
jeq r3, 0x0, -0xf
mov64 r6, r3
mov64 r9, 0x0
lddw r1, 0x10000000000000
jgt r1, r5, +0x2
jgt r1, r6, +0x35
ja -0x7f
mov64 r0, 0x40
jeq r4, 0x0, +0x2b
mov64 r5, r4
rsh64 r5, 0x1
mov64 r3, r4
or64 r3, r5
mov64 r5, r3
rsh64 r5, 0x2
or64 r3, r5
mov64 r5, r3
rsh64 r5, 0x4
or64 r3, r5
mov64 r5, r3
rsh64 r5, 0x8
or64 r3, r5
mov64 r5, r3
rsh64 r5, 0x10
or64 r3, r5
mov64 r5, r3
rsh64 r5, 0x20
or64 r3, r5
xor64 r3, -0x1
lddw r5, 0x5555555555555555
mov64 r0, r3
rsh64 r0, 0x1
and64 r0, r5
sub64 r3, r0
lddw r5, 0x3333333333333333
mov64 r0, r3
and64 r0, r5
rsh64 r3, 0x2
and64 r3, r5
add64 r0, r3
mov64 r3, r0
rsh64 r3, 0x4
add64 r0, r3
lddw r3, 0xf0f0f0f0f0f0f0f
and64 r0, r3
lddw r3, 0x101010101010101
mul64 r0, r3
rsh64 r0, 0x38
mov64 r9, 0xc
sub64 r9, r0
add64 r0, 0x35
and64 r0, 0x3f
lsh64 r4, r0
jgt r1, r6, +0x1
ja -0xb3
mov64 r3, 0x40
jeq r2, 0x0, +0x2b
mov64 r3, r2
rsh64 r3, 0x1
mov64 r1, r2
or64 r1, r3
mov64 r3, r1
rsh64 r3, 0x2
or64 r1, r3
mov64 r3, r1
rsh64 r3, 0x4
or64 r1, r3
mov64 r3, r1
rsh64 r3, 0x8
or64 r1, r3
mov64 r3, r1
rsh64 r3, 0x10
or64 r1, r3
mov64 r3, r1
rsh64 r3, 0x20
or64 r1, r3
xor64 r1, -0x1
lddw r3, 0x5555555555555555
mov64 r5, r1
rsh64 r5, 0x1
and64 r5, r3
sub64 r1, r5
lddw r5, 0x3333333333333333
mov64 r3, r1
and64 r3, r5
rsh64 r1, 0x2
and64 r1, r5
add64 r3, r1
mov64 r1, r3
rsh64 r1, 0x4
add64 r3, r1
lddw r1, 0xf0f0f0f0f0f0f0f
and64 r3, r1
lddw r1, 0x101010101010101
mul64 r3, r1
rsh64 r3, 0x38
sub64 r9, r3
add64 r3, 0x35
and64 r3, 0x3f
lsh64 r2, r3
add64 r9, 0xc
ja -0xe6
fn_15758:
lddw r0, 0xffffffff
lddw r5, 0x7fffffffffffffff
mov64 r3, r1
and64 r3, r5
lddw r6, 0x7ff0000000000000
jgt r3, r6, +0x18
mov64 r4, r2
and64 r4, r5
lddw r0, 0xffffffff
jgt r4, r6, +0x13
or64 r4, r3
mov64 r0, 0x0
jeq r4, 0x0, +0x10
mov64 r3, r2
and64 r3, r1
jsgt r3, -0x1, +0x6
lddw r0, 0xffffffff
jsgt r1, r2, +0xa
mov64 r0, 0x1
jeq r1, r2, +0x7
ja +0x7
lddw r0, 0xffffffff
jsgt r2, r1, +0x4
mov64 r0, 0x1
jeq r1, r2, +0x1
ja +0x1
mov64 r0, 0x0
lsh64 r0, 0x20
arsh64 r0, 0x20
exit
fn_15878:
mov64 r6, r1
mov64 r4, r3
rsh64 r4, 0x3
mov64 r1, r4
mul64 r1, -0x7
add64 r1, r3
jgt r1, 0xf, +0x18
mov64 r1, 0x0
mov64 r5, 0x8
jgt r5, r3, +0xb
mov64 r1, 0x0
mov64 r5, 0x0
mov64 r0, r6
add64 r0, r1
mov64 r7, r2
add64 r7, r1
ldxdw r7, [r7+0x0]
stxdw [r0+0x0], r7
add64 r1, 0x8
add64 r5, 0x1
jgt r4, r5, -0x9
jsge r1, r3, +0xb
mov64 r4, r6
add64 r4, r1
mov64 r5, r2
add64 r5, r1
ldxb r5, [r5+0x0]
stxb [r4+0x0], r5
add64 r1, 0x1
jsgt r3, r1, -0x8
ja +0x2
mov64 r1, r6
fn_15978:
call fn_15978
mov64 r0, r6
exit
fn_15990:
mov64 r6, r1
mov64 r4, r3
rsh64 r4, 0x3
mov64 r1, r4
mul64 r1, -0x7
add64 r1, r3
jgt r1, 0xf, +0x17
mov64 r1, 0x0
mov64 r5, 0x8
jgt r5, r3, +0xd
mov64 r5, r2
and64 r5, 0xff
lddw r1, 0x101010101010101
mul64 r5, r1
mov64 r1, 0x0
mov64 r0, 0x0
mov64 r7, r6
add64 r7, r1
stxdw [r7+0x0], r5
add64 r1, 0x8
add64 r0, 0x1
jgt r4, r0, -0x6
jsge r1, r3, +0x9
mov64 r4, r6
add64 r4, r1
stxb [r4+0x0], r2
add64 r1, 0x1
jsgt r3, r1, -0x5
ja +0x3
and64 r2, 0xff
mov64 r1, r6
fn_15a90:
call fn_15a90
mov64 r0, r6
exit
fn_15aa8:
mov64 r5, r3
rsh64 r5, 0x3
mov64 r4, r5
mul64 r4, -0x7
add64 r4, r3
jgt r4, 0xf, +0x1d
mov64 r0, 0x0
mov64 r6, 0x8
mov64 r4, 0x0
jgt r6, r3, +0xb
mov64 r4, 0x0
mov64 r6, r1
mov64 r7, r2
ldxdw r8, [r7+0x0]
ldxdw r9, [r6+0x0]
jne r9, r8, +0x4
add64 r6, 0x8
add64 r7, 0x8
add64 r4, 0x1
jgt r5, r4, -0x7
lsh64 r4, 0x3
jsge r4, r3, +0x13
ja +0x2
add64 r4, 0x1
jsge r4, r3, +0x10
mov64 r6, r1
add64 r6, r4
mov64 r5, r2
add64 r5, r4
ldxb r5, [r5+0x0]
ldxb r6, [r6+0x0]
jeq r6, r5, -0x9
sub64 r6, r5
mov64 r0, r6
ja +0x6
mov64 r4, 0x0
stxw [r10-0x4], r4
mov64 r4, r10
add64 r4, -0x4
fn_15be0:
call fn_15be0
ldxw r0, [r10-0x4]
lsh64 r0, 0x20
arsh64 r0, 0x20
exit
fn_15c08:
lddw r0, 0xffffffff
lddw r5, 0x7fffffffffffffff
mov64 r3, r1
and64 r3, r5
lddw r6, 0x7ff0000000000000
jgt r3, r6, +0x18
mov64 r4, r2
and64 r4, r5
lddw r0, 0xffffffff
jgt r4, r6, +0x13
or64 r4, r3
mov64 r0, 0x0
jeq r4, 0x0, +0x10
mov64 r3, r2
and64 r3, r1
jsgt r3, -0x1, +0x6
lddw r0, 0xffffffff
jsgt r1, r2, +0xa
mov64 r0, 0x1
jeq r1, r2, +0x7
ja +0x7
lddw r0, 0xffffffff
jsgt r2, r1, +0x4
mov64 r0, 0x1
jeq r1, r2, +0x1
ja +0x1
mov64 r0, 0x0
lsh64 r0, 0x20
arsh64 r0, 0x20
exit
fn_15d28:
lddw r3, 0x7fffffffffffffff
mov64 r4, r2
and64 r4, r3
mov64 r5, r1
and64 r5, r3
mov64 r0, r5
add64 r0, -0x1
lddw r3, 0x7feffffffffffffe
jgt r0, r3, +0x94
mov64 r0, r4
add64 r0, -0x1
jgt r0, r3, +0x91
mov64 r3, r2
jgt r4, r5, +0x1
mov64 r3, r1
jgt r4, r5, +0x1
mov64 r1, r2
lddw r6, 0xfffffffffffff
mov64 r4, r3
and64 r4, r6
mov64 r0, r1
rsh64 r0, 0x34
and64 r0, 0x7ff
mov64 r2, r3
rsh64 r2, 0x34
and64 r2, 0x7ff
jeq r2, 0x0, +0x1
ja +0x32
mov64 r5, 0x40
jeq r4, 0x0, +0x2b
mov64 r5, r4
rsh64 r5, 0x1
mov64 r2, r4
or64 r2, r5
mov64 r5, r2
rsh64 r5, 0x2
or64 r2, r5
mov64 r5, r2
rsh64 r5, 0x4
or64 r2, r5
mov64 r5, r2
rsh64 r5, 0x8
or64 r2, r5
mov64 r5, r2
rsh64 r5, 0x10
or64 r2, r5
mov64 r5, r2
rsh64 r5, 0x20
or64 r2, r5
xor64 r2, -0x1
lddw r5, 0x5555555555555555
mov64 r7, r2
rsh64 r7, 0x1
and64 r7, r5
sub64 r2, r7
lddw r7, 0x3333333333333333
mov64 r5, r2
and64 r5, r7
rsh64 r2, 0x2
and64 r2, r7
add64 r5, r2
mov64 r2, r5
rsh64 r2, 0x4
add64 r5, r2
lddw r2, 0xf0f0f0f0f0f0f0f
and64 r5, r2
lddw r2, 0x101010101010101
mul64 r5, r2
rsh64 r5, 0x38
mov64 r2, 0xc
sub64 r2, r5
add64 r5, 0x35
and64 r5, 0x3f
lsh64 r4, r5
mov64 r5, r1
and64 r5, r6
jne r0, 0x0, +0x32
mov64 r6, 0x40
jeq r5, 0x0, +0x2b
mov64 r6, r5
rsh64 r6, 0x1
mov64 r0, r5
or64 r0, r6
mov64 r6, r0
rsh64 r6, 0x2
or64 r0, r6
mov64 r6, r0
rsh64 r6, 0x4
or64 r0, r6
mov64 r6, r0
rsh64 r6, 0x8
or64 r0, r6
mov64 r6, r0
rsh64 r6, 0x10
or64 r0, r6
mov64 r6, r0
rsh64 r6, 0x20
or64 r0, r6
xor64 r0, -0x1
lddw r6, 0x5555555555555555
mov64 r7, r0
rsh64 r7, 0x1
and64 r7, r6
sub64 r0, r7
lddw r7, 0x3333333333333333
mov64 r6, r0
and64 r6, r7
rsh64 r0, 0x2
and64 r0, r7
add64 r6, r0
mov64 r0, r6
rsh64 r0, 0x4
add64 r6, r0
lddw r0, 0xf0f0f0f0f0f0f0f
and64 r6, r0
lddw r0, 0x101010101010101
mul64 r6, r0
rsh64 r6, 0x38
mov64 r0, 0xc
sub64 r0, r6
add64 r6, 0x35
and64 r6, 0x3f
lsh64 r5, r6
xor64 r1, r3
lsh64 r5, 0x3
lddw r6, 0x80000000000000
or64 r5, r6
lsh64 r4, 0x3
mov64 r7, r2
sub64 r7, r0
mov64 r0, r5
jne r7, 0x0, +0x19
or64 r4, r6
jsgt r1, -0x1, +0x1
ja +0x2d
add64 r0, r4
lddw r1, 0x100000000000000
mov64 r4, r0
and64 r4, r1
jeq r4, 0x0, +0x5e
mov64 r1, r0
rsh64 r1, 0x1
and64 r0, 0x1
or64 r0, r1
add64 r2, 0x1
ja +0x58
lddw r3, 0x7ff0000000000000
jgt r5, r3, +0x1a
jgt r4, r3, +0x1
ja +0x7e
lddw r1, 0x8000000000000
or64 r4, r1
mov64 r5, r4
ja +0x87
mov64 r0, 0x1
mov64 r8, r7
lsh64 r8, 0x20
rsh64 r8, 0x20
jgt r8, 0x3f, -0x1e
mov64 r0, r7
neg64 r0
and64 r0, 0x3f
mov64 r8, r5
lsh64 r8, r0
mov64 r0, 0x1
jne r8, 0x0, +0x1
mov64 r0, 0x0
lsh64 r7, 0x20
rsh64 r7, 0x20
rsh64 r5, r7
or64 r5, r0
mov64 r0, r5
ja -0x2c
lddw r1, 0x8000000000000
or64 r5, r1
ja +0x70
sub64 r4, r0
mov64 r5, 0x0
jeq r4, 0x0, +0x6d
lddw r1, 0x7fffffffffffff
mov64 r0, r4
jgt r4, r1, +0x30
mov64 r5, r4
rsh64 r5, 0x1
mov64 r1, r4
or64 r1, r5
mov64 r5, r1
rsh64 r5, 0x2
or64 r1, r5
mov64 r5, r1
rsh64 r5, 0x4
or64 r1, r5
mov64 r5, r1
rsh64 r5, 0x8
or64 r1, r5
mov64 r5, r1
rsh64 r5, 0x10
or64 r1, r5
mov64 r5, r1
rsh64 r5, 0x20
or64 r1, r5
xor64 r1, -0x1
lddw r5, 0x5555555555555555
mov64 r0, r1
rsh64 r0, 0x1
and64 r0, r5
sub64 r1, r0
lddw r0, 0x3333333333333333
mov64 r5, r1
and64 r5, r0
rsh64 r1, 0x2
and64 r1, r0
add64 r5, r1
mov64 r1, r5
rsh64 r1, 0x4
add64 r5, r1
lddw r1, 0xf0f0f0f0f0f0f0f
and64 r5, r1
lddw r1, 0x101010101010101
mul64 r5, r1
rsh64 r5, 0x38
add64 r5, -0x8
sub64 r2, r5
and64 r5, 0x3f
lsh64 r4, r5
mov64 r0, r4
lddw r1, -0x8000000000000000
and64 r3, r1
jsgt r2, 0x7fe, +0x1
ja +0x5
lddw r1, 0x7ff0000000000000
or64 r3, r1
mov64 r5, r3
ja +0x2f
mov64 r1, 0x1
jsgt r1, r2, +0x1
ja +0xd
mov64 r4, r2
add64 r4, -0x1
and64 r4, 0x3f
mov64 r5, r0
lsh64 r5, r4
mov64 r4, 0x1
jne r5, 0x0, +0x1
mov64 r4, 0x0
sub64 r1, r2
and64 r1, 0x3f
rsh64 r0, r1
or64 r0, r4
mov64 r2, 0x0
mov64 r1, r0
rsh64 r1, 0x3
lddw r4, 0xfffffffffffff
mov64 r5, r1
and64 r5, r4
lsh64 r2, 0x34
or64 r2, r5
or64 r2, r3
and64 r0, 0x7
jgt r0, 0x4, +0x12
mov64 r5, r2
jeq r0, 0x4, +0x1
ja +0x11
and64 r1, 0x1
add64 r2, r1
ja +0xd
lddw r3, 0x7ff0000000000000
jeq r5, r3, +0x1
ja +0xc
xor64 r2, r1
lddw r5, 0x7ff8000000000000
lddw r3, -0x8000000000000000
mov64 r0, r1
jeq r2, r3, +0x3
ja +0x3
add64 r2, 0x1
mov64 r5, r2
mov64 r0, r5
exit
mov64 r0, r2
jeq r4, r3, -0x3
jeq r5, 0x0, +0x3
mov64 r0, r1
jeq r4, 0x0, -0x6
ja -0x12a
mov64 r0, r2
jne r4, 0x0, -0x9
and64 r2, r1
ja -0xd
fn_16708:
mov64 r6, r1
rsh64 r1, 0x20
lddw r2, 0x4530000000000000
or64 r1, r2
lddw r2, -0x3acffffffff00000
call fn_14e60
lsh64 r6, 0x20
rsh64 r6, 0x20
lddw r1, 0x4330000000000000
or64 r6, r1
mov64 r1, r0
mov64 r2, r6
call fn_14e60
exit
fn_16790:
mul64 r3, r4
mul64 r5, r2
add64 r5, r3
mov64 r0, r2
rsh64 r0, 0x20
mov64 r3, r4
rsh64 r3, 0x20
mov64 r6, r3
mul64 r6, r0
add64 r5, r6
lsh64 r4, 0x20
rsh64 r4, 0x20
mov64 r6, r4
mul64 r6, r0
lsh64 r2, 0x20
rsh64 r2, 0x20
mul64 r4, r2
mov64 r0, r4
rsh64 r0, 0x20
add64 r0, r6
mov64 r6, r0
rsh64 r6, 0x20
add64 r5, r6
mul64 r3, r2
lsh64 r0, 0x20
rsh64 r0, 0x20
add64 r0, r3
mov64 r2, r0
rsh64 r2, 0x20
add64 r5, r2
stxdw [r1+0x8], r5
lsh64 r0, 0x20
lsh64 r4, 0x20
rsh64 r4, 0x20
or64 r0, r4
stxdw [r1+0x0], r0
exit
