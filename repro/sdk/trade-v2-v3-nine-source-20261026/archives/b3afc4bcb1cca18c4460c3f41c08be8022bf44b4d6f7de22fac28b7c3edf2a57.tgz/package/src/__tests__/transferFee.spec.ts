import { expect } from "chai";
import BN from "bn.js";
import { Keypair, PublicKey } from "@solana/web3.js";
import { RawMint, TOKEN_2022_PROGRAM_ID } from "@solana/spl-token";
import { buyBaseInput, buyDebit, buyQuoteInput } from "../sdk/buy";
import { sellBaseInput, sellQuoteInput } from "../sdk/sell";
import { depositLpToken } from "../sdk/deposit";
import { withdraw } from "../sdk/withdraw";
import { multiHopSwapQuote, MultiHopPoolQuoteHop } from "../sdk/multiHop";
import {
  grossForTransferFee,
  netOfTransferFee,
  QuoteTransferFee,
  transferFeeOn,
} from "../sdk/transferFee";
import { PUMP_AMM_SDK } from "../sdk/offlinePumpAmm";
import { FeeConfig, GlobalConfig, LiquiditySolanaState } from "../types/sdk";
import { createSwapSolanaState, fees, ZERO_FEES } from "./utils";

const bn = (n: number | string) => new BN(n);
// 1% with a cap no amount here reaches, as a typical tax coin.
const ONE_PERCENT: QuoteTransferFee = {
  basisPoints: 100,
  maximumFee: bn("18446744073709551615"),
};
const CAPPED: QuoteTransferFee = { basisPoints: 100, maximumFee: bn(50) };

describe("Token-2022 transfer fee math (pump-mint-extensions TransferFee oracle)", () => {
  it("withholds ceil(amount * bps / 10_000), capped at maximum_fee", () => {
    expect(transferFeeOn(ONE_PERCENT, bn(10_000)).toNumber()).to.equal(100);
    expect(transferFeeOn(ONE_PERCENT, bn(10_001)).toNumber()).to.equal(101);
    expect(transferFeeOn(ONE_PERCENT, bn(1)).toNumber()).to.equal(1);
    expect(transferFeeOn(ONE_PERCENT, bn(0)).toNumber()).to.equal(0);
    expect(transferFeeOn(CAPPED, bn(1_000_000)).toNumber()).to.equal(50);
    expect(transferFeeOn(null, bn(1_000_000)).toNumber()).to.equal(0);
    expect(
      transferFeeOn({ basisPoints: 0, maximumFee: bn(50) }, bn(1_000_000)),
    ).to.satisfy((x: BN) => x.isZero());
  });

  it("grosses up so that at least the net lands, by at most one unit", () => {
    for (const fee of [ONE_PERCENT, CAPPED]) {
      for (const net of [1, 2, 99, 100, 101, 4_950, 4_951, 9_999, 123_457]) {
        const gross = grossForTransferFee(fee, bn(net));
        const landed = netOfTransferFee(fee, gross);
        expect(landed.gte(bn(net)), `${net}`).to.be.true;
        expect(netOfTransferFee(fee, gross.subn(1)).lt(bn(net)), `${net}`).to.be
          .true;
      }
    }
    expect(grossForTransferFee(ONE_PERCENT, bn(9_900)).toNumber()).to.equal(
      10_000,
    );
    expect(grossForTransferFee(CAPPED, bn(100_000)).toNumber()).to.equal(
      100_050,
    );
    expect(
      grossForTransferFee({ basisPoints: 10_000, maximumFee: bn(7) }, bn(3)),
    ).to.satisfy((x: BN) => x.eqn(10));
    expect(grossForTransferFee(null, bn(42)).toNumber()).to.equal(42);
    expect(grossForTransferFee(ONE_PERCENT, bn(0)).toNumber()).to.equal(0);
  });
});

describe("pricing on a transfer-fee quote", () => {
  const schedule = fees(20, 93, 30);
  const globalConfig: GlobalConfig = {
    admin: PublicKey.unique(),
    lpFeeBasisPoints: new BN(30),
    protocolFeeBasisPoints: new BN(20),
    disableFlags: 0,
    protocolFeeRecipients: [PublicKey.unique()],
    coinCreatorFeeBasisPoints: new BN(0),
    adminSetCoinCreatorAuthority: PublicKey.unique(),
    whitelistPda: PublicKey.unique(),
    reservedFeeRecipient: PublicKey.unique(),
    mayhemModeEnabled: false,
    reservedFeeRecipients: [],
    isCashbackEnabled: false,
    buybackFeeRecipients: [PublicKey.unique()],
    buybackBasisPoints: new BN(2_000),
    boostAuthority: PublicKey.default,
    boostEnabled: false,
    creatorFeeConfigurable: false,
    maxConfigurableCreatorFeeBps: new BN(0),
  };
  // An unlisted Token-2022 quote pays the exotic flat fees.
  const feeConfig: FeeConfig = {
    admin: PublicKey.unique(),
    flatFees: ZERO_FEES,
    feeTiers: [],
    stableFeeTiers: [],
    exoticFlatFees: schedule,
  };
  const baseMintAccount: RawMint = {
    mintAuthorityOption: 0,
    mintAuthority: PublicKey.unique(),
    supply: BigInt("1000000000000000"),
    decimals: 6,
    isInitialized: true,
    freezeAuthorityOption: 0,
    freezeAuthority: PublicKey.unique(),
  };
  const state = () => {
    const s = createSwapSolanaState({
      globalConfig,
      feeConfig,
      quoteMint: Keypair.generate().publicKey,
      quoteTokenProgram: TOKEN_2022_PROGRAM_ID,
      baseMintAccount,
      poolBaseAmount: bn("500000000000000"),
      poolQuoteAmount: bn("100000000000"),
    });
    s.pool.coinCreator = Keypair.generate().publicKey;
    return s;
  };
  const args = (s = state()) => ({
    baseReserve: s.poolBaseAmount,
    quoteReserve: s.poolQuoteAmount,
    globalConfig: s.globalConfig,
    feeConfig: s.feeConfig,
    baseMint: s.baseMint,
    baseMintAccount: s.baseMintAccount,
    coinCreator: s.pool.coinCreator,
    creator: s.pool.creator,
    quoteMint: s.pool.quoteMint,
  });

  it("buyBaseInput: v1 grosses up quote + LP fee, v2 everything but the buyback slice", () => {
    const untaxed = buyBaseInput({
      ...args(),
      base: bn(1_000_000_000),
      slippage: 0,
    });
    const v1 = buyBaseInput({
      ...args(),
      base: bn(1_000_000_000),
      slippage: 0,
      quoteTransferFee: ONE_PERCENT,
    });
    const v2 = buyBaseInput({
      ...args(),
      base: bn(1_000_000_000),
      slippage: 0,
      quoteTransferFee: ONE_PERCENT,
      tradeV2: true,
    });
    const quote = untaxed.internalQuoteAmount;
    const lp = quote.muln(20).addn(9_999).divn(10_000);
    const protocol = quote.muln(93).addn(9_999).divn(10_000);
    const creatorFee = quote.muln(30).addn(9_999).divn(10_000);
    const booked = quote.add(lp).add(protocol).add(creatorFee);
    expect(untaxed.uiQuote.eq(booked)).to.be.true;

    const v1Vault = quote.add(lp);
    expect(
      v1.uiQuote.eq(
        booked.add(grossForTransferFee(ONE_PERCENT, v1Vault).sub(v1Vault)),
      ),
    ).to.be.true;
    const buyback = protocol.muln(2_000).divn(10_000);
    const v2Vault = booked.sub(buyback);
    expect(
      v2.uiQuote.eq(grossForTransferFee(ONE_PERCENT, v2Vault).add(buyback)),
    ).to.be.true;
    expect(v2.uiQuote.gt(v1.uiQuote)).to.be.true;
    expect(v1.maxQuote.eq(v1.uiQuote)).to.be.true;
    // The same figure through the helper the two paths share.
    expect(
      buyDebit({
        quoteAmountIn: quote,
        lpFee: lp,
        protocolFee: protocol,
        coinCreatorFee: creatorFee,
        quoteTransferFee: ONE_PERCENT,
        tradeV2: true,
        globalConfig: args().globalConfig,
      }).eq(v2.uiQuote),
    ).to.be.true;
  });

  it("buyQuoteInput: the budget is what leaves the wallet, fee included", () => {
    const budget = bn(1_000_000_000);
    for (const tradeV2 of [false, true]) {
      const taxed = buyQuoteInput({
        ...args(),
        quote: budget,
        slippage: 0,
        quoteTransferFee: ONE_PERCENT,
        tradeV2,
      });
      const untaxed = buyQuoteInput({ ...args(), quote: budget, slippage: 0 });
      expect(taxed.base.lt(untaxed.base)).to.be.true;
      // Re-pricing the base it buys debits no more than the budget, and nearly all of it.
      const { uiQuote } = buyBaseInput({
        ...args(),
        base: taxed.base,
        slippage: 0,
        quoteTransferFee: ONE_PERCENT,
        tradeV2,
      });
      expect(uiQuote.lte(budget), `${tradeV2}`).to.be.true;
      // As the program: the derivation runs on what the budget lands, so the fee slices paid
      // as they are leave their tax's worth of the budget in the wallet, never more.
      expect(
        budget.sub(uiQuote).lte(transferFeeOn(ONE_PERCENT, budget)),
        `${tradeV2}`,
      ).to.be.true;
      expect(taxed.maxQuote.eq(budget)).to.be.true;
    }
  });

  it("sellBaseInput / sellQuoteInput: the floor is on what lands", () => {
    const base = bn(1_000_000_000);
    const untaxed = sellBaseInput({ ...args(), base, slippage: 0 });
    const taxed = sellBaseInput({
      ...args(),
      base,
      slippage: 0,
      quoteTransferFee: ONE_PERCENT,
    });
    expect(taxed.internalQuoteAmountOut.eq(untaxed.internalQuoteAmountOut)).to
      .be.true;
    expect(taxed.uiQuote.eq(netOfTransferFee(ONE_PERCENT, untaxed.uiQuote))).to
      .be.true;
    expect(taxed.minQuote.eq(taxed.uiQuote)).to.be.true;

    const want = taxed.uiQuote;
    const byQuote = sellQuoteInput({
      ...args(),
      quote: want,
      slippage: 0,
      quoteTransferFee: ONE_PERCENT,
    });
    expect(byQuote.minQuote.eq(want)).to.be.true;
    // Selling the base it asks for lands at least `want`.
    const check = sellBaseInput({
      ...args(),
      base: byQuote.base,
      slippage: 0,
      quoteTransferFee: ONE_PERCENT,
    });
    expect(check.uiQuote.gte(want)).to.be.true;
    expect(check.uiQuote.sub(want).lt(bn(1_000))).to.be.true;
  });

  it("deposit grosses up the quote, withdraw lands less the fee", () => {
    const untaxed = depositLpToken(
      bn(1_000),
      0,
      bn(50_000),
      bn(10_000),
      bn(5_000),
    );
    const taxed = depositLpToken(
      bn(1_000),
      0,
      bn(50_000),
      bn(10_000),
      bn(5_000),
      ONE_PERCENT,
    );
    expect(taxed.maxBase.eq(untaxed.maxBase)).to.be.true;
    expect(
      taxed.maxQuote.eq(grossForTransferFee(ONE_PERCENT, untaxed.maxQuote)),
    ).to.be.true;

    const out = withdraw(
      bn(1_000),
      0,
      bn(50_000),
      bn(10_000),
      bn(5_000),
      ONE_PERCENT,
    );
    expect(out.base.toNumber()).to.equal(10_000);
    expect(out.quote.toNumber()).to.equal(2_000 - 20);
    expect(out.minQuote.toNumber()).to.equal(2_000 - 20);
  });

  it("deposit previews are wallet-side: the quote shown is the quote debited", () => {
    const s = state();
    const liquidity = {
      ...s,
      poolBaseTokenAccount: { amount: BigInt("50000") } as any,
      poolQuoteTokenAccount: { amount: BigInt("10000") } as any,
      userPoolTokenAccount: s.userBaseTokenAccount,
      userPoolAccountInfo: null,
      pool: { ...s.pool, lpSupply: bn(5_000) },
    } as unknown as LiquiditySolanaState;
    const taxed = { ...liquidity, quoteTransferFee: ONE_PERCENT };

    const untaxed = PUMP_AMM_SDK.depositBaseInput(liquidity, bn(10_000), 0);
    const fromBase = PUMP_AMM_SDK.depositBaseInput(taxed, bn(10_000), 0);
    expect(untaxed.quote.toNumber()).to.equal(2_000);
    expect(fromBase.quote.eq(grossForTransferFee(ONE_PERCENT, bn(2_000)))).to.be
      .true;
    expect(fromBase.maxQuote.eq(fromBase.quote)).to.be.true;
    expect(fromBase.lpToken.eq(untaxed.lpToken)).to.be.true;

    // Spending the wallet-side quote back lands the same pool share and position.
    const fromQuote = PUMP_AMM_SDK.depositQuoteInput(taxed, fromBase.quote, 0);
    expect(fromQuote.base.eq(bn(10_000))).to.be.true;
    expect(fromQuote.lpToken.eq(fromBase.lpToken)).to.be.true;
    expect(fromQuote.maxQuote.lte(fromBase.quote)).to.be.true;
  });

  it("multi-hop: a buy hop prices what landed, a sell hop pays out what lands", () => {
    const s = state();
    const hop = (
      quoteTransferFee: QuoteTransferFee | null,
    ): MultiHopPoolQuoteHop => ({
      kind: "pool",
      poolKey: s.poolKey,
      pool: s.pool,
      baseTokenProgram: s.baseTokenProgram,
      quoteTokenProgram: s.quoteTokenProgram,
      poolBaseAmount: s.poolBaseAmount,
      poolQuoteAmount: s.poolQuoteAmount,
      baseMintSupply: bn("1000000000000000"),
      quoteTransferFee,
    });
    const route = (
      inMint: PublicKey,
      amountIn: BN,
      fee: QuoteTransferFee | null,
    ) =>
      multiHopSwapQuote({
        inMint,
        hops: [hop(fee)],
        amountIn,
        slippage: 0,
        globalConfig: s.globalConfig,
        feeConfig: s.feeConfig,
      }).amountOut;

    const buyIn = bn(1_000_000_000);
    const taxedBuy = route(s.pool.quoteMint, buyIn, ONE_PERCENT);
    const landedBuy = route(
      s.pool.quoteMint,
      netOfTransferFee(ONE_PERCENT, buyIn),
      null,
    );
    expect(taxedBuy.eq(landedBuy)).to.be.true;

    const sellIn = bn(1_000_000_000);
    const untaxedSell = route(s.pool.baseMint, sellIn, null);
    expect(
      route(s.pool.baseMint, sellIn, ONE_PERCENT).eq(
        netOfTransferFee(ONE_PERCENT, untaxedSell),
      ),
    ).to.be.true;
  });

  it("boostBuyAndBurnInstruction passes quote_mint writable", async () => {
    const s = state();
    const ix = await PUMP_AMM_SDK.boostBuyAndBurnInstruction(
      s.poolKey,
      s.pool,
      Keypair.generate().publicKey,
      bn(1),
      bn(1),
      s.baseTokenProgram,
      TOKEN_2022_PROGRAM_ID,
    );
    const meta = ix.keys.find((k) => k.pubkey.equals(s.pool.quoteMint))!;
    expect(meta.isWritable).to.be.true;
    expect(ix.keys.find((k) => k.pubkey.equals(s.pool.baseMint))!.isWritable).to
      .be.true;
  });
});
