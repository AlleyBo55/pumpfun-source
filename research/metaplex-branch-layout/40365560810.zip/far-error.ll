target triple = "sbf"

declare void @sink(ptr)

define void @guard(ptr %out, i64 %n, i64 %total, i64 %remaining) {
entry:
  %zero = icmp eq i64 %n, 0
  %over = icmp ugt i64 %n, %total
  %bad = or i1 %zero, %over
  br i1 %bad, label %initial_error, label %remaining_check

remaining_check:
  %under = icmp ult i64 %remaining, %n
  br i1 %under, label %underflow_error, label %success

initial_error:
  store i64 86, ptr %out, align 8
  call void @sink(ptr %out)
  ret void

success:
  %new_remaining = sub i64 %remaining, %n
  store i64 %new_remaining, ptr %out, align 8
  call void @sink(ptr %out)
  ret void

underflow_error:
  store i64 86, ptr %out, align 8
  call void @sink(ptr %out)
  ret void
}
